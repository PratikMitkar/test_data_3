import express from 'express'
import cors from 'cors'
import sqlite3 from 'sqlite3'
const { Database } = sqlite3.verbose()
import path from 'path'
import fs from 'fs'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

const app = express()
const PORT = 3001

// Middleware
app.use(cors())
app.use(express.json())

// Initialize SQLite database
const dbPath = path.join(__dirname, 'assessment.sqlite')
const db = new Database(dbPath)

// Create tables if they don't exist
db.serialize(() => {
    db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      employee_id TEXT NOT NULL UNIQUE,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `)

    db.run(`
    CREATE TABLE IF NOT EXISTS answers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      question_index INTEGER,
      question_text TEXT,
      answer TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users (id)
    )
  `)
})

// Load questions from JSON file
const loadQuestions = () => {
    try {
        const questionsPath = path.join(__dirname, 'questions.json')
        const questionsData = fs.readFileSync(questionsPath, 'utf8')
        return JSON.parse(questionsData)
    } catch (error) {
        console.error('Error loading questions:', error)
        return { questions: [] }
    }
}

// API Routes

// Create or get user
app.post('/api/users', (req, res) => {
    const { name, employeeId } = req.body

    if (!name || !employeeId) {
        return res.status(400).json({ error: 'Name and employee ID are required' })
    }

    // Check if user already exists
    db.get(
        'SELECT * FROM users WHERE employee_id = ?',
        [employeeId],
        (err, row) => {
            if (err) {
                return res.status(500).json({ error: 'Database error' })
            }

            if (row) {
                // User exists, return existing user
                return res.json({ user: { id: row.id, name: row.name, employeeId: row.employee_id } })
            }

            // Create new user
            db.run(
                'INSERT INTO users (name, employee_id) VALUES (?, ?)',
                [name, employeeId],
                function (err) {
                    if (err) {
                        return res.status(500).json({ error: 'Failed to create user' })
                    }

                    res.json({
                        user: {
                            id: this.lastID,
                            name,
                            employeeId
                        }
                    })
                }
            )
        }
    )
})

// Get question by index
app.get('/api/questions/:index', (req, res) => {
    const index = parseInt(req.params.index)
    const questionsData = loadQuestions()

    if (index >= 0 && index < questionsData.questions.length) {
        res.json({ question: questionsData.questions[index] })
    } else {
        res.json({ question: null })
    }
})

// Save answer
app.post('/api/answers', (req, res) => {
    const { userId, questionIndex, answer } = req.body

    if (!userId || questionIndex === undefined || !answer) {
        return res.status(400).json({ error: 'Missing required fields' })
    }

    const questionsData = loadQuestions()
    const question = questionsData.questions[questionIndex]

    if (!question) {
        return res.status(400).json({ error: 'Invalid question index' })
    }

    db.run(
        'INSERT INTO answers (user_id, question_index, question_text, answer) VALUES (?, ?, ?, ?)',
        [userId, questionIndex, question.text, answer],
        function (err) {
            if (err) {
                return res.status(500).json({ error: 'Failed to save answer' })
            }

            res.json({ success: true, answerId: this.lastID })
        }
    )
})

// Get user's assessment results
app.get('/api/users/:userId/results', (req, res) => {
    const userId = req.params.userId

    db.all(
        `SELECT u.name, u.employee_id, a.question_index, a.question_text, a.answer, a.created_at
     FROM users u
     LEFT JOIN answers a ON u.id = a.user_id
     WHERE u.id = ?
     ORDER BY a.question_index`,
        [userId],
        (err, rows) => {
            if (err) {
                return res.status(500).json({ error: 'Database error' })
            }

            if (rows.length === 0) {
                return res.status(404).json({ error: 'User not found' })
            }

            const user = {
                name: rows[0].name,
                employeeId: rows[0].employee_id
            }

            const answers = rows
                .filter(row => row.question_index !== null)
                .map(row => ({
                    questionIndex: row.question_index,
                    questionText: row.question_text,
                    answer: row.answer,
                    timestamp: row.created_at
                }))

            res.json({ user, answers })
        }
    )
})

// Export all data as CSV
app.get('/api/export/csv', (req, res) => {
    db.all(
        `SELECT 
            u.name as "Name",
            u.employee_id as "Employee ID",
            u.created_at as "Registration Date",
            a.question_index as "Question Number",
            a.question_text as "Question",
            a.answer as "Answer",
            a.created_at as "Answer Date"
         FROM users u
         LEFT JOIN answers a ON u.id = a.user_id
         ORDER BY u.id, a.question_index`,
        [],
        (err, rows) => {
            if (err) {
                return res.status(500).json({ error: 'Database error' })
            }

            // Convert to CSV format
            const headers = Object.keys(rows[0] || {})
            const csvContent = [
                headers.join(','),
                ...rows.map(row =>
                    headers.map(header =>
                        `"${(row[header] || '').toString().replace(/"/g, '""')}"`
                    ).join(',')
                )
            ].join('\n')

            res.setHeader('Content-Type', 'text/csv')
            res.setHeader('Content-Disposition', 'attachment; filename="assessment_data.csv"')
            res.send(csvContent)
        }
    )
})

// Get all users and their completion status
app.get('/api/admin/dashboard', (req, res) => {
    db.all(
        `SELECT 
            u.id,
            u.name,
            u.employee_id,
            u.created_at as registration_date,
            COUNT(a.id) as questions_answered,
            MAX(a.created_at) as last_activity
         FROM users u
         LEFT JOIN answers a ON u.id = a.user_id
         GROUP BY u.id, u.name, u.employee_id, u.created_at
         ORDER BY u.created_at DESC`,
        [],
        (err, rows) => {
            if (err) {
                return res.status(500).json({ error: 'Database error' })
            }

            const totalQuestions = loadQuestions().questions.length
            const usersWithStatus = rows.map(user => ({
                ...user,
                completion_percentage: Math.round((user.questions_answered / totalQuestions) * 100),
                status: user.questions_answered === totalQuestions ? 'Completed' : 'In Progress'
            }))

            res.json({ users: usersWithStatus, totalQuestions })
        }
    )
})

app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`)
    console.log(`Network access: http://192.168.137.66:${PORT}`)
})