# AI Assessment Platform

A React-based AI assessment platform where users enter their details and participate in a chat-based assessment focused on AI knowledge. The system stores all responses in a SQLite database and supports resuming incomplete assessments.

## ✨ Features

- **User Registration**: Name and employee ID entry
- **AI-Focused Questions**: 10 questions about AI, ML, and tech tools
- **Resume Functionality**: Continue from where you left off
- **SQLite Database**: Persistent data storage with `.sqlite` extension
- **Admin Dashboard**: View user progress and export data
- **Responsive Design**: Works on desktop, tablet, and mobile
- **Data Export**: CSV export for Excel compatibility

## 🚀 Quick Start

### Installation
```bash
npm install
```

### Run Application
```bash
npm run dev
```

This starts:
- **Frontend**: http://localhost:5173
- **Backend**: http://localhost:3001
- **Admin Dashboard**: http://localhost:5173?admin=true

## 📊 Database Management

### Database File Location
```
server/assessment.sqlite
```

### How to Access Database Data

#### 1. **Admin Dashboard (Recommended)**
- Visit: `http://localhost:5173?admin=true`
- View user progress, completion status
- Export all data to CSV format
- Real-time statistics

#### 2. **DB Browser for SQLite (Best for detailed analysis)**
- Download: [sqlitebrowser.org](https://sqlitebrowser.org/)
- Open `server/assessment.sqlite`
- Browse tables, run queries, export to various formats
- **Free and user-friendly GUI**

#### 3. **VS Code Extension**
- Install "SQLite Viewer" extension
- Right-click `assessment.sqlite` → "Open with SQLite Viewer"
- View and query data directly in VS Code

#### 4. **Command Line**
```bash
sqlite3 server/assessment.sqlite
.tables                    # List all tables
SELECT * FROM users;       # View all users
SELECT * FROM answers;     # View all answers
.quit                      # Exit
```

### Export Options

#### **CSV Export (Excel Compatible)**
- Use Admin Dashboard export button
- Direct download of formatted data
- Includes all user responses and timestamps

#### **Database Tools Export**
- DB Browser: Export to CSV, JSON, SQL, XML
- Command line: `.output filename.csv` then `.mode csv`
- Custom queries for specific data extraction

## 🗄️ Database Schema

### Users Table
```sql
CREATE TABLE users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  employee_id TEXT NOT NULL UNIQUE,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

### Answers Table
```sql
CREATE TABLE answers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  question_index INTEGER,
  question_text TEXT,
  answer TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users (id)
);
```

## 🔧 API Endpoints

### User Management
- `POST /api/users` - Create or retrieve user
- `GET /api/users/:userId/results` - Get user's assessment data

### Assessment
- `GET /api/questions/:index` - Get question by index
- `POST /api/answers` - Save user answer

### Admin & Export
- `GET /api/admin/dashboard` - Get all users with completion status
- `GET /api/export/csv` - Download CSV export of all data

## 📝 AI Assessment Questions

1. What is the full form of ML (related to AI)?
2. What is Artificial Intelligence in simple terms?
3. What is the difference between AI and Machine Learning?
4. What is a "prompt" in tools like ChatGPT or Midjourney?
5. After the Tech Talk, what AI topic or tool did you explore on your own?
6. What kind of AI tool would you like to learn or build if given a chance?
7. How do you currently stay updated about technology or AI news?
8. What does GitHub Copilot do for software developers?
9. Describe a time you explored a new tech tool just out of curiosity. What was it?
10. Have you taken any steps outside work (videos, courses, blogs) to learn AI?

## 🎯 Key Features

### **Resume Functionality**
- Users can return with same credentials
- System automatically continues from last answered question
- Previous conversation is reconstructed
- No data loss between sessions

### **Admin Dashboard Features**
- User completion statistics
- Progress tracking with visual progress bars
- Export functionality
- Real-time data updates
- Responsive design for all devices

### **Data Export Capabilities**
- **CSV Format**: Excel-compatible with proper formatting
- **Complete Data**: All user responses with timestamps
- **Structured Export**: Organized by user and question
- **Multiple Access Methods**: Web interface, database tools, command line

## 🛠️ Technologies Used

- **Frontend**: React 18, Vite, Axios
- **Backend**: Node.js, Express
- **Database**: SQLite3 with `.sqlite` extension
- **Styling**: Modern CSS with Space Grotesk font
- **Export**: CSV generation with proper formatting

## 📱 Responsive Design

- **Desktop**: Full-width layout with optimal spacing
- **Tablet**: Touch-optimized interface
- **Mobile**: Compact design with easy navigation
- **Admin Dashboard**: Responsive tables and statistics

## 🔍 Usage Examples

### **For Users**
1. Enter name and employee ID
2. Answer AI-related questions in chat format
3. Resume anytime with same credentials
4. Complete all 10 questions at your own pace

### **For Administrators**
1. Visit admin dashboard: `?admin=true`
2. Monitor user progress in real-time
3. Export data for analysis
4. Access database directly for custom queries

## 💡 Pro Tips

- **Database Backup**: Regularly backup `assessment.sqlite`
- **Excel Analysis**: Use CSV export for spreadsheet analysis
- **Custom Queries**: Use DB Browser for advanced data filtering
- **Monitoring**: Check admin dashboard for completion rates
- **Data Integrity**: SQLite ensures ACID compliance for reliable data storage

The platform now provides comprehensive data management with multiple access methods, making it easy to analyze assessment results and track user progress!