import React, { useState, useEffect, useRef } from 'react'
import axios from 'axios'
import './ChatWindow.css'

const ChatWindow = ({ user }) => {
  const [messages, setMessages] = useState([])
  const [currentAnswer, setCurrentAnswer] = useState('')
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)
  const [isComplete, setIsComplete] = useState(false)
  const [loading, setLoading] = useState(false)
  const [showCompletionModal, setShowCompletionModal] = useState(false)
  const [isAssessmentComplete, setIsAssessmentComplete] = useState(false)
  const [hasLoadedInitialQuestion, setHasLoadedInitialQuestion] = useState(false)
  const messagesEndRef = useRef(null)

  // Cache management
  const getCacheKey = () => `assessment_${user.employeeId}`
  
  const saveToCache = (data) => {
    localStorage.setItem(getCacheKey(), JSON.stringify(data))
  }
  
  const getFromCache = () => {
    const cached = localStorage.getItem(getCacheKey())
    return cached ? JSON.parse(cached) : null
  }
  
  const clearCache = () => {
    localStorage.removeItem(getCacheKey())
  }

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  useEffect(() => {
    // Check if user has previous answers and resume from where they left off
    loadPreviousChat()
  }, [])

  const loadPreviousChat = async () => {
    try {
      // Check cache first
      const cachedData = getFromCache()
      if (cachedData && cachedData.isComplete) {
        setIsAssessmentComplete(true)
        setIsComplete(true)
        return
      }

      const response = await axios.get(`/api/users/${user.id}/results`)
      const previousAnswers = response.data.answers || []
      
      // Check if assessment is complete (10 questions answered)
      if (previousAnswers.length >= 10) {
        setIsAssessmentComplete(true)
        setIsComplete(true)
        saveToCache({ isComplete: true, completedAt: new Date().toISOString() })
        return
      }
      
      if (previousAnswers.length > 0) {
        // Resume from previous session
        const chatMessages = []
        
        // Add welcome message
        chatMessages.push({
          type: 'ai',
          content: `Welcome back, ${user.name}! Let's continue your assessment from where you left off.`,
          timestamp: new Date().toISOString()
        })

        // Reconstruct previous conversation
        for (let i = 0; i < previousAnswers.length; i++) {
          chatMessages.push({
            type: 'ai',
            content: previousAnswers[i].questionText,
            timestamp: previousAnswers[i].timestamp
          })
          chatMessages.push({
            type: 'user',
            content: previousAnswers[i].answer,
            timestamp: previousAnswers[i].timestamp
          })
        }

        setMessages(chatMessages)
        setCurrentQuestionIndex(previousAnswers.length)
        setHasLoadedInitialQuestion(true)
        
        // Load next question after a short delay
        setTimeout(() => {
          loadNextQuestion()
        }, 1500)
      } else {
        // Start fresh assessment
        const welcomeMessage = {
          type: 'ai',
          content: `Hello ${user.name}! I'm your AI assessment assistant. I'll be asking you a series of questions to evaluate your AI knowledge. Let's begin!`,
          timestamp: new Date().toISOString()
        }
        setMessages([welcomeMessage])
        
        // Load first question after a short delay
        setTimeout(() => {
          if (!hasLoadedInitialQuestion) {
            setHasLoadedInitialQuestion(true)
            loadNextQuestion()
          }
        }, 2000)
      }
    } catch (error) {
      console.error('Error loading previous chat:', error)
      // Fallback to fresh start
      const welcomeMessage = {
        type: 'ai',
        content: `Hello ${user.name}! I'm your AI assessment assistant. I'll be asking you a series of questions to evaluate your AI knowledge. Let's begin!`,
        timestamp: new Date().toISOString()
      }
      setMessages([welcomeMessage])
      
      setTimeout(() => {
        if (!hasLoadedInitialQuestion) {
          setHasLoadedInitialQuestion(true)
          loadNextQuestion()
        }
      }, 2000)
    }
  }

  const loadNextQuestion = async () => {
    try {
      const response = await axios.get(`/api/questions/${currentQuestionIndex}`)
      if (response.data.question) {
        const questionMessage = {
          type: 'ai',
          content: response.data.question.text,
          timestamp: new Date().toISOString()
        }
        setMessages(prev => [...prev, questionMessage])
      } else {
        // No more questions - assessment complete
        setIsComplete(true)
        setIsAssessmentComplete(true)
        
        // Save completion to cache
        saveToCache({ isComplete: true, completedAt: new Date().toISOString() })
        
        const completionMessage = {
          type: 'ai',
          content: `Excellent work, ${user.name}! 🎉 You have successfully completed the AI Assessment. All your responses have been recorded. Thank you for participating!`,
          timestamp: new Date().toISOString()
        }
        setMessages(prev => [...prev, completionMessage])
        
        // Show completion modal after a short delay
        setTimeout(() => {
          setShowCompletionModal(true)
        }, 2000)
      }
    } catch (error) {
      console.error('Error loading question:', error)
    }
  }

  const handleSubmitAnswer = async () => {
    if (!currentAnswer.trim() || loading) return

    setLoading(true)

    // Add user message
    const userMessage = {
      type: 'user',
      content: currentAnswer,
      timestamp: new Date().toISOString()
    }
    setMessages(prev => [...prev, userMessage])

    try {
      // Save the answer
      await axios.post('/api/answers', {
        userId: user.id,
        questionIndex: currentQuestionIndex,
        answer: currentAnswer
      })

      setCurrentAnswer('')
      setCurrentQuestionIndex(prev => prev + 1)

      // Load next question after a short delay
      setTimeout(() => {
        loadNextQuestion()
      }, 1500)

    } catch (error) {
      console.error('Error saving answer:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSubmitAnswer()
    }
  }

  const handleCloseModal = () => {
    setShowCompletionModal(false)
  }

  const handleStartNew = () => {
    clearCache()
    window.location.reload()
  }

  const handleCloseCompletion = () => {
    window.location.reload()
  }

  // If assessment is already complete, show completion screen
  if (isAssessmentComplete && !showCompletionModal) {
    return (
      <div className="chat-container">
        <div className="completion-screen">
          <div className="completion-content">
            <div className="completion-icon-large">
              🎉
            </div>
            <h1>Assessment Already Complete!</h1>
            <p>
              Hello <strong>{user.name}</strong>, you have already completed the AI Assessment.
            </p>
            <div className="completion-details">
              <div className="detail-item">
                <span className="detail-icon">✅</span>
                <span>All 10 questions answered</span>
              </div>
              <div className="detail-item">
                <span className="detail-icon">💾</span>
                <span>Responses saved successfully</span>
              </div>
              <div className="detail-item">
                <span className="detail-icon">📊</span>
                <span>Data available for review</span>
              </div>
            </div>
            <p className="completion-note">
              Your assessment data has been recorded and is available for review by administrators.
            </p>
            <div className="completion-actions">
              <button onClick={handleStartNew} className="primary-button">
                Take New Assessment
              </button>
              <button onClick={handleCloseCompletion} className="secondary-button">
                Close
              </button>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="chat-container">
      {/* Hide chat window when assessment is complete but show during completion flow */}
      {!isComplete && (
        <>
          <div className="chat-title">
            <h1>AI Assessment</h1>
          </div>

          <div className="messages-container">
            {messages.map((message, index) => (
              <div key={index} className={`message-wrapper ${message.type}`}>
                <div className="message-avatar">
                  <div className={`avatar ${message.type}`}></div>
                </div>
                <div className="message-content-wrapper">
                  <p className="message-sender">
                    {message.type === 'ai' ? 'AI Tutor' : user.name}
                  </p>
                  <div className="message-bubble">
                    {message.content}
                  </div>
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          <div className="input-container">
            <div className="input-wrapper">
              <input
                type="text"
                value={currentAnswer}
                onChange={(e) => setCurrentAnswer(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Type your answer here..."
                disabled={loading}
                className="message-input"
              />
              <button
                onClick={handleSubmitAnswer}
                disabled={!currentAnswer.trim() || loading}
                className="send-button"
              >
                {loading ? 'Sending...' : 'Send'}
              </button>
            </div>
          </div>
        </>
      )}

      {/* Show completion message when assessment just finished */}
      {isComplete && !showCompletionModal && (
        <div className="completion-message-screen">
          <div className="completion-message-content">
            <div className="completion-icon-large">
              🎉
            </div>
            <h1>Assessment Complete!</h1>
            <p>
              Excellent work, <strong>{user.name}</strong>! You have successfully completed the AI Assessment.
            </p>
            <div className="loading-indicator">
              <div className="spinner"></div>
              <p>Processing your responses...</p>
            </div>
          </div>
        </div>
      )}

      {/* Completion Modal */}
      {showCompletionModal && (
        <div className="modal-overlay">
          <div className="completion-modal">
            <div className="modal-content">
              <div className="completion-icon">
                🎉
              </div>
              <h2>Assessment Complete!</h2>
              <p>
                Congratulations, <strong>{user.name}</strong>! You have successfully completed the AI Assessment.
              </p>
              <div className="completion-stats">
                <div className="stat-item">
                  <span className="stat-number">10</span>
                  <span className="stat-label">Questions Answered</span>
                </div>
                <div className="stat-item">
                  <span className="stat-number">✓</span>
                  <span className="stat-label">All Responses Saved</span>
                </div>
              </div>
              <p className="completion-message">
                Your responses have been recorded and will be reviewed. Thank you for participating in this assessment!
              </p>
              <div className="modal-buttons">
                <button onClick={handleStartNew} className="primary-button">
                  Start New Assessment
                </button>
                <button onClick={handleCloseModal} className="secondary-button">
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default ChatWindow