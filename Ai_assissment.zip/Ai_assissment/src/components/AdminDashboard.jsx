import React, { useState, useEffect } from 'react'
import axios from 'axios'
import './AdminDashboard.css'

const AdminDashboard = () => {
  const [users, setUsers] = useState([])
  const [selectedUser, setSelectedUser] = useState(null)
  const [userAnswers, setUserAnswers] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [analytics, setAnalytics] = useState({
    totalUsers: 0,
    completedAssessments: 0,
    inProgressAssessments: 0,
    averageCompletion: 0,
    totalQuestions: 10,
    recentActivity: []
  })
  const [activeTab, setActiveTab] = useState('analytics')

  useEffect(() => {
    fetchDashboardData()
  }, [])

  const fetchDashboardData = async () => {
    try {
      setLoading(true)
      const response = await axios.get('/api/admin/dashboard')
      const usersData = response.data.users || []
      setUsers(usersData)
      
      // Calculate analytics
      const totalUsers = usersData.length
      const completedAssessments = usersData.filter(user => user.status === 'Completed').length
      const inProgressAssessments = usersData.filter(user => user.status === 'In Progress').length
      const averageCompletion = totalUsers > 0 ? 
        Math.round(usersData.reduce((sum, user) => sum + user.completion_percentage, 0) / totalUsers) : 0
      
      // Get recent activity (last 5 users)
      const recentActivity = usersData
        .sort((a, b) => new Date(b.last_activity || b.registration_date) - new Date(a.last_activity || a.registration_date))
        .slice(0, 5)
      
      setAnalytics({
        totalUsers,
        completedAssessments,
        inProgressAssessments,
        averageCompletion,
        totalQuestions: response.data.totalQuestions || 10,
        recentActivity
      })
    } catch (err) {
      setError('Failed to fetch dashboard data')
      console.error('Error fetching dashboard data:', err)
    } finally {
      setLoading(false)
    }
  }

  const fetchUserAnswers = async (userId) => {
    try {
      const response = await axios.get(`/api/users/${userId}/results`)
      setUserAnswers(response.data.answers || [])
      setSelectedUser(response.data.user)
    } catch (err) {
      setError('Failed to fetch user answers')
      console.error('Error fetching user answers:', err)
    }
  }

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleString()
  }

  if (loading) {
    return (
      <div className="admin-container">
        <div className="loading">Loading dashboard...</div>
      </div>
    )
  }

  const exportToCSV = async () => {
    try {
      const response = await axios.get('/api/export/csv', {
        responseType: 'blob'
      })
      
      const url = window.URL.createObjectURL(new Blob([response.data]))
      const link = document.createElement('a')
      link.href = url
      link.setAttribute('download', 'assessment_data.csv')
      document.body.appendChild(link)
      link.click()
      link.remove()
      window.URL.revokeObjectURL(url)
    } catch (error) {
      console.error('Error exporting data:', error)
    }
  }

  return (
    <div className="admin-container">
      <div className="admin-header">
        <h1>AI Assessment Admin Dashboard</h1>
        <div className="header-actions">
          <button onClick={exportToCSV} className="export-btn">
            📊 Export CSV
          </button>
        </div>
      </div>

      {error && <div className="error-message">{error}</div>}

      {/* Tab Navigation */}
      <div className="tab-navigation">
        <button 
          className={`tab-btn ${activeTab === 'analytics' ? 'active' : ''}`}
          onClick={() => setActiveTab('analytics')}
        >
          📈 Analytics
        </button>
        <button 
          className={`tab-btn ${activeTab === 'users' ? 'active' : ''}`}
          onClick={() => setActiveTab('users')}
        >
          👥 User Responses
        </button>
      </div>

      {/* Analytics Tab */}
      {activeTab === 'analytics' && (
        <div className="analytics-content">
          {/* Key Metrics */}
          <div className="metrics-grid">
            <div className="metric-card">
              <div className="metric-icon">👥</div>
              <div className="metric-info">
                <h3>Total Users</h3>
                <div className="metric-number">{analytics.totalUsers}</div>
              </div>
            </div>
            <div className="metric-card">
              <div className="metric-icon">✅</div>
              <div className="metric-info">
                <h3>Completed</h3>
                <div className="metric-number">{analytics.completedAssessments}</div>
              </div>
            </div>
            <div className="metric-card">
              <div className="metric-icon">⏳</div>
              <div className="metric-info">
                <h3>In Progress</h3>
                <div className="metric-number">{analytics.inProgressAssessments}</div>
              </div>
            </div>
            <div className="metric-card">
              <div className="metric-icon">📊</div>
              <div className="metric-info">
                <h3>Avg. Completion</h3>
                <div className="metric-number">{analytics.averageCompletion}%</div>
              </div>
            </div>
          </div>

          {/* Charts and Analytics */}
          <div className="analytics-grid">
            {/* Completion Rate Chart */}
            <div className="analytics-card">
              <h3>Completion Rate</h3>
              <div className="completion-chart">
                <div className="chart-bar">
                  <div className="bar-section completed" 
                       style={{width: `${analytics.totalUsers > 0 ? (analytics.completedAssessments / analytics.totalUsers) * 100 : 0}%`}}>
                    <span>Completed ({analytics.completedAssessments})</span>
                  </div>
                  <div className="bar-section in-progress" 
                       style={{width: `${analytics.totalUsers > 0 ? (analytics.inProgressAssessments / analytics.totalUsers) * 100 : 0}%`}}>
                    <span>In Progress ({analytics.inProgressAssessments})</span>
                  </div>
                </div>
                <div className="chart-legend">
                  <div className="legend-item">
                    <div className="legend-color completed"></div>
                    <span>Completed: {analytics.totalUsers > 0 ? Math.round((analytics.completedAssessments / analytics.totalUsers) * 100) : 0}%</span>
                  </div>
                  <div className="legend-item">
                    <div className="legend-color in-progress"></div>
                    <span>In Progress: {analytics.totalUsers > 0 ? Math.round((analytics.inProgressAssessments / analytics.totalUsers) * 100) : 0}%</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Recent Activity */}
            <div className="analytics-card">
              <h3>Recent Activity</h3>
              <div className="activity-list">
                {analytics.recentActivity.length === 0 ? (
                  <div className="no-activity">No recent activity</div>
                ) : (
                  analytics.recentActivity.map((user, index) => (
                    <div key={index} className="activity-item">
                      <div className="activity-info">
                        <div className="activity-name">{user.name}</div>
                        <div className="activity-details">
                          {user.questions_answered}/{analytics.totalQuestions} questions • {user.completion_percentage}% complete
                        </div>
                      </div>
                      <div className="activity-status">
                        <span className={`status-badge ${user.status.toLowerCase().replace(' ', '-')}`}>
                          {user.status}
                        </span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* User Progress Table */}
          <div className="analytics-card full-width">
            <h3>User Progress Overview</h3>
            <div className="progress-table-wrapper">
              <table className="progress-table">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Employee ID</th>
                    <th>Progress</th>
                    <th>Status</th>
                    <th>Last Activity</th>
                  </tr>
                </thead>
                <tbody>
                  {users.map(user => (
                    <tr key={user.id}>
                      <td>{user.name}</td>
                      <td>{user.employee_id}</td>
                      <td>
                        <div className="progress-bar-small">
                          <div 
                            className="progress-fill-small" 
                            style={{ width: `${user.completion_percentage}%` }}
                          ></div>
                          <span className="progress-text-small">{user.completion_percentage}%</span>
                        </div>
                      </td>
                      <td>
                        <span className={`status-badge ${user.status.toLowerCase().replace(' ', '-')}`}>
                          {user.status}
                        </span>
                      </td>
                      <td>
                        {user.last_activity 
                          ? formatDate(user.last_activity)
                          : formatDate(user.registration_date)
                        }
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* User Responses Tab */}
      {activeTab === 'users' && (
        <div className="dashboard-content">
          <div className="users-panel">
            <h2>Users ({users.length})</h2>
            <div className="users-list">
              {users.length === 0 ? (
                <div className="no-data">No users found</div>
              ) : (
                users.map((user) => (
                  <div
                    key={user.id}
                    className={`user-card ${selectedUser?.id === user.id ? 'selected' : ''}`}
                    onClick={() => fetchUserAnswers(user.id)}
                  >
                    <div className="user-info">
                      <h3>{user.name}</h3>
                      <p>ID: {user.employee_id}</p>
                      <span className="user-date">
                        Registered: {formatDate(user.registration_date)}
                      </span>
                    </div>
                    <div className="user-stats">
                      <span className={`status-badge ${user.status.toLowerCase().replace(' ', '-')}`}>
                        {user.status}
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          <div className="answers-panel">
            {selectedUser ? (
              <>
                <div className="selected-user-header">
                  <h2>{selectedUser.name}'s Responses</h2>
                  <p>Employee ID: {selectedUser.employeeId}</p>
                </div>
                
                <div className="answers-list">
                  {userAnswers.length === 0 ? (
                    <div className="no-data">No answers found for this user</div>
                  ) : (
                    userAnswers.map((answer, index) => (
                      <div key={index} className="answer-card">
                        <div className="question-header">
                          <span className="question-number">Q{answer.questionIndex + 1}</span>
                          <span className="answer-date">{formatDate(answer.timestamp)}</span>
                        </div>
                        <div className="question-text">
                          {answer.questionText}
                        </div>
                        <div className="answer-text">
                          <strong>Answer:</strong> {answer.answer}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </>
            ) : (
              <div className="no-selection">
                <h2>Select a user to view their responses</h2>
                <p>Click on a user from the left panel to see their assessment answers</p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}

export default AdminDashboard