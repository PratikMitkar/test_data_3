import React, { useState } from 'react'
import axios from 'axios'
import './UserForm.css'

const UserForm = ({ onSubmit }) => {
  const [formData, setFormData] = useState({
    name: '',
    employeeId: ''
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    
    if (!formData.name.trim() || !formData.employeeId.trim()) {
      setError('Please fill in all fields')
      return
    }

    setLoading(true)
    setError('')

    try {
      const response = await axios.post('/api/users', formData)
      onSubmit(response.data.user)
    } catch (err) {
      setError('Failed to create user session')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="user-form-container">
      <div className="form-content">
        <div className="form-header">
          <h1>AI Assessment</h1>
          <p>Please enter your details to begin your personalized assessment</p>
        </div>
        
        <form onSubmit={handleSubmit} className="user-form">
          <div className="form-group">
            <label htmlFor="name">Full Name</label>
            <input
              type="text"
              id="name"
              name="name"
              value={formData.name}
              onChange={handleChange}
              placeholder="Enter your full name"
              required
              className="form-input"
            />
          </div>
          
          <div className="form-group">
            <label htmlFor="employeeId">Employee ID</label>
            <input
              type="text"
              id="employeeId"
              name="employeeId"
              value={formData.employeeId}
              onChange={handleChange}
              placeholder="Enter your employee ID"
              required
              className="form-input"
            />
          </div>
          
          {error && <div className="error-message">{error}</div>}
          
          <button type="submit" disabled={loading} className="submit-button">
            {loading ? 'Starting Assessment...' : 'Start Assessment'}
          </button>
        </form>
      </div>
    </div>
  )
}

export default UserForm