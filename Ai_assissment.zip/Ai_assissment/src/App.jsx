import React, { useState, useEffect } from 'react'
import UserForm from './components/UserForm'
import ChatWindow from './components/ChatWindow'
import AdminDashboard from './components/AdminDashboard'
import './App.css'

function App() {
  const [user, setUser] = useState(null)
  const [showAdmin, setShowAdmin] = useState(false)

  useEffect(() => {
    // Check if URL contains admin parameter
    const urlParams = new URLSearchParams(window.location.search)
    if (urlParams.get('admin') === 'true') {
      setShowAdmin(true)
    }
  }, [])

  const handleUserSubmit = (userData) => {
    setUser(userData)
  }

  if (showAdmin) {
    return <AdminDashboard />
  }

  return (
    <div className="App">
      {!user ? (
        <UserForm onSubmit={handleUserSubmit} />
      ) : (
        <ChatWindow user={user} />
      )}
    </div>
  )
}

export default App