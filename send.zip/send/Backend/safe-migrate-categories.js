const sqlite3 = require('sqlite3').verbose();
const path = require('path');

console.log('🔄 Starting safe ticket category migration...');

// Open the database
const db = new sqlite3.Database('./database.sqlite', (err) => {
  if (err) {
    console.error('❌ Error opening database:', err.message);
    process.exit(1);
  }
  console.log('✅ Connected to the SQLite database.');
});

// Function to run migration
async function migrateCategories() {
  return new Promise((resolve, reject) => {
    // First, let's check if there are any existing tickets
    db.get("SELECT COUNT(*) as count FROM tickets", (err, row) => {
      if (err) {
        console.error('❌ Error checking tickets:', err.message);
        reject(err);
        return;
      }
      
      const ticketCount = row.count;
      console.log(`📊 Found ${ticketCount} existing tickets in the database.`);
      
      if (ticketCount === 0) {
        console.log('ℹ️  No existing tickets found. Migration not needed.');
        resolve();
        return;
      }
      
      // Check current categories
      db.all("SELECT DISTINCT category FROM tickets", (err, rows) => {
        if (err) {
          console.error('❌ Error checking categories:', err.message);
          reject(err);
          return;
        }
        
        console.log('📋 Current categories in database:');
        rows.forEach(row => console.log(`   - ${row.category}`));
        
        // Create a backup table
        console.log('💾 Creating backup of existing tickets...');
        db.run("CREATE TABLE IF NOT EXISTS tickets_backup AS SELECT * FROM tickets", (err) => {
          if (err) {
            console.error('❌ Error creating backup:', err.message);
            reject(err);
            return;
          }
          
          console.log('✅ Backup created successfully.');
          
          // Update categories with mapping
          console.log('🔄 Updating ticket categories...');
          
          const updateQueries = [
            "UPDATE tickets SET category = 'Hardware' WHERE category = 'technical'",
            "UPDATE tickets SET category = 'Software' WHERE category = 'business'",
            "UPDATE tickets SET category = 'Tools' WHERE category = 'infrastructure'",
            "UPDATE tickets SET category = 'Cyber sec' WHERE category = 'security'",
            "UPDATE tickets SET category = 'Lab Support' WHERE category = 'performance'",
            "UPDATE tickets SET category = 'Tools' WHERE category = 'ui/ux'",
            "UPDATE tickets SET category = 'Software' WHERE category = 'database'",
            "UPDATE tickets SET category = 'Software' WHERE category = 'api'"
          ];
          
          let completed = 0;
          let errors = [];
          
          updateQueries.forEach((query, index) => {
            db.run(query, function(err) {
              if (err) {
                console.error(`❌ Error in update ${index + 1}:`, err.message);
                errors.push(err);
              } else {
                console.log(`✅ Update ${index + 1} completed. Rows affected: ${this.changes}`);
              }
              
              completed++;
              
              if (completed === updateQueries.length) {
                if (errors.length > 0) {
                  console.error('❌ Some updates failed. Rolling back...');
                  db.run("DROP TABLE tickets_backup", () => {
                    reject(new Error('Migration failed'));
                  });
                } else {
                  console.log('✅ All category updates completed successfully.');
                  
                  // Verify the migration
                  db.all("SELECT category, COUNT(*) as count FROM tickets GROUP BY category", (err, rows) => {
                    if (err) {
                      console.error('❌ Error verifying migration:', err.message);
                      reject(err);
                      return;
                    }
                    
                    console.log('\n📊 Final ticket category distribution:');
                    rows.forEach(row => {
                      console.log(`   ${row.category}: ${row.count} tickets`);
                    });
                    
                    // Keep the backup for safety
                    console.log('\n💾 Backup table "tickets_backup" has been preserved for safety.');
                    console.log('   You can drop it later if everything looks good: DROP TABLE tickets_backup;');
                    
                    resolve();
                  });
                }
              }
            });
          });
        });
      });
    });
  });
}

// Run the migration
migrateCategories()
  .then(() => {
    console.log('\n🎉 Migration completed successfully!');
  })
  .catch((error) => {
    console.error('\n❌ Migration failed:', error.message);
  })
  .finally(() => {
    db.close((err) => {
      if (err) {
        console.error('❌ Error closing database:', err.message);
      } else {
        console.log('✅ Database connection closed.');
      }
    });
  }); 