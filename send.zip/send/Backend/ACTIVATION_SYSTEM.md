# User/Team Activation/Deactivation & Archive System

## Overview

This document describes the comprehensive activation/deactivation and archiving system implemented for the ticketing system. The system provides hierarchical user management with automatic archiving of content when users or teams are deactivated.

## System Architecture

### User Hierarchy
```
SuperAdmin
    ├── Admin
    │   ├── Team
    │   │   ├── User
    │   │   ├── User
    │   │   └── User
    │   └── Team
    └── Team (directly managed)
```

### Activation Status
- All user types (SuperAdmin, Admin, Team, User) have an `isActive` boolean field
- When deactivated, users cannot login and their content is archived
- Hierarchical cascade: deactivating higher-level users automatically deactivates subordinates

## Features Implemented

### 1. Activation/Deactivation API Endpoints

#### SuperAdmin Management
- `PUT /api/admin/super-admin/:id/status` - Activate/deactivate super admin
  - Only other SuperAdmins can perform this action
  - Prevents self-deactivation
  - Cascades to all managed admins and teams

#### Admin Management  
- `PUT /api/admin/admin/:id/status` - Activate/deactivate admin
  - SuperAdmins and the admin themselves can perform this action
  - Prevents self-deactivation
  - Cascades to all managed teams and users

#### Team Management
- `PUT /api/admin/team/:id/status` - Activate/deactivate team
  - SuperAdmins and managing admins can perform this action
  - Cascades to all team members

#### User Management
- `PUT /api/admin/user/:id/status` - Activate/deactivate user
  - SuperAdmins, managing admins, and team managers can perform this action
  - No cascade (individual user deactivation)

### 2. Archive System

#### Automatic Archiving
- When users/teams are deactivated, their tickets and projects are automatically archived
- Archived content is hidden from normal API responses
- Archive status is determined by the active status of creators and assigned teams

#### Archive Retrieval
- `GET /api/admin/archived` - Get archived tickets and projects
  - Supports filtering by type (tickets, projects, or all)
  - Includes pagination and search functionality
  - Admin-only access

#### Archive Filtering
- All ticket and project endpoints support `includeArchived` parameter
- Default behavior excludes archived content
- Set `includeArchived=true` to include archived items

### 3. System Monitoring

#### System Status
- `GET /api/admin/system-status` - Get comprehensive system overview
  - Shows active/inactive counts for all user types
  - Shows active/archived counts for tickets and projects
  - SuperAdmin-only access

#### Archive Statistics
- Integrated with ArchiveService for real-time statistics
- Tracks total, active, and archived counts for all entities

### 4. Authentication Updates

#### Enhanced Security
- Deactivated users cannot login (401 Unauthorized)
- Users from deactivated teams cannot login
- Proper error messages for different deactivation scenarios

#### Token Validation
- Enhanced middleware checks user and team active status
- Automatic logout for deactivated accounts

## Technical Implementation

### 1. Database Schema
All user tables include `isActive` boolean field:
- `super_admins.is_active`
- `admins.is_active` 
- `teams.is_active`
- `users.is_active`

### 2. Services

#### ArchiveService (`services/archiveService.js`)
- `isUserArchived(userId)` - Check if user is archived
- `isTeamArchived(teamId)` - Check if team is archived
- `getArchivedTickets(options)` - Get archived tickets with filtering
- `getArchivedProjects(options)` - Get archived projects with filtering
- `getActiveTickets(whereClause, includeConditions)` - Get non-archived tickets
- `getActiveProjects(whereClause, includeConditions)` - Get non-archived projects
- `getArchiveStats()` - Get system-wide archive statistics
- `cascadeDeactivation(entityType, entityId, isActive)` - Handle cascade deactivation

### 3. Routes

#### Admin Routes (`routes/admin.js`)
- Centralized admin functionality
- Proper permission checking
- Cascade deactivation handling
- Archive management

#### Updated Existing Routes
- `routes/tickets.js` - Added archive filtering
- `routes/projects.js` - Added archive filtering  
- `routes/users.js` - Enhanced with active team filtering
- `routes/teams.js` - Maintained existing functionality

### 4. Middleware Updates

#### Authentication Middleware (`middleware/auth.js`)
- Enhanced to check user and team active status
- Proper error handling for deactivated accounts
- Support for all user types

## Usage Examples

### Deactivate a Team (cascades to all members)
```javascript
PUT /api/admin/team/123/status
{
  "isActive": false
}
```

### Get Archived Content
```javascript
GET /api/admin/archived?type=tickets&page=1&limit=10
```

### Get Active Tickets Only
```javascript
GET /api/tickets?includeArchived=false
```

### Get System Status
```javascript
GET /api/admin/system-status
```

## Cascade Behavior

### Deactivation Cascade
- SuperAdmin deactivation → All managed admins and teams deactivated
- Admin deactivation → All managed teams and users deactivated  
- Team deactivation → All team members deactivated
- User deactivation → No cascade

### Reactivation
- Manual reactivation required at each level
- No automatic cascade upward
- Allows granular control over reactivation

## Archive Logic

### Content Archiving Rules
1. **Tickets are archived if:**
   - Creator user is deactivated, OR
   - Creator team is deactivated, OR
   - Assigned team is deactivated

2. **Projects are archived if:**
   - Manager user is deactivated, OR
   - Project team is deactivated

### Filtering Implementation
- Archive status determined at query time
- Efficient database queries with proper joins
- Consistent behavior across all endpoints

## Security Considerations

### Permission Matrix
| Action | SuperAdmin | Admin | Team Manager | User |
|--------|------------|-------|--------------|------|
| Deactivate SuperAdmin | ✅ (others only) | ❌ | ❌ | ❌ |
| Deactivate Admin | ✅ | ✅ (self only) | ❌ | ❌ |
| Deactivate Team | ✅ | ✅ (managed only) | ❌ | ❌ |
| Deactivate User | ✅ | ✅ (managed only) | ✅ (team only) | ❌ |
| View Archived | ✅ | ✅ | ❌ | ❌ |
| System Status | ✅ | ❌ | ❌ | ❌ |

### Self-Protection
- Users cannot deactivate themselves
- Prevents accidental lockouts
- Requires another admin for deactivation

## Testing

### Test Files
- `test-activation-system.js` - Comprehensive test suite
- `test-basic-activation.js` - Basic functionality tests
- `test-simple.js` - Simple server connectivity tests

### Test Coverage
- Login/logout with deactivated accounts
- Cascade deactivation behavior
- Archive filtering functionality
- Permission enforcement
- System status reporting

## Error Handling

### Common Error Responses
- `401 Unauthorized` - Deactivated account login attempt
- `403 Forbidden` - Insufficient permissions
- `404 Not Found` - User/team not found
- `400 Bad Request` - Invalid parameters

### Error Messages
- Clear, descriptive error messages
- Proper HTTP status codes
- Consistent error format across endpoints

## Performance Considerations

### Database Optimization
- Proper indexing on `isActive` fields
- Efficient joins for archive filtering
- Pagination for large result sets

### Caching Strategy
- Archive status computed at query time
- No caching of archive status (real-time accuracy)
- Efficient database queries minimize performance impact

## Future Enhancements

### Potential Improvements
1. **Soft Delete**: Instead of just deactivation, implement soft delete
2. **Archive Retention**: Automatic cleanup of old archived content
3. **Bulk Operations**: Bulk activate/deactivate multiple entities
4. **Audit Trail**: Track who activated/deactivated whom and when
5. **Scheduled Deactivation**: Set future deactivation dates
6. **Archive Export**: Export archived content for backup

### API Extensions
1. **Restore from Archive**: Endpoint to restore archived content
2. **Archive Search**: Advanced search within archived content
3. **Archive Analytics**: Detailed analytics on archived content
4. **Notification System**: Notify users before deactivation

## Conclusion

The activation/deactivation and archive system provides comprehensive user lifecycle management with proper security, cascading behavior, and content archiving. The system is designed to be scalable, secure, and maintainable while providing administrators with the tools they need to manage users and content effectively.