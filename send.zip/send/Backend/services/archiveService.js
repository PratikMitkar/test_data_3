const { Op } = require('sequelize');
const User = require('../models/User');
const Team = require('../models/Team');
const Admin = require('../models/Admin');
const SuperAdmin = require('../models/SuperAdmin');
const Ticket = require('../models/Ticket');
const Project = require('../models/Project');

class ArchiveService {
  /**
   * Check if a user is archived (deactivated)
   * @param {number} userId - User ID to check
   * @returns {Promise<boolean>} - True if user is archived
   */
  static async isUserArchived(userId) {
    try {
      const user = await User.findByPk(userId);
      if (!user) return true; // Consider non-existent users as archived
      
      // Check if user is inactive
      if (!user.isActive) return true;
      
      // Check if user's team is inactive
      const team = await Team.findByPk(user.teamId);
      if (!team || !team.isActive) return true;
      
      return false;
    } catch (error) {
      console.error('Error checking user archive status:', error);
      return true; // Default to archived on error
    }
  }

  /**
   * Check if a team is archived (deactivated)
   * @param {number} teamId - Team ID to check
   * @returns {Promise<boolean>} - True if team is archived
   */
  static async isTeamArchived(teamId) {
    try {
      const team = await Team.findByPk(teamId);
      return !team || !team.isActive;
    } catch (error) {
      console.error('Error checking team archive status:', error);
      return true; // Default to archived on error
    }
  }

  /**
   * Get archived tickets based on deactivated users/teams
   * @param {Object} options - Query options
   * @returns {Promise<Object>} - Archived tickets with pagination
   */
  static async getArchivedTickets(options = {}) {
    const {
      page = 1,
      limit = 10,
      search,
      priority,
      status,
      sort = 'createdAt',
      order = 'desc'
    } = options;

    try {
      const whereClause = {};
      
      if (search) {
        whereClause[Op.or] = [
          { title: { [Op.like]: `%${search}%` } },
          { description: { [Op.like]: `%${search}%` } }
        ];
      }
      
      if (priority) whereClause.priority = priority;
      if (status) whereClause.status = status;

      const offset = (parseInt(page) - 1) * parseInt(limit);

      const { count, rows: tickets } = await Ticket.findAndCountAll({
        where: whereClause,
        include: [
          {
            model: User,
            as: 'creator',
            attributes: ['id', 'name', 'email', 'isActive'],
            required: false
          },
          {
            model: Team,
            as: 'creatorTeam',
            attributes: ['id', 'teamName', 'isActive'],
            required: false
          },
          {
            model: Team,
            as: 'assignedTeam',
            attributes: ['id', 'teamName', 'isActive'],
            required: false
          },
          {
            model: User,
            as: 'assignedUser',
            attributes: ['id', 'name', 'email', 'isActive'],
            required: false
          }
        ],
        order: [[sort, order.toUpperCase()]],
        limit: parseInt(limit),
        offset: offset
      });

      // Filter tickets that are archived (creator or team is inactive)
      const archivedTickets = tickets.filter(ticket => {
        const creatorInactive = ticket.creator && !ticket.creator.isActive;
        const creatorTeamInactive = ticket.creatorTeam && !ticket.creatorTeam.isActive;
        const assignedTeamInactive = ticket.assignedTeam && !ticket.assignedTeam.isActive;
        
        return creatorInactive || creatorTeamInactive || assignedTeamInactive;
      });

      return {
        tickets: archivedTickets,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total: archivedTickets.length,
          pages: Math.ceil(archivedTickets.length / parseInt(limit))
        }
      };
    } catch (error) {
      console.error('Error getting archived tickets:', error);
      throw error;
    }
  }

  /**
   * Get archived projects based on deactivated users/teams
   * @param {Object} options - Query options
   * @returns {Promise<Object>} - Archived projects with pagination
   */
  static async getArchivedProjects(options = {}) {
    const {
      page = 1,
      limit = 10,
      search,
      priority,
      status,
      sort = 'createdAt',
      order = 'desc'
    } = options;

    try {
      const whereClause = {};
      
      if (search) {
        whereClause[Op.or] = [
          { name: { [Op.like]: `%${search}%` } },
          { description: { [Op.like]: `%${search}%` } },
          { code: { [Op.like]: `%${search}%` } }
        ];
      }
      
      if (priority) whereClause.priority = priority;
      if (status) whereClause.status = status;

      const offset = (parseInt(page) - 1) * parseInt(limit);

      const { count, rows: projects } = await Project.findAndCountAll({
        where: whereClause,
        include: [
          {
            model: User,
            as: 'manager',
            attributes: ['id', 'name', 'email', 'isActive'],
            required: false
          },
          {
            model: Team,
            as: 'team',
            attributes: ['id', 'teamName', 'isActive'],
            required: false
          }
        ],
        order: [[sort, order.toUpperCase()]],
        limit: parseInt(limit),
        offset: offset
      });

      // Filter projects that are archived (manager or team is inactive)
      const archivedProjects = projects.filter(project => {
        const managerInactive = project.manager && !project.manager.isActive;
        const teamInactive = project.team && !project.team.isActive;
        
        return managerInactive || teamInactive;
      });

      return {
        projects: archivedProjects,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total: archivedProjects.length,
          pages: Math.ceil(archivedProjects.length / parseInt(limit))
        }
      };
    } catch (error) {
      console.error('Error getting archived projects:', error);
      throw error;
    }
  }

  /**
   * Get active (non-archived) tickets
   * @param {Object} whereClause - Base where conditions
   * @param {Object} includeConditions - Include conditions
   * @returns {Promise<Array>} - Filtered active tickets
   */
  static async getActiveTickets(whereClause = {}, includeConditions = []) {
    try {
      const tickets = await Ticket.findAll({
        where: whereClause,
        include: [
          {
            model: User,
            as: 'creator',
            attributes: ['id', 'name', 'email', 'isActive'],
            where: { isActive: true },
            required: false
          },
          {
            model: Team,
            as: 'creatorTeam',
            attributes: ['id', 'teamName', 'isActive'],
            where: { isActive: true },
            required: false
          },
          {
            model: Team,
            as: 'assignedTeam',
            attributes: ['id', 'teamName', 'isActive'],
            where: { isActive: true },
            required: false
          },
          ...includeConditions
        ]
      });

      // Filter out tickets where creator or teams are inactive
      return tickets.filter(ticket => {
        const creatorActive = !ticket.creator || ticket.creator.isActive;
        const creatorTeamActive = !ticket.creatorTeam || ticket.creatorTeam.isActive;
        const assignedTeamActive = !ticket.assignedTeam || ticket.assignedTeam.isActive;
        
        return creatorActive && creatorTeamActive && assignedTeamActive;
      });
    } catch (error) {
      console.error('Error getting active tickets:', error);
      throw error;
    }
  }

  /**
   * Get active (non-archived) projects
   * @param {Object} whereClause - Base where conditions
   * @param {Object} includeConditions - Include conditions
   * @returns {Promise<Array>} - Filtered active projects
   */
  static async getActiveProjects(whereClause = {}, includeConditions = []) {
    try {
      const projects = await Project.findAll({
        where: whereClause,
        include: [
          {
            model: User,
            as: 'manager',
            attributes: ['id', 'name', 'email', 'isActive'],
            where: { isActive: true },
            required: false
          },
          {
            model: Team,
            as: 'team',
            attributes: ['id', 'teamName', 'isActive'],
            where: { isActive: true },
            required: false
          },
          ...includeConditions
        ]
      });

      // Filter out projects where manager or team is inactive
      return projects.filter(project => {
        const managerActive = !project.manager || project.manager.isActive;
        const teamActive = !project.team || project.team.isActive;
        
        return managerActive && teamActive;
      });
    } catch (error) {
      console.error('Error getting active projects:', error);
      throw error;
    }
  }

  /**
   * Get system archive statistics
   * @returns {Promise<Object>} - Archive statistics
   */
  static async getArchiveStats() {
    try {
      const [
        totalUsers,
        activeUsers,
        totalTeams,
        activeTeams,
        totalAdmins,
        activeAdmins,
        totalSuperAdmins,
        activeSuperAdmins,
        totalTickets,
        totalProjects
      ] = await Promise.all([
        User.count(),
        User.count({ where: { isActive: true } }),
        Team.count(),
        Team.count({ where: { isActive: true } }),
        Admin.count(),
        Admin.count({ where: { isActive: true } }),
        SuperAdmin.count(),
        SuperAdmin.count({ where: { isActive: true } }),
        Ticket.count(),
        Project.count()
      ]);

      // Get archived tickets and projects
      const archivedTicketsResult = await this.getArchivedTickets({ limit: 1000 });
      const archivedProjectsResult = await this.getArchivedProjects({ limit: 1000 });

      return {
        users: {
          total: totalUsers,
          active: activeUsers,
          archived: totalUsers - activeUsers
        },
        teams: {
          total: totalTeams,
          active: activeTeams,
          archived: totalTeams - activeTeams
        },
        admins: {
          total: totalAdmins,
          active: activeAdmins,
          archived: totalAdmins - activeAdmins
        },
        superAdmins: {
          total: totalSuperAdmins,
          active: activeSuperAdmins,
          archived: totalSuperAdmins - activeSuperAdmins
        },
        tickets: {
          total: totalTickets,
          archived: archivedTicketsResult.tickets.length,
          active: totalTickets - archivedTicketsResult.tickets.length
        },
        projects: {
          total: totalProjects,
          archived: archivedProjectsResult.projects.length,
          active: totalProjects - archivedProjectsResult.projects.length
        }
      };
    } catch (error) {
      console.error('Error getting archive stats:', error);
      throw error;
    }
  }

  /**
   * Cascade deactivation when a user/team/admin is deactivated
   * @param {string} entityType - Type of entity ('user', 'team', 'admin', 'super_admin')
   * @param {number} entityId - ID of the entity
   * @param {boolean} isActive - New active status
   */
  static async cascadeDeactivation(entityType, entityId, isActive) {
    try {
      if (isActive) {
        // When reactivating, we don't cascade (manual reactivation required)
        return;
      }

      switch (entityType) {
        case 'super_admin':
          // Deactivate all admins managed by this super admin
          const managedAdmins = await Admin.findAll({ where: { superAdminId: entityId } });
          for (const admin of managedAdmins) {
            await admin.update({ isActive: false });
            await this.cascadeDeactivation('admin', admin.id, false);
          }
          
          // Deactivate teams directly managed by super admin
          const directTeams = await Team.findAll({ where: { superAdminId: entityId } });
          for (const team of directTeams) {
            await team.update({ isActive: false });
            await this.cascadeDeactivation('team', team.id, false);
          }
          break;

        case 'admin':
          // Deactivate all teams managed by this admin
          const adminTeams = await Team.findAll({ where: { adminId: entityId } });
          for (const team of adminTeams) {
            await team.update({ isActive: false });
            await this.cascadeDeactivation('team', team.id, false);
          }
          break;

        case 'team':
          // Deactivate all users in this team
          await User.update({ isActive: false }, { where: { teamId: entityId } });
          break;

        case 'user':
          // No cascade needed for individual users
          break;
      }
    } catch (error) {
      console.error('Error in cascade deactivation:', error);
      throw error;
    }
  }
}

module.exports = ArchiveService;