const axios = require('axios');

async function testSimple() {
  console.log('🔧 Simple Activation System Test');
  console.log('================================');
  
  try {
    // Test server health
    console.log('\n1. Testing server health...');
    const health = await axios.get('http://localhost:5000/api/health');
    console.log('✅ Server is running:', health.data.status);
    
    // Test if admin routes are accessible (should be protected)
    console.log('\n2. Testing admin route protection...');
    try {
      await axios.get('http://localhost:5000/api/admin/system-status');
      console.log('❌ Admin route should be protected');
    } catch (error) {
      if (error.response?.status === 401) {
        console.log('✅ Admin routes are properly protected');
      } else {
        console.log('⚠️  Unexpected response:', error.response?.status);
      }
    }
    
    // Test basic auth endpoint
    console.log('\n3. Testing auth endpoint...');
    try {
      await axios.post('http://localhost:5000/api/auth/login', {
        email: 'invalid@test.com',
        password: 'invalid'
      });
      console.log('❌ Invalid login should fail');
    } catch (error) {
      if (error.response?.status === 401 || error.response?.status === 400) {
        console.log('✅ Auth endpoint working (invalid login rejected)');
      } else {
        console.log('⚠️  Unexpected auth response:', error.response?.status);
      }
    }
    
    console.log('\n✅ Simple tests completed successfully!');
    console.log('💡 To run full tests, ensure you have test data and run: node test-activation-system.js');
    
  } catch (error) {
    console.error('❌ Simple test failed:', error.message);
    if (error.code === 'ECONNREFUSED') {
      console.log('💡 Make sure the server is running: npm start or node server.js');
    }
  }
}

testSimple().catch(console.error);