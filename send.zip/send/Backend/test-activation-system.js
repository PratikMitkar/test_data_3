const axios = require('axios');

// Configuration
const BASE_URL = 'http://localhost:5000/api';
let authTokens = {};

// Test data storage
let testData = {
  superAdmin: null,
  admin: null,
  team: null,
  user: null,
  ticket: null,
  project: null
};

// Helper function to make authenticated requests
const makeRequest = async (method, url, data = null, userType = 'superAdmin') => {
  try {
    const config = {
      method,
      url: `${BASE_URL}${url}`,
      headers: {
        'Authorization': `Bearer ${authTokens[userType]}`,
        'Content-Type': 'application/json'
      }
    };
    
    if (data) {
      config.data = data;
    }
    
    const response = await axios(config);
    return response.data;
  } catch (error) {
    console.error(`Error in ${method} ${url}:`, error.response?.data || error.message);
    throw error;
  }
};

// Test functions
async function testLogin() {
  console.log('\n=== Testing Login ===');
  
  try {
    // Login as SuperAdmin
    const superAdminLogin = await axios.post(`${BASE_URL}/auth/login`, {
      email: 'superadmin@company.com',
      password: 'password123'
    });
    authTokens.superAdmin = superAdminLogin.data.token;
    testData.superAdmin = superAdminLogin.data.user;
    console.log('✅ SuperAdmin login successful');
    
    // Login as Admin
    const adminLogin = await axios.post(`${BASE_URL}/auth/login`, {
      email: 'admin@company.com',
      password: 'password123'
    });
    authTokens.admin = adminLogin.data.token;
    testData.admin = adminLogin.data.user;
    console.log('✅ Admin login successful');
    
    // Login as Team Manager
    const teamLogin = await axios.post(`${BASE_URL}/auth/login`, {
      email: 'team1@company.com',
      password: 'password123'
    });
    authTokens.team = teamLogin.data.token;
    testData.team = teamLogin.data.user;
    console.log('✅ Team Manager login successful');
    
    // Login as User
    const userLogin = await axios.post(`${BASE_URL}/auth/login`, {
      email: 'user1@company.com',
      password: 'password123'
    });
    authTokens.user = userLogin.data.token;
    testData.user = userLogin.data.user;
    console.log('✅ User login successful');
    
  } catch (error) {
    console.error('❌ Login failed:', error.response?.data || error.message);
    throw error;
  }
}

async function testSystemStatus() {
  console.log('\n=== Testing System Status ===');
  
  try {
    const status = await makeRequest('GET', '/admin/system-status');
    console.log('✅ System Status Retrieved:');
    console.log(`   SuperAdmins: ${status.systemStatus.superAdmins.active}/${status.systemStatus.superAdmins.total} active`);
    console.log(`   Admins: ${status.systemStatus.admins.active}/${status.systemStatus.admins.total} active`);
    console.log(`   Teams: ${status.systemStatus.teams.active}/${status.systemStatus.teams.total} active`);
    console.log(`   Users: ${status.systemStatus.users.active}/${status.systemStatus.users.total} active`);
    console.log(`   Tickets: ${status.systemStatus.tickets.active}/${status.systemStatus.tickets.total} active`);
    console.log(`   Projects: ${status.systemStatus.projects.active}/${status.systemStatus.projects.total} active`);
  } catch (error) {
    console.error('❌ System status test failed:', error.response?.data || error.message);
  }
}

async function testCreateTicketAndProject() {
  console.log('\n=== Testing Ticket and Project Creation ===');
  
  try {
    // Create a test ticket
    const ticketData = {
      title: 'Test Activation System Ticket',
      description: 'This ticket is for testing the activation/deactivation system',
      type: 'task',
      category: 'Software',
      teamId: testData.user.teamId,
      assignedTeamId: testData.user.teamId,
      priority: 'MEDIUM',
      dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString()
    };
    
    const ticket = await makeRequest('POST', '/tickets', ticketData, 'user');
    testData.ticket = ticket.ticket;
    console.log('✅ Test ticket created:', testData.ticket.id);
    
    // Create a test project
    const projectData = {
      name: 'Test Activation System Project',
      description: 'This project is for testing the activation/deactivation system',
      code: 'TEST-ACTIVATION-001',
      priority: 'medium',
      managerId: testData.user.id,
      teamId: testData.user.teamId
    };
    
    const project = await makeRequest('POST', '/projects', projectData, 'admin');
    testData.project = project.project;
    console.log('✅ Test project created:', testData.project.id);
    
  } catch (error) {
    console.error('❌ Create ticket/project test failed:', error.response?.data || error.message);
  }
}

async function testUserDeactivation() {
  console.log('\n=== Testing User Deactivation ===');
  
  try {
    // Deactivate user
    await makeRequest('PUT', `/admin/user/${testData.user.id}/status`, { isActive: false }, 'admin');
    console.log('✅ User deactivated successfully');
    
    // Try to login as deactivated user (should fail)
    try {
      await axios.post(`${BASE_URL}/auth/login`, {
        email: 'user1@company.com',
        password: 'password123'
      });
      console.log('❌ Deactivated user login should have failed');
    } catch (error) {
      if (error.response?.status === 401) {
        console.log('✅ Deactivated user login correctly rejected');
      } else {
        throw error;
      }
    }
    
    // Check if tickets are archived
    const tickets = await makeRequest('GET', '/tickets?includeArchived=false', null, 'admin');
    const archivedTickets = await makeRequest('GET', '/admin/archived?type=tickets', null, 'admin');
    
    console.log(`✅ Active tickets: ${tickets.tickets.length}`);
    console.log(`✅ Archived tickets: ${archivedTickets.archived.tickets.tickets.length}`);
    
  } catch (error) {
    console.error('❌ User deactivation test failed:', error.response?.data || error.message);
  }
}

async function testTeamDeactivation() {
  console.log('\n=== Testing Team Deactivation ===');
  
  try {
    // Get team ID
    const teamId = testData.user.teamId;
    
    // Deactivate team
    await makeRequest('PUT', `/admin/team/${teamId}/status`, { isActive: false }, 'admin');
    console.log('✅ Team deactivated successfully');
    
    // Try to login as team manager (should fail)
    try {
      await axios.post(`${BASE_URL}/auth/login`, {
        email: 'team1@company.com',
        password: 'password123'
      });
      console.log('❌ Deactivated team manager login should have failed');
    } catch (error) {
      if (error.response?.status === 401) {
        console.log('✅ Deactivated team manager login correctly rejected');
      } else {
        throw error;
      }
    }
    
    // Check archived content
    const archivedData = await makeRequest('GET', '/admin/archived?type=all', null, 'admin');
    console.log(`✅ Total archived tickets: ${archivedData.archived.tickets.tickets.length}`);
    console.log(`✅ Total archived projects: ${archivedData.archived.projects.projects.length}`);
    
  } catch (error) {
    console.error('❌ Team deactivation test failed:', error.response?.data || error.message);
  }
}

async function testAdminDeactivation() {
  console.log('\n=== Testing Admin Deactivation ===');
  
  try {
    // Deactivate admin
    await makeRequest('PUT', `/admin/admin/${testData.admin.id}/status`, { isActive: false }, 'superAdmin');
    console.log('✅ Admin deactivated successfully');
    
    // Try to login as deactivated admin (should fail)
    try {
      await axios.post(`${BASE_URL}/auth/login`, {
        email: 'admin@company.com',
        password: 'password123'
      });
      console.log('❌ Deactivated admin login should have failed');
    } catch (error) {
      if (error.response?.status === 401) {
        console.log('✅ Deactivated admin login correctly rejected');
      } else {
        throw error;
      }
    }
    
  } catch (error) {
    console.error('❌ Admin deactivation test failed:', error.response?.data || error.message);
  }
}

async function testReactivation() {
  console.log('\n=== Testing Reactivation ===');
  
  try {
    // Reactivate admin
    await makeRequest('PUT', `/admin/admin/${testData.admin.id}/status`, { isActive: true }, 'superAdmin');
    console.log('✅ Admin reactivated successfully');
    
    // Reactivate team
    const teamId = testData.user.teamId;
    await makeRequest('PUT', `/admin/team/${teamId}/status`, { isActive: true }, 'admin');
    console.log('✅ Team reactivated successfully');
    
    // Reactivate user
    await makeRequest('PUT', `/admin/user/${testData.user.id}/status`, { isActive: true }, 'admin');
    console.log('✅ User reactivated successfully');
    
    // Test login after reactivation
    const userLogin = await axios.post(`${BASE_URL}/auth/login`, {
      email: 'user1@company.com',
      password: 'password123'
    });
    console.log('✅ User login successful after reactivation');
    
  } catch (error) {
    console.error('❌ Reactivation test failed:', error.response?.data || error.message);
  }
}

async function testCascadeDeactivation() {
  console.log('\n=== Testing Cascade Deactivation ===');
  
  try {
    // Get initial system status
    const initialStatus = await makeRequest('GET', '/admin/system-status');
    console.log('📊 Initial Status:');
    console.log(`   Active Users: ${initialStatus.systemStatus.users.active}`);
    console.log(`   Active Teams: ${initialStatus.systemStatus.teams.active}`);
    console.log(`   Active Admins: ${initialStatus.systemStatus.admins.active}`);
    
    // Deactivate admin (should cascade to teams and users)
    await makeRequest('PUT', `/admin/admin/${testData.admin.id}/status`, { isActive: false }, 'superAdmin');
    console.log('✅ Admin deactivated (cascade should occur)');
    
    // Check system status after cascade
    const afterStatus = await makeRequest('GET', '/admin/system-status');
    console.log('📊 After Cascade Status:');
    console.log(`   Active Users: ${afterStatus.systemStatus.users.active}`);
    console.log(`   Active Teams: ${afterStatus.systemStatus.teams.active}`);
    console.log(`   Active Admins: ${afterStatus.systemStatus.admins.active}`);
    
    // Verify cascade worked
    const usersDiff = initialStatus.systemStatus.users.active - afterStatus.systemStatus.users.active;
    const teamsDiff = initialStatus.systemStatus.teams.active - afterStatus.systemStatus.teams.active;
    
    console.log(`✅ Cascade deactivated ${usersDiff} users and ${teamsDiff} teams`);
    
  } catch (error) {
    console.error('❌ Cascade deactivation test failed:', error.response?.data || error.message);
  }
}

async function testArchiveFiltering() {
  console.log('\n=== Testing Archive Filtering ===');
  
  try {
    // Get active tickets (should exclude archived)
    const activeTickets = await makeRequest('GET', '/tickets?includeArchived=false', null, 'superAdmin');
    console.log(`✅ Active tickets: ${activeTickets.tickets.length}`);
    
    // Get all tickets (including archived)
    const allTickets = await makeRequest('GET', '/tickets?includeArchived=true', null, 'superAdmin');
    console.log(`✅ All tickets (including archived): ${allTickets.tickets.length}`);
    
    // Get archived content
    const archivedContent = await makeRequest('GET', '/admin/archived', null, 'superAdmin');
    console.log(`✅ Explicitly archived tickets: ${archivedContent.archived.tickets.tickets.length}`);
    console.log(`✅ Explicitly archived projects: ${archivedContent.archived.projects.projects.length}`);
    
    // Verify filtering works
    const archivedCount = allTickets.tickets.length - activeTickets.tickets.length;
    console.log(`✅ Archive filtering working: ${archivedCount} tickets filtered out`);
    
  } catch (error) {
    console.error('❌ Archive filtering test failed:', error.response?.data || error.message);
  }
}

// Main test runner
async function runAllTests() {
  console.log('🚀 Starting Activation/Deactivation System Tests');
  console.log('================================================');
  
  try {
    await testLogin();
    await testSystemStatus();
    await testCreateTicketAndProject();
    await testUserDeactivation();
    await testTeamDeactivation();
    await testAdminDeactivation();
    await testReactivation();
    await testCascadeDeactivation();
    await testArchiveFiltering();
    
    console.log('\n🎉 All tests completed successfully!');
    console.log('================================================');
    
  } catch (error) {
    console.error('\n💥 Test suite failed:', error.message);
    process.exit(1);
  }
}

// Run tests if this file is executed directly
if (require.main === module) {
  runAllTests().catch(console.error);
}

module.exports = {
  runAllTests,
  testLogin,
  testSystemStatus,
  testUserDeactivation,
  testTeamDeactivation,
  testAdminDeactivation,
  testReactivation,
  testCascadeDeactivation,
  testArchiveFiltering
};