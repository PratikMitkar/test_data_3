const sqlite3 = require('sqlite3').verbose();

console.log('🔧 Fixing database schema column naming issues...');

// Open the database
const db = new sqlite3.Database('./database.sqlite', (err) => {
  if (err) {
    console.error('❌ Error opening database:', err.message);
    process.exit(1);
  }
  console.log('✅ Connected to the SQLite database.');
});

// Function to fix the schema
async function fixSchema() {
  return new Promise((resolve, reject) => {
    // First, let's check the current table structure
    db.all("PRAGMA table_info(tickets)", (err, columns) => {
      if (err) {
        console.error('❌ Error checking table structure:', err.message);
        reject(err);
        return;
      }
      
      console.log('📋 Current table columns:');
      columns.forEach(col => {
        console.log(`   - ${col.name} (${col.type})`);
      });
      
      // Check if we need to rename columns
      const needsRenaming = columns.some(col => 
        col.name === 'assignedTeamId' || 
        col.name === 'dueDate' || 
        col.name === 'createdBy' || 
        col.name === 'teamId' || 
        col.name === 'projectId' || 
        col.name === 'assignedTo' || 
        col.name === 'approvedBy' || 
        col.name === 'approvedAt' || 
        col.name === 'rejectionReason' || 
        col.name === 'expectedClosure' || 
        col.name === 'actualClosure' || 
        col.name === 'estimatedHours' || 
        col.name === 'actualHours' || 
        col.name === 'createdAt' || 
        col.name === 'updatedAt'
      );
      
      if (!needsRenaming) {
        console.log('✅ Schema is already correct. No changes needed.');
        resolve();
        return;
      }
      
      console.log('🔄 Schema needs updating. Creating new table with correct column names...');
      
      // Create new table with correct column names
      const createTableSQL = `
        CREATE TABLE tickets_new (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          title VARCHAR(200) NOT NULL,
          description TEXT,
          type VARCHAR(50) NOT NULL,
          category VARCHAR(50) NOT NULL CHECK (
            category IN (
              'Hardware',
              'Software', 
              'Tools',
              'Lab Support',
              'Purchase',
              'ASPICE',
              'Functional Safety',
              'Cyber sec'
            )
          ),
          assigned_team_id INTEGER NOT NULL,
          due_date DATETIME NOT NULL,
          created_by INTEGER NOT NULL,
          team_id INTEGER NOT NULL,
          project_id INTEGER,
          assigned_to INTEGER,
          priority VARCHAR(20) DEFAULT 'MEDIUM',
          status VARCHAR(20) DEFAULT 'PENDING_APPROVAL',
          approved_by INTEGER,
          approved_at DATETIME,
          rejection_reason TEXT,
          expected_closure DATETIME,
          actual_closure DATETIME,
          estimated_hours FLOAT,
          actual_hours FLOAT,
          project VARCHAR(100),
          attachments TEXT DEFAULT '[]',
          comments TEXT DEFAULT '[]',
          tags TEXT DEFAULT '[]',
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
      `;
      
      db.run(createTableSQL, (err) => {
        if (err) {
          console.error('❌ Error creating new table:', err.message);
          reject(err);
          return;
        }
        
        console.log('✅ New table created successfully.');
        
        // Copy data from old table to new table
        const copyDataSQL = `
          INSERT INTO tickets_new (
            id, title, description, type, category, 
            assigned_team_id, due_date, created_by, team_id, project_id,
            assigned_to, priority, status, approved_by, approved_at,
            rejection_reason, expected_closure, actual_closure, estimated_hours,
            actual_hours, project, attachments, comments, tags, created_at, updated_at
          )
          SELECT 
            id, title, description, type, category,
            assignedTeamId, dueDate, createdBy, teamId, projectId,
            assignedTo, priority, status, approvedBy, approvedAt,
            rejectionReason, expectedClosure, actualClosure, estimatedHours,
            actualHours, project, attachments, comments, tags, createdAt, updatedAt
          FROM tickets
        `;
        
        db.run(copyDataSQL, function(err) {
          if (err) {
            console.error('❌ Error copying data:', err.message);
            reject(err);
            return;
          }
          
          console.log(`✅ Data copied successfully. ${this.changes} rows transferred.`);
          
          // Drop old table and rename new table
          db.run("DROP TABLE tickets", (err) => {
            if (err) {
              console.error('❌ Error dropping old table:', err.message);
              reject(err);
              return;
            }
            
            console.log('✅ Old table dropped.');
            
            db.run("ALTER TABLE tickets_new RENAME TO tickets", (err) => {
              if (err) {
                console.error('❌ Error renaming table:', err.message);
                reject(err);
                return;
              }
              
              console.log('✅ Table renamed successfully.');
              
              // Recreate indexes
              const indexes = [
                "CREATE INDEX idx_tickets_team_id ON tickets(team_id)",
                "CREATE INDEX idx_tickets_assigned_team_id ON tickets(assigned_team_id)",
                "CREATE INDEX idx_tickets_created_by ON tickets(created_by)",
                "CREATE INDEX idx_tickets_assigned_to ON tickets(assigned_to)",
                "CREATE INDEX idx_tickets_status ON tickets(status)",
                "CREATE INDEX idx_tickets_priority ON tickets(priority)"
              ];
              
              let indexCount = 0;
              indexes.forEach((indexSQL, i) => {
                db.run(indexSQL, (err) => {
                  if (err) {
                    console.error(`❌ Error creating index ${i + 1}:`, err.message);
                  } else {
                    console.log(`✅ Index ${i + 1} created.`);
                  }
                  
                  indexCount++;
                  if (indexCount === indexes.length) {
                    console.log('🎉 Schema update completed successfully!');
                    resolve();
                  }
                });
              });
            });
          });
        });
      });
    });
  });
}

// Run the schema fix
fixSchema()
  .then(() => {
    console.log('\n✅ Database schema has been updated successfully!');
    console.log('🔄 The application should now work correctly with the new ticket categories.');
  })
  .catch((error) => {
    console.error('\n❌ Schema update failed:', error.message);
  })
  .finally(() => {
    db.close((err) => {
      if (err) {
        console.error('❌ Error closing database:', err.message);
      } else {
        console.log('✅ Database connection closed.');
      }
    });
  }); 