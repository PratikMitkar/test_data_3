const express = require('express');
const { Op } = require('sequelize');
const SuperAdmin = require('../models/SuperAdmin');
const Admin = require('../models/Admin');
const Team = require('../models/Team');
const User = require('../models/User');
const Ticket = require('../models/Ticket');
const Project = require('../models/Project');
const ArchiveService = require('../services/archiveService');
const { 
  authenticateToken, 
  isAdmin,
  authorizeRole
} = require('../middleware/auth');
const { 
  validateId 
} = require('../middleware/validation');

const router = express.Router();

// Helper function to check user permissions
const checkUserPermissions = async (user) => {
  try {
    const admin = await Admin.findOne({ where: { email: user.email } });
    const superAdmin = await SuperAdmin.findOne({ where: { email: user.email } });
    
    if (admin) return { role: 'admin', adminId: admin.id };
    if (superAdmin) return { role: 'super_admin', superAdminId: superAdmin.id };
    
    return { role: 'user' };
  } catch (error) {
    console.error('Error checking user permissions:', error);
    return { role: 'user' };
  }
};

// Activate/Deactivate SuperAdmin (Only other SuperAdmins can do this)
router.put('/super-admin/:id/status', authenticateToken, authorizeRole('super_admin'), validateId, async (req, res) => {
  try {
    const { isActive } = req.body;
    
    if (typeof isActive !== 'boolean') {
      return res.status(400).json({
        error: 'isActive must be a boolean value'
      });
    }

    // Prevent self-deactivation
    if (req.user.id === parseInt(req.params.id) && !isActive) {
      return res.status(400).json({
        error: 'Cannot deactivate yourself'
      });
    }

    const superAdmin = await SuperAdmin.findByPk(req.params.id);
    
    if (!superAdmin) {
      return res.status(404).json({
        error: 'Super Admin not found'
      });
    }

    await superAdmin.update({ isActive });

    // Use cascade deactivation service
    if (!isActive) {
      await ArchiveService.cascadeDeactivation('super_admin', superAdmin.id, false);
    }

    res.json({
      message: `Super Admin ${isActive ? 'activated' : 'deactivated'} successfully`,
      superAdmin: {
        id: superAdmin.id,
        name: superAdmin.name,
        email: superAdmin.email,
        isActive: superAdmin.isActive
      }
    });
  } catch (error) {
    console.error('Update super admin status error:', error);
    res.status(500).json({
      error: 'Failed to update super admin status',
      message: error.message
    });
  }
});

// Activate/Deactivate Admin (SuperAdmin and Admin can do this)
router.put('/admin/:id/status', authenticateToken, isAdmin, validateId, async (req, res) => {
  try {
    const { isActive } = req.body;
    
    if (typeof isActive !== 'boolean') {
      return res.status(400).json({
        error: 'isActive must be a boolean value'
      });
    }

    const userPermissions = await checkUserPermissions(req.user);
    
    // Prevent self-deactivation
    if (req.user.id === parseInt(req.params.id) && !isActive) {
      return res.status(400).json({
        error: 'Cannot deactivate yourself'
      });
    }

    const admin = await Admin.findByPk(req.params.id);
    
    if (!admin) {
      return res.status(404).json({
        error: 'Admin not found'
      });
    }

    // Check permissions - only super admin or the admin themselves can modify
    if (userPermissions.role === 'admin' && req.user.id !== admin.id) {
      return res.status(403).json({
        error: 'Admins can only modify their own status'
      });
    }

    await admin.update({ isActive });

    // Use cascade deactivation service
    if (!isActive) {
      await ArchiveService.cascadeDeactivation('admin', admin.id, false);
    }

    res.json({
      message: `Admin ${isActive ? 'activated' : 'deactivated'} successfully`,
      admin: {
        id: admin.id,
        name: admin.name,
        email: admin.email,
        isActive: admin.isActive
      }
    });
  } catch (error) {
    console.error('Update admin status error:', error);
    res.status(500).json({
      error: 'Failed to update admin status',
      message: error.message
    });
  }
});

// Activate/Deactivate Team (SuperAdmin and Admin can do this)
router.put('/team/:id/status', authenticateToken, isAdmin, validateId, async (req, res) => {
  try {
    const { isActive } = req.body;
    
    if (typeof isActive !== 'boolean') {
      return res.status(400).json({
        error: 'isActive must be a boolean value'
      });
    }

    const team = await Team.findByPk(req.params.id);
    
    if (!team) {
      return res.status(404).json({
        error: 'Team not found'
      });
    }

    const userPermissions = await checkUserPermissions(req.user);
    
    // Check permissions - admin can only manage their own teams
    if (userPermissions.role === 'admin') {
      if (team.adminId !== userPermissions.adminId) {
        return res.status(403).json({
          error: 'You can only manage teams assigned to you'
        });
      }
    }

    await team.update({ isActive });

    // Use cascade deactivation service
    if (!isActive) {
      await ArchiveService.cascadeDeactivation('team', team.id, false);
    }

    res.json({
      message: `Team ${isActive ? 'activated' : 'deactivated'} successfully`,
      team: {
        id: team.id,
        teamName: team.teamName,
        managerName: team.managerName,
        email: team.email,
        isActive: team.isActive
      }
    });
  } catch (error) {
    console.error('Update team status error:', error);
    res.status(500).json({
      error: 'Failed to update team status',
      message: error.message
    });
  }
});

// Activate/Deactivate User (SuperAdmin, Admin, and Team Manager can do this)
router.put('/user/:id/status', authenticateToken, validateId, async (req, res) => {
  try {
    const { isActive } = req.body;
    
    if (typeof isActive !== 'boolean') {
      return res.status(400).json({
        error: 'isActive must be a boolean value'
      });
    }

    const user = await User.findByPk(req.params.id, {
      include: [
        {
          model: Team,
          as: 'team',
          attributes: ['id', 'teamName', 'adminId', 'superAdminId']
        }
      ]
    });
    
    if (!user) {
      return res.status(404).json({
        error: 'User not found'
      });
    }

    const userPermissions = await checkUserPermissions(req.user);
    
    // Check permissions
    if (userPermissions.role === 'admin') {
      // Admin can only manage users in teams they manage
      if (user.team.adminId !== userPermissions.adminId) {
        return res.status(403).json({
          error: 'You can only manage users in teams assigned to you'
        });
      }
    } else if (userPermissions.role === 'team') {
      // Team manager can only manage users in their team
      const team = await Team.findOne({ where: { email: req.user.email } });
      if (!team || user.teamId !== team.id) {
        return res.status(403).json({
          error: 'You can only manage users in your team'
        });
      }
    } else if (userPermissions.role !== 'super_admin') {
      return res.status(403).json({
        error: 'Access denied. Insufficient permissions.'
      });
    }

    await user.update({ isActive });

    res.json({
      message: `User ${isActive ? 'activated' : 'deactivated'} successfully`,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        teamName: user.team.teamName,
        isActive: user.isActive
      }
    });
  } catch (error) {
    console.error('Update user status error:', error);
    res.status(500).json({
      error: 'Failed to update user status',
      message: error.message
    });
  }
});

// Get archived tickets and projects (Admin only)
router.get('/archived', authenticateToken, isAdmin, async (req, res) => {
  try {
    const { type = 'all', page = 1, limit = 10, search, priority, status } = req.query;
    
    let archivedData = {};
    
    if (type === 'all' || type === 'tickets') {
      archivedData.tickets = await ArchiveService.getArchivedTickets({
        page,
        limit,
        search,
        priority,
        status
      });
    }
    
    if (type === 'all' || type === 'projects') {
      archivedData.projects = await ArchiveService.getArchivedProjects({
        page,
        limit,
        search,
        priority,
        status
      });
    }
    
    res.json({
      archived: archivedData,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit)
      }
    });
  } catch (error) {
    console.error('Get archived data error:', error);
    res.status(500).json({
      error: 'Failed to get archived data',
      message: error.message
    });
  }
});

// Get system status overview (SuperAdmin only)
router.get('/system-status', authenticateToken, authorizeRole('super_admin'), async (req, res) => {
  try {
    const systemStatus = await ArchiveService.getArchiveStats();
    res.json({ systemStatus });
  } catch (error) {
    console.error('Get system status error:', error);
    res.status(500).json({
      error: 'Failed to get system status',
      message: error.message
    });
  }
});

module.exports = router;