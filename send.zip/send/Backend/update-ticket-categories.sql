-- Backup the existing tickets table
CREATE TABLE tickets_backup AS SELECT * FROM tickets;

-- Drop the existing tickets table
DROP TABLE tickets;

-- Recreate the tickets table with the new category constraints
CREATE TABLE tickets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    type VARCHAR(50) NOT NULL,
    category VARCHAR(50) NOT NULL CHECK (
        category IN (
            'Hardware', 
            'Software', 
            'Tools', 
            'Lab Support', 
            'Purchase', 
            'ASPICE', 
            'Functional Safety', 
            'Cyber sec'
        )
    ),
    assignedTeamId INTEGER NOT NULL,
    dueDate DATETIME NOT NULL,
    createdBy INTEGER NOT NULL,
    teamId INTEGER NOT NULL,
    projectId INTEGER,
    assignedTo INTEGER,
    priority VARCHAR(20) DEFAULT 'MEDIUM',
    status VARCHAR(20) DEFAULT 'PENDING_APPROVAL',
    approvedBy INTEGER,
    approvedAt DATETIME,
    rejectionReason TEXT,
    expectedClosure DATETIME,
    actualClosure DATETIME,
    estimatedHours FLOAT,
    actualHours FLOAT,
    project VARCHAR(100),
    attachments TEXT DEFAULT '[]',
    comments TEXT DEFAULT '[]',
    tags TEXT DEFAULT '[]',
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Migrate data with category mapping
INSERT INTO tickets (
    id, title, description, type, category, assignedTeamId, dueDate, 
    createdBy, teamId, projectId, assignedTo, priority, status, 
    approvedBy, approvedAt, rejectionReason, expectedClosure, 
    actualClosure, estimatedHours, actualHours, project, 
    attachments, comments, tags, createdAt, updatedAt
)
SELECT 
    id, title, description, type, 
    CASE 
        WHEN category = 'technical' THEN 'Hardware'
        WHEN category = 'business' THEN 'Software'
        WHEN category = 'infrastructure' THEN 'Tools'
        WHEN category = 'security' THEN 'Cyber sec'
        WHEN category = 'performance' THEN 'Lab Support'
        WHEN category = 'ui/ux' THEN 'Tools'
        WHEN category = 'database' THEN 'Software'
        WHEN category = 'api' THEN 'Software'
        ELSE category
    END AS category, 
    assignedTeamId, dueDate, createdBy, teamId, projectId, assignedTo, 
    priority, status, approvedBy, approvedAt, rejectionReason, 
    expectedClosure, actualClosure, estimatedHours, actualHours, 
    project, attachments, comments, tags, createdAt, updatedAt
FROM tickets_backup;

-- Drop the backup table
DROP TABLE tickets_backup;

-- Recreate indexes
CREATE INDEX idx_tickets_teamId ON tickets(teamId);
CREATE INDEX idx_tickets_assignedTeamId ON tickets(assignedTeamId);
CREATE INDEX idx_tickets_createdBy ON tickets(createdBy);
CREATE INDEX idx_tickets_assignedTo ON tickets(assignedTo);
CREATE INDEX idx_tickets_status ON tickets(status);
CREATE INDEX idx_tickets_priority ON tickets(priority);

-- Verify the migration
SELECT category, COUNT(*) as count 
FROM tickets 
GROUP BY category; 