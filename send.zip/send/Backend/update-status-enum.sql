-- Update the status ENUM to include IN_REVIEW
-- First, create a new table with the updated ENUM
CREATE TABLE tickets_new (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    type VARCHAR(50) NOT NULL,
    category VARCHAR(50) NOT NULL CHECK (
        category IN (
            'Hardware',
            'Software', 
            'Tools',
            'Lab Support',
            'Purchase',
            'ASPICE',
            'Functional Safety',
            'Cyber sec'
        )
    ),
    assigned_team_id INTEGER NOT NULL,
    due_date DATETIME NOT NULL,
    created_by INTEGER NOT NULL,
    team_id INTEGER NOT NULL,
    project_id INTEGER,
    assigned_to INTEGER,
    priority VARCHAR(20) DEFAULT 'MEDIUM',
    status VARCHAR(20) DEFAULT 'PENDING_APPROVAL' CHECK (
        status IN (
            'PENDING_APPROVAL',
            'APPROVED',
            'IN_PROGRESS',
            'IN_REVIEW',
            'COMPLETED',
            'REJECTED'
        )
    ),
    approved_by INTEGER,
    approved_at DATETIME,
    rejection_reason TEXT,
    expected_closure DATETIME,
    actual_closure DATETIME,
    estimated_hours FLOAT,
    actual_hours FLOAT,
    project VARCHAR(100),
    attachments TEXT DEFAULT '[]',
    comments TEXT DEFAULT '[]',
    tags TEXT DEFAULT '[]',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Copy data from old table to new table
INSERT INTO tickets_new 
SELECT * FROM tickets;

-- Drop old table and rename new table
DROP TABLE tickets;
ALTER TABLE tickets_new RENAME TO tickets;

-- Recreate indexes
CREATE INDEX idx_tickets_team_id ON tickets(team_id);
CREATE INDEX idx_tickets_assigned_team_id ON tickets(assigned_team_id);
CREATE INDEX idx_tickets_created_by ON tickets(created_by);
CREATE INDEX idx_tickets_assigned_to ON tickets(assigned_to);
CREATE INDEX idx_tickets_status ON tickets(status);
CREATE INDEX idx_tickets_priority ON tickets(priority); 