const axios = require('axios');

const BASE_URL = 'http://localhost:5000/api';

async function testBasicActivation() {
  console.log('🔧 Testing Basic Activation/Deactivation System');
  console.log('==============================================');
  
  try {
    // Test server health
    console.log('\n1. Testing server health...');
    const health = await axios.get(`${BASE_URL}/health`);
    console.log('✅ Server is running:', health.data.status);
    
    // Test admin routes exist
    console.log('\n2. Testing admin routes...');
    try {
      await axios.get(`${BASE_URL}/admin/system-status`);
    } catch (error) {
      if (error.response?.status === 401) {
        console.log('✅ Admin routes are protected (401 Unauthorized)');
      } else {
        console.log('❌ Unexpected error:', error.response?.status);
      }
    }
    
    // Test archive service
    console.log('\n3. Testing archive service...');
    const ArchiveService = require('./services/archiveService');
    const stats = await ArchiveService.getArchiveStats();
    console.log('✅ Archive service working:');
    console.log(`   Total users: ${stats.users.total} (${stats.users.active} active, ${stats.users.archived} archived)`);
    console.log(`   Total teams: ${stats.teams.total} (${stats.teams.active} active, ${stats.teams.archived} archived)`);
    console.log(`   Total tickets: ${stats.tickets.total} (${stats.tickets.active} active, ${stats.tickets.archived} archived)`);
    console.log(`   Total projects: ${stats.projects.total} (${stats.projects.active} active, ${stats.projects.archived} archived)`);
    
    console.log('\n✅ Basic activation system tests passed!');
    
  } catch (error) {
    console.error('❌ Basic test failed:', error.message);
    throw error;
  }
}

// Run the test
if (require.main === module) {
  testBasicActivation().catch(console.error);
}

module.exports = testBasicActivation;