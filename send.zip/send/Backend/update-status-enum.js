const sqlite3 = require('sqlite3').verbose();
const fs = require('fs');
const path = require('path');

console.log('🔄 Updating ticket status ENUM to include IN_REVIEW...');

// Open the database
const db = new sqlite3.Database('./database.sqlite', (err) => {
  if (err) {
    console.error('❌ Error opening database:', err.message);
    process.exit(1);
  }
  console.log('✅ Connected to the SQLite database.');
});

// Read the migration SQL
const migrationSql = fs.readFileSync(path.join(__dirname, 'update-status-enum.sql'), 'utf8');

// Run the migration
db.exec(migrationSql, (err) => {
  if (err) {
    console.error('❌ Migration failed:', err.message);
    process.exit(1);
  }
  console.log('✅ Status ENUM updated successfully!');
  
  // Verify the migration
  db.get("SELECT COUNT(*) as count FROM tickets", (err, row) => {
    if (err) {
      console.error('❌ Error verifying migration:', err.message);
    } else {
      console.log(`📊 Total tickets in database: ${row.count}`);
    }
    
    // Close the database connection
    db.close((err) => {
      if (err) {
        console.error('❌ Error closing database:', err.message);
      } else {
        console.log('✅ Database connection closed.');
        console.log('🎉 Migration completed successfully!');
      }
    });
  });
}); 