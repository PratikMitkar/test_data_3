const sqlite3 = require('sqlite3').verbose();
const fs = require('fs');
const path = require('path');

// Open the database
const db = new sqlite3.Database('./database.sqlite', (err) => {
  if (err) {
    console.error('Error opening database', err);
    process.exit(1);
  }
  console.log('Connected to the SQLite database.');
});

// Read the migration SQL
const migrationSql = fs.readFileSync(path.join(__dirname, 'update-ticket-categories.sql'), 'utf8');

// Run the migration
db.exec(migrationSql, (err) => {
  if (err) {
    console.error('Migration failed:', err);
    process.exit(1);
  }
  console.log('🎉 Ticket category migration completed successfully!');
  
  // Verify migration results
  db.all('SELECT category, COUNT(*) as count FROM tickets GROUP BY category', (err, rows) => {
    if (err) {
      console.error('Error verifying migration:', err);
    } else {
      console.log('\n📊 Ticket Category Distribution:');
      rows.forEach(row => {
        console.log(`${row.category}: ${row.count} tickets`);
      });
    }
    
    // Close the database connection
    db.close((err) => {
      if (err) {
        console.error('Error closing database', err);
      }
      console.log('Database connection closed.');
    });
  });
}); 