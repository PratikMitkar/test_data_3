# Frontend Archive System Implementation

## Overview

This document describes the comprehensive frontend implementation of the User/Team Activation/Deactivation and Archive System. The frontend provides a complete user interface for managing user lifecycle and viewing archived content.

## Architecture

### Context-Based State Management
```
App.jsx
├── AuthProvider (User Authentication)
├── ArchiveProvider (Archive State Management)
└── NotificationProvider (Notifications)
```

### Component Hierarchy
```
Layout
├── Navigation (with Archive Dashboard link)
├── Archive Warning Banners
└── Page Components
    ├── Users (with activation controls)
    ├── Teams (with activation controls)
    ├── Tickets (with archive filtering)
    ├── Projects (with archive filtering)
    └── ArchiveDashboard (admin only)
```

## Key Components

### 1. Archive Service (`services/archiveService.js`)

**Purpose**: Centralized API communication for archive operations

**Key Methods**:
- `getArchivedContent(options)` - Fetch archived tickets/projects
- `getSystemStatus()` - Get system-wide statistics
- `updateUserStatus(userId, isActive)` - Activate/deactivate users
- `updateTeamStatus(teamId, isActive)` - Activate/deactivate teams
- `updateAdminStatus(adminId, isActive)` - Activate/deactivate admins
- `getTickets(options, includeArchived)` - Fetch tickets with archive filtering
- `getProjects(options, includeArchived)` - Fetch projects with archive filtering

### 2. Archive Context (`contexts/ArchiveContext.jsx`)

**Purpose**: Global state management for archive functionality

**State Variables**:
- `showArchived` - Toggle for archive visibility
- `systemStatus` - System-wide statistics
- `archivedContent` - Cached archived content
- `loading` - Loading state for operations

**Key Functions**:
- `fetchSystemStatus()` - Refresh system statistics
- `fetchArchivedContent()` - Load archived content
- `updateUserStatus()` - Update user activation status
- `updateTeamStatus()` - Update team activation status
- `getTickets()` - Get tickets with archive filtering
- `getProjects()` - Get projects with archive filtering
- `shouldShowArchiveWarning()` - Check if warning should be displayed

### 3. Archive Dashboard (`pages/ArchiveDashboard.jsx`)

**Purpose**: Admin interface for viewing archived content and system status

**Features**:
- System status overview with statistics cards
- Tabbed interface for different content types
- Search and filter functionality for archived content
- Real-time data refresh capabilities
- Role-based access control

**Tabs**:
- **Overview**: System statistics and quick actions
- **Archived Tickets**: List of archived tickets with details
- **Archived Projects**: List of archived projects with details

### 4. Enhanced User Management (`pages/Users.jsx`)

**New Features**:
- Activation/deactivation toggle buttons
- Confirmation dialogs with cascade warnings
- Visual status indicators
- Role-based permission checks
- Integration with archive context

**User Actions**:
- Activate/deactivate users, teams, admins, super admins
- Cascade deactivation warnings
- Real-time status updates

### 5. Enhanced Content Pages

#### Tickets Page (`pages/Tickets.jsx`)
- Archive warning banner for deactivated users
- Archive filter toggle (Active Only / Include Archived)
- Link to Archive Dashboard for admins
- Integration with archive context for data fetching

#### Projects Page (`pages/Projects.jsx`)
- Similar archive functionality as Tickets
- Archive filtering controls
- Warning banners for deactivated accounts

#### Teams Page (`pages/Teams.jsx`)
- Team activation/deactivation controls
- Confirmation dialogs with member impact warnings
- Archive warning banners

## User Interface Features

### 1. Archive Warning Banners

**Purpose**: Inform users when their account or team is deactivated

**Appearance**: Orange warning banner with alert icon

**Trigger**: Shown when `shouldShowArchiveWarning()` returns true

**Message**: "Your account or team has been deactivated. Some content may be hidden from view."

### 2. Archive Filter Controls

**Purpose**: Allow admins to toggle between active and archived content

**Components**:
- Filter icon and label
- Toggle buttons (Active Only / Include Archived)
- Link to Archive Dashboard

**Visibility**: Only shown to admin and super admin users

### 3. Activation Controls

**Purpose**: Provide interface for activating/deactivating users and teams

**Components**:
- Toggle buttons with appropriate icons (UserCheck/UserX)
- Confirmation dialogs with impact warnings
- Visual feedback for status changes

**Permissions**:
- Super Admin: Can manage all user types
- Admin: Can manage users and teams under their control
- Team Manager: Can manage users in their team

### 4. Navigation Integration

**Archive Dashboard Link**: Added to main navigation for admin users

**Icon**: Archive icon from Lucide React

**Visibility**: Only shown to admin and super admin roles

## State Management Flow

### 1. Archive Visibility Toggle
```javascript
// User clicks toggle button
setShowArchived(!showArchived)
↓
// Context updates state
showArchived = newValue
↓
// Components re-fetch data
getTickets(options) // with new archive setting
↓
// UI updates with filtered content
```

### 2. User Status Update
```javascript
// User clicks activation button
updateUserStatus(userId, newStatus)
↓
// API call to backend
PUT /api/admin/user/:id/status
↓
// Success response
toast.success(message)
↓
// Local state update
setUsers(updatedUsers)
↓
// System status refresh (if applicable)
fetchSystemStatus()
```

### 3. Archive Content Loading
```javascript
// Admin navigates to Archive Dashboard
fetchArchivedContent()
↓
// API call to backend
GET /api/admin/archived
↓
// Update context state
setArchivedContent(data)
↓
// UI renders archived content
```

## Error Handling

### 1. API Error Handling
- All API calls wrapped in try-catch blocks
- User-friendly error messages via toast notifications
- Graceful degradation for failed operations
- Loading states during operations

### 2. Permission Errors
- Role-based access checks before operations
- Clear error messages for insufficient permissions
- Redirect to appropriate pages for unauthorized access

### 3. Network Errors
- Retry mechanisms for failed requests
- Offline state handling
- Connection status indicators

## Security Features

### 1. Role-Based Access Control
- Archive Dashboard only accessible to admins
- User management controls based on role hierarchy
- System status only visible to super admins

### 2. Confirmation Dialogs
- Confirmation required for all destructive actions
- Clear warnings about cascade effects
- Prevention of accidental deactivations

### 3. Self-Protection
- Users cannot deactivate themselves
- Appropriate warnings for cascade operations
- Clear indication of operation impact

## Performance Optimizations

### 1. Context Optimization
- Selective re-renders using React context
- Memoized functions to prevent unnecessary re-computations
- Efficient state updates

### 2. Data Fetching
- Pagination for large datasets
- Search and filter on backend
- Caching of frequently accessed data

### 3. UI Optimizations
- Loading states for better user experience
- Debounced search inputs
- Optimistic updates where appropriate

## Testing

### 1. Archive Test Component (`components/ArchiveTest.jsx`)

**Purpose**: Comprehensive testing interface for archive functionality

**Tests**:
- Archive context availability
- User authentication status
- Role-based access permissions
- Archive state management
- System status availability
- Permission checks
- Archive warning logic

**Usage**: Navigate to test component to verify functionality

### 2. Manual Testing Checklist

**User Management**:
- [ ] Can activate/deactivate users
- [ ] Confirmation dialogs work
- [ ] Status updates reflect in UI
- [ ] Cascade warnings appear

**Archive Filtering**:
- [ ] Toggle between active/archived content
- [ ] Archived content hidden by default
- [ ] Filter controls only visible to admins

**Archive Dashboard**:
- [ ] System status displays correctly
- [ ] Archived content loads properly
- [ ] Search and filter work
- [ ] Only accessible to admins

**Warning Banners**:
- [ ] Appear for deactivated users/teams
- [ ] Contain appropriate messaging
- [ ] Styled correctly

## Integration Points

### 1. Backend API Integration
- All archive operations use backend API endpoints
- Proper error handling for API responses
- Consistent data format expectations

### 2. Authentication Integration
- Uses existing AuthContext for user information
- Respects role-based permissions
- Handles authentication state changes

### 3. Notification Integration
- Uses existing toast notification system
- Consistent messaging patterns
- Appropriate notification types

## Deployment Considerations

### 1. Environment Configuration
- API endpoints configurable via environment variables
- Feature flags for archive functionality
- Role-based feature toggles

### 2. Browser Compatibility
- Modern browser support (ES6+)
- Responsive design for mobile devices
- Accessibility compliance

### 3. Performance Monitoring
- Error tracking for archive operations
- Performance metrics for data loading
- User interaction analytics

## Future Enhancements

### 1. Advanced Filtering
- Date range filters for archived content
- Advanced search capabilities
- Export functionality for archived data

### 2. Bulk Operations
- Bulk activation/deactivation
- Batch operations for multiple users
- Progress indicators for bulk operations

### 3. Audit Trail
- History of activation/deactivation actions
- User activity logs
- Change tracking and rollback capabilities

### 4. Real-time Updates
- WebSocket integration for real-time status updates
- Live notifications for status changes
- Real-time system status monitoring

## Conclusion

The frontend archive system provides a comprehensive, user-friendly interface for managing user lifecycle and archived content. It integrates seamlessly with the backend API while providing excellent user experience through proper state management, error handling, and role-based access control.

The system is designed to be scalable, maintainable, and secure, with proper separation of concerns and modern React patterns. The implementation follows best practices for state management, API integration, and user interface design.