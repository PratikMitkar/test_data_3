// Centralized Theme Configuration
// This file contains all the styling constants used throughout the application
// Any changes here will be reflected across the entire webapp

import { masterColors, getStatusColors, getPriorityColors, getButtonColors } from '../config/colors';

export const theme = {
  // Color Palette
  colors: {
    primary: {
      50: '#f0f9ff',
      100: '#e0f2fe',
      200: '#bae6fd',
      300: '#7dd3fc',
      400: '#38bdf8',
      500: '#0ea5e9',
      600: '#0284c7',
      700: '#0369a1',
      800: '#075985',
      900: '#0c4a6e',
    },
    gray: {
      50: '#f9fafb',
      100: '#f3f4f6',
      200: '#e5e7eb',
      300: '#d1d5db',
      400: '#9ca3af',
      500: '#6b7280',
      600: '#4b5563',
      700: '#374151',
      800: '#1f2937',
      900: '#111827',
    },
    neutral: {
      50: '#fafafa',
      100: '#f5f5f5',
      200: '#e5e5e5',
      300: '#d4d4d4',
      400: '#a3a3a3',
      500: '#737373',
      600: '#525252',
      700: '#404040',
      800: '#262626',
      900: '#171717',
    },
    success: {
      50: '#f0fdf4',
      100: '#dcfce7',
      200: '#bbf7d0',
      300: '#86efac',
      400: '#4ade80',
      500: '#22c55e',
      600: '#16a34a',
      700: '#15803d',
      800: '#166534',
      900: '#14532d',
    },
    warning: {
      50: '#fffbeb',
      100: '#fef3c7',
      200: '#fde68a',
      300: '#fcd34d',
      400: '#fbbf24',
      500: '#f59e0b',
      600: '#d97706',
      700: '#b45309',
      800: '#92400e',
      900: '#78350f',
    },
    error: {
      50: '#fef2f2',
      100: '#fee2e2',
      200: '#fecaca',
      300: '#fca5a5',
      400: '#f87171',
      500: '#ef4444',
      600: '#dc2626',
      700: '#b91c1c',
      800: '#991b1b',
      900: '#7f1d1d',
    },
    info: {
      50: '#eff6ff',
      100: '#dbeafe',
      200: '#bfdbfe',
      300: '#93c5fd',
      400: '#60a5fa',
      500: '#3b82f6',
      600: '#2563eb',
      700: '#1d4ed8',
      800: '#1e40af',
      900: '#1e3a8a',
    }
  },

  // Typography
  typography: {
    fontFamily: {
      sans: ['Inter', 'system-ui', 'sans-serif'],
    },
    fontSize: {
      xs: '0.75rem',
      sm: '0.875rem',
      base: '1rem',
      lg: '1.125rem',
      xl: '1.25rem',
      '2xl': '1.5rem',
      '3xl': '1.875rem',
      '4xl': '2.25rem',
    },
    fontWeight: {
      normal: '400',
      medium: '500',
      semibold: '600',
      bold: '700',
    }
  },

  // Spacing
  spacing: {
    xs: '0.25rem',
    sm: '0.5rem',
    md: '1rem',
    lg: '1.5rem',
    xl: '2rem',
    '2xl': '3rem',
    '3xl': '4rem',
  },

  // Border Radius
  borderRadius: {
    sm: '0.25rem',
    md: '0.375rem',
    lg: '0.5rem',
    xl: '0.75rem',
    '2xl': '1rem',
    full: '9999px',
  },

  // Shadows
  shadows: {
    sm: '0 1px 2px 0 rgb(0 0 0 / 0.05)',
    md: '0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)',
    lg: '0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1)',
    xl: '0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1)',
  }
};

// Component Styles - Now using Master Colors
export const componentStyles = {
  // Page Layout
  page: {
    container: "max-w-7xl mx-auto",
    header: "flex flex-col gap-3 p-4",
    title: `text-[${masterColors.text.primary}] tracking-light text-[32px] font-bold leading-tight`,
    subtitle: `text-[${masterColors.text.secondary}] text-sm font-normal leading-normal`,
    content: "px-4 py-3"
  },

  // Cards
  card: {
    base: `rounded-xl border border-[${masterColors.background.border}] bg-[${masterColors.background.secondary}] overflow-hidden`,
    header: `p-6 border-b border-[${masterColors.background.border}]`,
    content: "p-6",
    footer: `p-6 border-t border-[${masterColors.background.border}] bg-[${masterColors.background.tertiary}]`
  },

  // Buttons
  button: {
    base: "flex items-center justify-center rounded-xl font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-black disabled:opacity-50",
    sizes: {
      sm: "h-8 px-3 text-xs",
      md: "h-10 px-4 text-sm",
      lg: "h-12 px-6 text-base"
    },
    variants: {
      primary: "bg-black text-white hover:bg-gray-800",
      secondary: "border border-[#dbdbdb] bg-white text-[#141414] hover:bg-neutral-50",
      success: "bg-green-600 text-white hover:bg-green-700",
      warning: "bg-yellow-600 text-white hover:bg-yellow-700",
      error: "bg-red-600 text-white hover:bg-red-700",
      info: "bg-blue-600 text-white hover:bg-blue-700"
    }
  },

  // Form Elements
  form: {
    label: "block text-sm font-medium text-[#141414] mb-2",
    input: "flex h-10 w-full rounded-xl border border-[#dbdbdb] bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-black",
    textarea: "flex w-full rounded-xl border border-[#dbdbdb] bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-black",
    select: "flex h-10 w-full rounded-xl border border-[#dbdbdb] bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-black",
    error: "text-red-500 text-sm mt-1"
  },

  // Tables
  table: {
    container: "rounded-xl border border-[#dbdbdb] bg-white overflow-hidden",
    header: "bg-neutral-50 border-b border-[#dbdbdb]",
    headerCell: "px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider",
    row: "border-b border-[#dbdbdb] hover:bg-neutral-50 transition-colors",
    cell: "px-6 py-4 whitespace-nowrap text-sm text-[#141414]"
  },

  // Badges/Status
  badge: {
    base: "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium",
    variants: {
      success: "bg-green-100 text-green-800",
      warning: "bg-yellow-100 text-yellow-800",
      error: "bg-red-100 text-red-800",
      info: "bg-blue-100 text-blue-800",
      primary: "bg-gray-100 text-gray-800",
      neutral: "bg-neutral-100 text-neutral-800"
    }
  },

  // Status specific badges
  status: {
    'PENDING_APPROVAL': { class: 'bg-yellow-100 text-yellow-800', text: 'Pending Approval' },
    'APPROVED': { class: 'bg-blue-100 text-blue-800', text: 'Approved' },
    'IN_PROGRESS': { class: 'bg-purple-100 text-purple-800', text: 'In Progress' },
    'IN_REVIEW': { class: 'bg-orange-100 text-orange-800', text: 'In Review' },
    'COMPLETED': { class: 'bg-green-100 text-green-800', text: 'Completed' },
    'REJECTED': { class: 'bg-red-100 text-red-800', text: 'Rejected' }
  },

  // Priority specific badges
  priority: {
    'LOW': { class: 'bg-green-100 text-green-800', text: 'Low' },
    'MEDIUM': { class: 'bg-yellow-100 text-yellow-800', text: 'Medium' },
    'HIGH': { class: 'bg-orange-100 text-orange-800', text: 'High' },
    'URGENT': { class: 'bg-red-100 text-red-800', text: 'Urgent' },
    'CRITICAL': { class: 'bg-purple-100 text-purple-800', text: 'Critical' }
  },

  // Loading States
  loading: {
    spinner: "animate-spin rounded-full border-b-2 border-primary-600",
    container: "flex items-center justify-center",
    sizes: {
      sm: "h-4 w-4",
      md: "h-8 w-8",
      lg: "h-12 w-12",
      xl: "h-32 w-32"
    }
  },

  // Modals
  modal: {
    overlay: "fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50",
    container: "bg-white rounded-xl max-w-md w-full mx-4 max-h-[90vh] overflow-y-auto",
    header: "p-6 border-b border-[#dbdbdb]",
    content: "p-6",
    footer: "p-6 border-t border-[#dbdbdb] flex justify-end space-x-3"
  },

  // Filters
  filters: {
    container: "bg-white rounded-xl border border-[#dbdbdb] p-4 mb-6",
    grid: "grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4",
    item: "flex flex-col"
  },

  // Pagination
  pagination: {
    container: "flex items-center justify-between px-4 py-3 bg-white border-t border-[#dbdbdb]",
    info: "text-sm text-neutral-500",
    buttons: "flex space-x-2",
    button: "px-3 py-1 text-sm border border-[#dbdbdb] rounded-lg hover:bg-neutral-50 disabled:opacity-50"
  }
};

// Utility Functions - Now using Master Colors
export const getStatusBadge = (status) => {
  return getStatusColors(status);
};

export const getPriorityBadge = (priority) => {
  return getPriorityColors(priority);
};

export const getButtonClasses = (variant = 'primary', size = 'md') => {
  const buttonColors = getButtonColors(variant);
  const sizeClasses = componentStyles.button.sizes[size];
  return `${buttonColors.className} ${sizeClasses}`;
};

export const getLoadingSpinner = (size = 'md') => {
  return `${componentStyles.loading.spinner} ${componentStyles.loading.sizes[size]}`;
};

// Export master colors for direct use
export { masterColors, getStatusColors, getPriorityColors, getButtonColors };

export default theme;