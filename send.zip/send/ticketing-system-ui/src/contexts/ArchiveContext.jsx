import { createContext, useContext, useState, useEffect } from 'react';
import { useAuth } from './AuthContext';
import ArchiveService from '../services/archiveService';
import toast from 'react-hot-toast';

const ArchiveContext = createContext();

export const useArchive = () => {
    const context = useContext(ArchiveContext);
    if (!context) {
        throw new Error('useArchive must be used within an ArchiveProvider');
    }
    return context;
};

export const ArchiveProvider = ({ children }) => {
    const { user, isAdmin, isSuperAdmin } = useAuth();
    const [showArchived, setShowArchived] = useState(false);
    const [systemStatus, setSystemStatus] = useState(null);
    const [archivedContent, setArchivedContent] = useState({
        tickets: { tickets: [], pagination: {} },
        projects: { projects: [], pagination: {} }
    });
    const [loading, setLoading] = useState(false);

    // Fetch system status for admins
    const fetchSystemStatus = async () => {
        if (!isSuperAdmin()) return;

        try {
            const status = await ArchiveService.getSystemStatus();
            setSystemStatus(status.systemStatus);
        } catch (error) {
            console.error('Failed to fetch system status:', error);
        }
    };

    // Fetch archived content
    const fetchArchivedContent = async (options = {}) => {
        if (!isAdmin()) return;

        try {
            setLoading(true);
            const archived = await ArchiveService.getArchivedContent(options);
            setArchivedContent(archived.archived || {
                tickets: { tickets: [], pagination: {} },
                projects: { projects: [], pagination: {} }
            });
        } catch (error) {
            console.error('Failed to fetch archived content:', error);
            toast.error('Failed to load archived content');
        } finally {
            setLoading(false);
        }
    };

    // Update user status
    const updateUserStatus = async (userId, isActive) => {
        try {
            const result = await ArchiveService.updateUserStatus(userId, isActive);
            toast.success(result.message);

            // Refresh system status if available
            if (isSuperAdmin()) {
                await fetchSystemStatus();
            }

            return result;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to update user status';
            toast.error(message);
            throw error;
        }
    };

    // Update team status
    const updateTeamStatus = async (teamId, isActive) => {
        try {
            const result = await ArchiveService.updateTeamStatus(teamId, isActive);
            toast.success(result.message);

            // Refresh system status if available
            if (isSuperAdmin()) {
                await fetchSystemStatus();
            }

            return result;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to update team status';
            toast.error(message);
            throw error;
        }
    };

    // Update admin status
    const updateAdminStatus = async (adminId, isActive) => {
        try {
            const result = await ArchiveService.updateAdminStatus(adminId, isActive);
            toast.success(result.message);

            // Refresh system status if available
            if (isSuperAdmin()) {
                await fetchSystemStatus();
            }

            return result;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to update admin status';
            toast.error(message);
            throw error;
        }
    };

    // Update super admin status
    const updateSuperAdminStatus = async (superAdminId, isActive) => {
        try {
            const result = await ArchiveService.updateSuperAdminStatus(superAdminId, isActive);
            toast.success(result.message);

            // Refresh system status if available
            if (isSuperAdmin()) {
                await fetchSystemStatus();
            }

            return result;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to update super admin status';
            toast.error(message);
            throw error;
        }
    };

    // Get tickets with archive filtering
    const getTickets = async (options = {}) => {
        try {
            return await ArchiveService.getTickets(options, showArchived);
        } catch (error) {
            console.error('Failed to fetch tickets:', error);
            throw error;
        }
    };

    // Get projects with archive filtering
    const getProjects = async (options = {}) => {
        try {
            return await ArchiveService.getProjects(options, showArchived);
        } catch (error) {
            console.error('Failed to fetch projects:', error);
            throw error;
        }
    };

    // Get teams with archive filtering
    const getTeams = async (options = {}) => {
        try {
            return await ArchiveService.getTeams(options, showArchived);
        } catch (error) {
            console.error('Failed to fetch teams:', error);
            throw error;
        }
    };

    // Check if user should see archived content warning
    const shouldShowArchiveWarning = () => {
        return user && (!user.isActive || (user.team && !user.team.isActive));
    };

    // Initialize system status on mount for admins
    useEffect(() => {
        if (isSuperAdmin()) {
            fetchSystemStatus();
        }
    }, [user]);

    const value = {
        showArchived,
        setShowArchived,
        systemStatus,
        archivedContent,
        loading,
        fetchSystemStatus,
        fetchArchivedContent,
        updateUserStatus,
        updateTeamStatus,
        updateAdminStatus,
        updateSuperAdminStatus,
        getTickets,
        getProjects,
        getTeams,
        shouldShowArchiveWarning,
        // Helper functions
        canManageUsers: () => isAdmin(),
        canViewArchived: () => isAdmin(),
        canViewSystemStatus: () => isSuperAdmin()
    };

    return (
        <ArchiveContext.Provider value={value}>
            {children}
        </ArchiveContext.Provider>
    );
};