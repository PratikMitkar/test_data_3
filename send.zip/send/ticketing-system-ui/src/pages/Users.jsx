import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useArchive } from '../contexts/ArchiveContext';
import axios from 'axios';
import toast from 'react-hot-toast';
import { getApiUrl } from '../config/api';
import { componentStyles, iconColors, getLoadingSpinner } from '../theme';
import {
  Users as UsersIcon,
  UserPlus,
  Search,
  Edit,
  Trash2,
  User,
  Mail,
  Building,
  Shield,
  Crown,
  UserCheck,
  UserX,
  Archive,
  AlertTriangle
} from 'lucide-react';

const UsersPage = () => {
  const { user, isSuperAdmin, isAdmin } = useAuth();
  const { updateUserStatus, updateTeamStatus, updateAdminStatus, updateSuperAdminStatus, showArchived, setShowArchived } = useArchive();
  const [users, setUsers] = useState([]);
  const [teams, setTeams] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [createType, setCreateType] = useState(''); // 'admin' or 'member'
  const [currentUser, setCurrentUser] = useState(null);
  const [confirmAction, setConfirmAction] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    teamId: '',
    username: ''
  });
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    fetchData();
  }, [showArchived]);

  const fetchData = async () => {
    try {
      setLoading(true);
      
      // Fetch all user types and teams with archive filtering
      const [usersRes, teamsRes] = await Promise.all([
        axios.get(getApiUrl('/api/users/all'), {
          params: { includeArchived: showArchived }
        }),
        axios.get(getApiUrl('/api/users/teams'), {
          params: { includeArchived: showArchived }
        })
      ]);
      
      setUsers(usersRes.data.users || []);
      setTeams(teamsRes.data || []);
    } catch (error) {
      console.error('Error fetching data:', error);
      toast.error('Failed to fetch data');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateUser = async (e) => {
    e.preventDefault();
    
    if (!formData.name || !formData.email || !formData.password) {
      toast.error('Please fill in all required fields');
      return;
    }

    // For members, teamId is required
    if (createType === 'member' && !formData.teamId) {
      toast.error('Please select a team for the member');
      return;
    }

    // For members, username is required
    if (createType === 'member' && !formData.username) {
      toast.error('Please provide a username for the member');
      return;
    }

    try {
      setSubmitting(true);
      
      if (createType === 'admin') {
        // Create admin (only super admin can do this)
        await axios.post(getApiUrl('/api/auth/register/admin'), {
          name: formData.name,
          email: formData.email,
          password: formData.password,
          superAdminId: user.id // Add the current super admin's ID
        });
        toast.success('Admin created successfully');
      } else if (createType === 'member') {
        // Create member (team can do this)
        await axios.post(getApiUrl('/api/auth/register/user'), {
          username: formData.username,
          name: formData.name,
          email: formData.email,
          password: formData.password,
          teamId: formData.teamId
        });
        toast.success('Member created successfully');
      }
      
      setShowCreateModal(false);
      setFormData({
        name: '',
        email: '',
        password: '',
        teamId: '',
        username: ''
      });
      setCreateType('');
      fetchData();
    } catch (error) {
      console.error('Error creating user:', error);
      const message = error.response?.data?.error || 'Failed to create user';
      toast.error(message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteUser = async (userId, userType) => {
    if (!window.confirm('Are you sure you want to delete this user?')) return;

    try {
      await axios.delete(getApiUrl(`/api/users/${userId}`));
      toast.success('User deleted successfully');
      fetchData();
    } catch (error) {
      console.error('Error deleting user:', error);
      toast.error('Failed to delete user');
    }
  };

  const handleToggleUserStatus = (userId, currentStatus, userRole) => {
    const action = currentStatus ? 'deactivate' : 'activate';
    const confirmMessage = currentStatus 
      ? `Are you sure you want to deactivate this ${getRoleLabel(userRole).toLowerCase()}? This will hide all their content.`
      : `Are you sure you want to activate this ${getRoleLabel(userRole).toLowerCase()}?`;
    
    setConfirmAction({
      message: confirmMessage,
      onConfirm: () => executeToggleUserStatus(userId, currentStatus, userRole)
    });
    setShowConfirmModal(true);
  };

  const executeToggleUserStatus = async (userId, currentStatus, userRole) => {
    try {
      let result;
      switch (userRole) {
        case 'super_admin':
          result = await updateSuperAdminStatus(userId, !currentStatus);
          break;
        case 'admin':
          result = await updateAdminStatus(userId, !currentStatus);
          break;
        case 'team':
          result = await updateTeamStatus(userId, !currentStatus);
          break;
        case 'user':
          result = await updateUserStatus(userId, !currentStatus);
          break;
        default:
          throw new Error('Unknown user role');
      }
      
      // Update local state - match both ID and role to avoid updating wrong users
      setUsers(users.map(u => 
        u.id === userId && u.role === userRole ? { ...u, isActive: !currentStatus } : u
      ));
      
    } catch (error) {
      console.error('Error toggling user status:', error);
      // Error is already handled by the archive context
    }
  };

  const handleEditUser = (user) => {
    setCurrentUser(user);
    setFormData({
      name: user.name || user.teamName || '',
      email: user.email || '',
      password: '', // Don't pre-fill password for security
      teamId: user.teamId || '',
      username: user.username || user.managerName || ''
    });
    setShowEditModal(true);
  };

  const handleUpdateUser = async (e) => {
    e.preventDefault();
    
    if (!formData.name || !formData.email) {
      toast.error('Please fill in all required fields');
      return;
    }

    try {
      setSubmitting(true);
      
      const updateData = {
        name: formData.name,
        email: formData.email,
        ...(formData.password && { password: formData.password }), // Only include password if provided
        ...(formData.username && { username: formData.username }),
        ...(formData.teamId && { teamId: formData.teamId })
      };

      // Update user based on role
      let endpoint;
      switch (currentUser.role) {
        case 'super_admin':
          endpoint = `/api/admin/super-admin/${currentUser.id}`;
          break;
        case 'admin':
          endpoint = `/api/admin/admin/${currentUser.id}`;
          break;
        case 'team':
          endpoint = `/api/admin/team/${currentUser.id}`;
          break;
        case 'user':
          endpoint = `/api/users/${currentUser.id}`;
          break;
        default:
          throw new Error('Unknown user role');
      }

      await axios.put(getApiUrl(endpoint), updateData);
      toast.success('User updated successfully');
      setShowEditModal(false);
      setCurrentUser(null);
      setFormData({
        name: '',
        email: '',
        password: '',
        teamId: '',
        username: ''
      });
      fetchData();
    } catch (error) {
      console.error('Error updating user:', error);
      const message = error.response?.data?.error || 'Failed to update user';
      toast.error(message);
    } finally {
      setSubmitting(false);
    }
  };

  const getRoleIcon = (role) => {
    switch (role) {
      case 'super_admin':
        return <Crown className={`h-4 w-4 ${iconColors.roles.super_admin}`} />;
      case 'admin':
        return <Shield className={`h-4 w-4 ${iconColors.roles.admin}`} />;
      case 'team':
        return <Building className={`h-4 w-4 ${iconColors.roles.team}`} />;
      case 'user':
        return <User className={`h-4 w-4 ${iconColors.roles.user}`} />;
      default:
        return <User className={`h-4 w-4 ${iconColors.roles.user}`} />;
    }
  };

  const getRoleLabel = (role) => {
    switch (role) {
      case 'super_admin':
        return 'Super Admin';
      case 'admin':
        return 'Admin';
      case 'team':
        return 'Team Manager';
      case 'user':
        return 'Member';
      default:
        return 'Unknown';
    }
  };

  const filteredUsers = users.filter(user =>
    user.name?.toLowerCase().includes(search.toLowerCase()) ||
    user.email?.toLowerCase().includes(search.toLowerCase()) ||
    user.username?.toLowerCase().includes(search.toLowerCase()) ||
    user.teamName?.toLowerCase().includes(search.toLowerCase())
  );

  const canCreateAdmin = isSuperAdmin();
  const canCreateMember = isAdmin() || user?.role === 'team';

  return (
    <div>
      {/* Header */}
      <div className="flex flex-wrap justify-between gap-3 p-4">
        <div className="flex min-w-72 flex-col gap-3">
          <p className="text-[#141414] tracking-light text-[32px] font-bold leading-tight">User Management</p>
          <p className="text-neutral-500 text-sm font-normal leading-normal">Manage system users and their permissions</p>
        </div>
        <div className="flex gap-2">
          {canCreateAdmin && (
            <button
              onClick={() => {
                setCreateType('admin');
                setShowCreateModal(true);
              }}
              className="flex max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-xl h-10 bg-black text-neutral-50 gap-2 text-sm font-bold leading-normal tracking-[0.015em] min-w-0 px-4 hover:bg-neutral-800 transition-colors"
            >
              <Shield className={`h-5 w-5 text-neutral-50`} />
              <span className="truncate">Create Admin</span>
            </button>
          )}
          {canCreateMember && (
            <button
              onClick={() => {
                setCreateType('member');
                setShowCreateModal(true);
              }}
              className="flex max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-xl h-10 border border-[#dbdbdb] bg-neutral-50 text-[#141414] gap-2 text-sm font-bold leading-normal tracking-[0.015em] min-w-0 px-4 hover:bg-neutral-100 transition-colors"
            >
              <UserPlus className={`h-5 w-5 text-[#141414]`} />
              <span className="truncate">Create Member</span>
            </button>
          )}
        </div>
      </div>

      {/* Search */}
      <div className="px-4 py-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-[#404040]" />
          <input
            type="text"
            placeholder="Search users..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className={`${componentStyles.form.input} pl-10`}
          />
        </div>
      </div>

      {/* Global Archive Toggle - Only for Admins */}
      {isAdmin() && (
        <div className="px-4 py-3">
          <div className="flex items-center justify-between bg-neutral-50 rounded-xl p-4 border border-[#dbdbdb]">
            <div className="flex items-center space-x-3">
              <div className="flex items-center justify-center rounded-full bg-neutral-200 p-2">
                <Archive className="h-4 w-4 text-[#404040]" />
              </div>
              <div>
                <h3 className="text-sm font-medium text-[#141414]">Archive Filter</h3>
                <p className="text-xs text-neutral-500">
                  {showArchived ? 'Showing ONLY archived/deactivated content' : 'Showing ONLY active content'}
                </p>
              </div>
            </div>
            <button
              onClick={() => setShowArchived(!showArchived)}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                showArchived ? 'bg-black' : 'bg-neutral-300'
              }`}
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                  showArchived ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>
          {showArchived && (
            <div className="mt-2 p-3 bg-orange-50 border border-orange-200 rounded-xl">
              <div className="flex items-center">
                <div className="flex items-center justify-center rounded-full bg-orange-200 p-1 mr-3">
                  <AlertTriangle className="h-4 w-4 text-orange-600" />
                </div>
                <div>
                  <p className="text-sm font-medium text-orange-800">Archive Mode Active</p>
                  <p className="text-xs text-orange-700">
                    You're viewing archived/deactivated content across the entire system.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Users Table */}
      <div className="px-4 py-3 @container">
        <div className="flex overflow-hidden rounded-xl border border-[#dbdbdb] bg-neutral-50">
          {loading ? (
            <div className="flex items-center justify-center h-64 w-full">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div>
            </div>
          ) : filteredUsers.length === 0 ? (
            <div className="text-center py-12 w-full">
              <UsersIcon className="mx-auto h-12 w-12 text-neutral-400" />
              <h3 className="mt-2 text-sm font-medium text-[#141414]">No users found</h3>
              <p className="mt-1 text-sm text-neutral-500">
                {search ? 'Try adjusting your search.' : 'Get started by adding a new user.'}
              </p>
            </div>
          ) : (
            <table className="flex-1">
              <thead>
                <tr className="bg-neutral-50">
                  <th className="table-column-120 px-4 py-3 text-left text-[#141414] w-[400px] text-sm font-medium leading-normal">
                    User
                  </th>
                  <th className="table-column-240 px-4 py-3 text-left text-[#141414] w-60 text-sm font-medium leading-normal">
                    Role
                  </th>
                  <th className="table-column-360 px-4 py-3 text-left text-[#141414] w-60 text-sm font-medium leading-normal">
                    Team
                  </th>
                  <th className="table-column-480 px-4 py-3 text-left text-[#141414] w-60 text-sm font-medium leading-normal">
                    Status
                  </th>
                  <th className="table-column-600 px-4 py-3 text-left text-[#141414] w-20 text-sm font-medium leading-normal">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody>
                {filteredUsers.map((user) => (
                  <tr key={`${user.role}-${user.id}`} className="border-t border-t-[#dbdbdb]">
                    <td className="table-column-120 h-[72px] px-4 py-2 w-[400px]">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 h-10 w-10">
                          <div className="h-10 w-10 rounded-full bg-[#ededed] flex items-center justify-center">
                            {getRoleIcon(user.role)}
                          </div>
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-[#141414]">
                            {user.name || user.teamName || user.username}
                          </div>
                          <div className="text-sm text-neutral-500">
                            {user.username || user.managerName}
                          </div>
                          <div className="flex items-center text-sm text-neutral-500">
                            <Mail className="h-3 w-3 mr-1" />
                            {user.email}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="table-column-240 h-[72px] px-4 py-2 w-60">
                      <div className="flex items-center">
                        {getRoleIcon(user.role)}
                        <span className="ml-2 text-sm text-[#141414]">
                          {getRoleLabel(user.role)}
                        </span>
                      </div>
                    </td>
                    <td className="table-column-360 h-[72px] px-4 py-2 w-60 text-sm text-[#141414]">
                      {user.role === 'user' ? (user.team?.teamName || 'N/A') : (user.role === 'team' ? 'Team Manager' : 'N/A')}
                    </td>
                    <td className="table-column-480 h-[72px] px-4 py-2 w-60">
                      <button className="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-xl h-8 px-4 bg-[#ededed] text-[#141414] text-sm font-medium leading-normal">
                        <span className="truncate">{user.isActive ? 'Active' : 'Inactive'}</span>
                      </button>
                    </td>
                    <td className="table-column-600 h-[72px] px-4 py-2 w-20 text-sm font-medium">
                      <div className="flex items-center justify-center space-x-2">
                        {(isAdmin() || isSuperAdmin()) && (
                          <>
                            <button
                              onClick={() => handleEditUser(user)}
                              className={iconColors.actions.edit}
                              title="Edit user"
                            >
                              <Edit className="h-4 w-4" />
                            </button>
                            <button
                              onClick={() => handleToggleUserStatus(user.id, user.isActive, user.role)}
                              className={user.isActive ? iconColors.actions.deactivate : iconColors.actions.activate}
                              title={user.isActive ? 'Deactivate user' : 'Activate user'}
                            >
                              {user.isActive ? <UserX className="h-4 w-4" /> : <UserCheck className="h-4 w-4" />}
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
        <style>
          {`
          @container(max-width:120px){.table-column-120{display: none;}}
          @container(max-width:240px){.table-column-240{display: none;}}
          @container(max-width:360px){.table-column-360{display: none;}}
          @container(max-width:480px){.table-column-480{display: none;}}
          @container(max-width:600px){.table-column-600{display: none;}}
          `}
        </style>
      </div>

      {/* Create User Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black bg-opacity-30 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-6 border border-[#dbdbdb] w-[480px] shadow-lg rounded-xl bg-white">
            <div className="mt-2">
              <div className="flex items-center mb-4">
                <div className="flex items-center justify-center rounded-full bg-blue-100 p-2 mr-3">
                  {createType === 'admin' ? (
                    <Shield className="h-6 w-6 text-blue-600" />
                  ) : (
                    <UserPlus className="h-6 w-6 text-blue-600" />
                  )}
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-[#141414]">
                    Create {createType === 'admin' ? 'Admin' : 'Member'}
                  </h3>
                  <p className="text-sm text-neutral-500">
                    Add a new {createType === 'admin' ? 'administrator' : 'team member'} to the system
                  </p>
                </div>
              </div>
              
              <form onSubmit={handleCreateUser} className="space-y-4">
                {createType === 'member' && (
                  <div>
                    <label className="block text-sm font-medium text-[#141414] mb-2">
                      Username <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={formData.username}
                      onChange={(e) => setFormData({...formData, username: e.target.value})}
                      className={componentStyles.form.input}
                      placeholder="Enter username"
                      required
                    />
                  </div>
                )}

                <div>
                  <label className="block text-sm font-medium text-[#141414] mb-2">
                    <User className="h-4 w-4 inline mr-1" />
                    Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    className={componentStyles.form.input}
                    placeholder="Enter full name"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#141414] mb-2">
                    <Mail className="h-4 w-4 inline mr-1" />
                    Email <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                    className={componentStyles.form.input}
                    placeholder="Enter email"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#141414] mb-2">
                    🔒 Password <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="password"
                    value={formData.password}
                    onChange={(e) => setFormData({...formData, password: e.target.value})}
                    className={componentStyles.form.input}
                    placeholder="Enter password"
                    required
                  />
                </div>

                {createType === 'member' && (
                  <div>
                    <label className="block text-sm font-medium text-[#141414] mb-2">
                      <Building className="h-4 w-4 inline mr-1" />
                      Team <span className="text-red-500">*</span>
                    </label>
                    <select
                      value={formData.teamId}
                      onChange={(e) => setFormData({...formData, teamId: e.target.value})}
                      className={componentStyles.form.select}
                      required
                    >
                      <option value="">Select a team</option>
                      {teams.map((team) => (
                        <option key={team.id} value={team.id}>
                          🏢 {team.teamName}
                        </option>
                      ))}
                    </select>
                  </div>
                )}

                <div className="flex items-center justify-end space-x-3 pt-4">
                  <button
                    type="button"
                    onClick={() => {
                      setShowCreateModal(false);
                      setFormData({
                        name: '',
                        email: '',
                        password: '',
                        teamId: '',
                        username: ''
                      });
                      setCreateType('');
                    }}
                    className="flex items-center justify-center rounded-xl h-10 px-4 border border-[#dbdbdb] bg-white text-[#141414] text-sm font-medium"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={submitting}
                    className="flex items-center justify-center rounded-xl h-10 px-4 bg-black text-neutral-50 text-sm font-medium"
                  >
                    {submitting ? (
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                    ) : (
                      'Create'
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Edit User Modal */}
      {showEditModal && currentUser && (
        <div className="fixed inset-0 bg-black bg-opacity-30 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-6 border border-[#dbdbdb] w-[480px] shadow-lg rounded-xl bg-white">
            <div className="mt-2">
              <div className="flex items-center mb-4">
                <div className="flex items-center justify-center rounded-full bg-neutral-200 p-2 mr-3">
                  <Edit className="h-6 w-6 text-[#404040]" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-[#141414]">
                    Edit {getRoleLabel(currentUser.role)}
                  </h3>
                  <p className="text-sm text-neutral-500">
                    Update user information and settings
                  </p>
                </div>
              </div>
              
              <form onSubmit={handleUpdateUser} className="space-y-4">
                {currentUser.role === 'user' && (
                  <div>
                    <label className="block text-sm font-medium text-[#141414] mb-2">
                      <User className="h-4 w-4 inline mr-1 text-[#404040]" />
                      Username
                    </label>
                    <input
                      type="text"
                      value={formData.username}
                      onChange={(e) => setFormData({...formData, username: e.target.value})}
                      className={componentStyles.form.input}
                      placeholder="Enter username"
                    />
                  </div>
                )}

                <div>
                  <label className="block text-sm font-medium text-[#141414] mb-2">
                    <User className="h-4 w-4 inline mr-1 text-[#404040]" />
                    Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    className={componentStyles.form.input}
                    placeholder="Enter full name"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#141414] mb-2">
                    <Mail className="h-4 w-4 inline mr-1 text-[#404040]" />
                    Email <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                    className={componentStyles.form.input}
                    placeholder="Enter email"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#141414] mb-2">
                    New Password (leave blank to keep current)
                  </label>
                  <input
                    type="password"
                    value={formData.password}
                    onChange={(e) => setFormData({...formData, password: e.target.value})}
                    className="flex h-10 w-full rounded-xl border border-[#dbdbdb] bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-black"
                    placeholder="Enter new password"
                  />
                </div>

                {currentUser.role === 'user' && (
                  <div>
                    <label className="block text-sm font-medium text-[#141414] mb-2">
                      Team
                    </label>
                    <select
                      value={formData.teamId}
                      onChange={(e) => setFormData({...formData, teamId: e.target.value})}
                      className="flex h-10 w-full rounded-xl border border-[#dbdbdb] bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-black"
                    >
                      <option value="">Select a team</option>
                      {teams.map((team) => (
                        <option key={team.id} value={team.id}>
                          {team.teamName}
                        </option>
                      ))}
                    </select>
                  </div>
                )}

                <div className="flex items-center justify-end space-x-3 pt-4">
                  <button
                    type="button"
                    onClick={() => {
                      setShowEditModal(false);
                      setCurrentUser(null);
                      setFormData({
                        name: '',
                        email: '',
                        password: '',
                        teamId: '',
                        username: ''
                      });
                    }}
                    className="flex items-center justify-center rounded-xl h-10 px-4 border border-[#dbdbdb] bg-white text-[#141414] text-sm font-medium"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={submitting}
                    className="flex items-center justify-center rounded-xl h-10 px-4 bg-black text-neutral-50 text-sm font-medium"
                  >
                    {submitting ? (
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                    ) : (
                      'Update User'
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Confirmation Modal */}
      {showConfirmModal && confirmAction && (
        <div className="fixed inset-0 bg-black bg-opacity-30 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-6 border w-[400px] shadow-lg rounded-xl bg-white">
            <div className="mt-2">
              <div className="flex items-center mb-4">
                <AlertTriangle className="h-6 w-6 text-orange-500 mr-3" />
                <h3 className="text-xl font-medium text-[#141414]">Confirm Action</h3>
              </div>
              
              <p className="text-sm text-neutral-600 mb-6">
                {confirmAction.message}
              </p>

              <div className="flex items-center justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => {
                    setShowConfirmModal(false);
                    setConfirmAction(null);
                  }}
                  className="flex items-center justify-center rounded-xl h-10 px-4 border border-[#dbdbdb] bg-white text-[#141414] text-sm font-medium"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => {
                    confirmAction.onConfirm();
                    setShowConfirmModal(false);
                    setConfirmAction(null);
                  }}
                  className="flex items-center justify-center rounded-xl h-10 px-4 bg-red-600 text-white text-sm font-medium hover:bg-red-700"
                >
                  Confirm
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default UsersPage; 