import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { api } from '../contexts/AuthContext';
import axios from 'axios';
import { getApiUrl } from '../config/api';
import toast from 'react-hot-toast';
import {
  Ticket,
  Upload,
  X,
  Calendar,
  User,
  AlertCircle,
  Clock,
  FileText,
  Building
} from 'lucide-react';

const CreateTicket = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [teams, setTeams] = useState([]);

  const [projects, setProjects] = useState([]);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    type: 'task',
    category: 'Software',
    dueDate: '',
    teamId: '',
    assignedTeamId: '',
    projectId: '',
    priority: 'MEDIUM',
    estimatedHours: '',
    expectedClosure: '',
    attachments: []
  });
  const [attachments, setAttachments] = useState([]);

  useEffect(() => {
    fetchFormData();
  }, []);

  const fetchFormData = async () => {
    try {
      // Fetch teams and projects for dropdowns
      const [teamsRes, projectsRes] = await Promise.all([
        api.get('/api/teams/dropdown'),
        api.get('/api/projects/dropdown')
      ]);

      setTeams(teamsRes.data.teams || []);
      setProjects(projectsRes.data.projects || []);

      // Auto-select team based on user role
      if (user?.role === 'user' && user?.teamId) {
        // Regular users are auto-assigned to their team
        setFormData(prev => ({
          ...prev,
          teamId: user.teamId.toString(),
          assignedTeamId: user.teamId.toString()
        }));
      } else if (user?.role === 'team' && user?.id) {
        // Team managers are auto-assigned to their team as creator
        // and can also assign to their own team if desired
        setFormData(prev => ({
          ...prev,
          teamId: user.id.toString(),
          // Auto-select their own team as the assigned team as well
          assignedTeamId: user.id.toString()
        }));
      }
    } catch (error) {
      console.error('Error fetching form data:', error);
      toast.error('Failed to load form data');
    }
  };



  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));

    // No need to fetch team members since we removed individual assignment
  };

  const handleFileChange = (e) => {
    const files = Array.from(e.target.files);
    setAttachments(prev => [...prev, ...files]);
  };

  const removeAttachment = (index) => {
    setAttachments(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validate required fields
    if (!formData.title || formData.title.length < 5) {
      toast.error('Title must be at least 5 characters long');
      return;
    }

    if (!formData.description || formData.description.length < 10) {
      toast.error('Description must be at least 10 characters long');
      return;
    }

    if (!formData.dueDate) {
      toast.error('Due date is required');
      return;
    }

    if (!formData.teamId) {
      toast.error('Your team selection is required');
      return;
    }

    if (!formData.assignedTeamId) {
      toast.error('Please select a team to assign the task to');
      return;
    }

    // Team managers can assign tickets to their own team (removed restriction)

    try {
      setLoading(true);

      // Get token from localStorage to ensure it's fresh
      const token = localStorage.getItem('token');

      // Debug: Check if form data is populated
      console.log('Current formData state:', formData);
      console.log('Current attachments:', attachments);

      // Create FormData to handle file uploads
      const formDataToSend = new FormData();
      
      // Add all form fields
      formDataToSend.append('title', formData.title);
      formDataToSend.append('description', formData.description);
      formDataToSend.append('type', formData.type);
      formDataToSend.append('category', formData.category);
      formDataToSend.append('dueDate', formData.dueDate);
      formDataToSend.append('teamId', parseInt(formData.teamId));
      formDataToSend.append('assignedTeamId', parseInt(formData.assignedTeamId));
      if (formData.projectId) {
        formDataToSend.append('projectId', parseInt(formData.projectId));
      }
      formDataToSend.append('priority', formData.priority);
      if (formData.estimatedHours) {
        formDataToSend.append('estimatedHours', parseFloat(formData.estimatedHours));
      }

      // Add attachments
      attachments.forEach((file) => {
        formDataToSend.append('attachments', file);
      });

      // Set authorization header (don't set Content-Type for FormData)
      const headers = {
        'Authorization': `Bearer ${token}`
      };

      console.log('Form data before sending:', formData);
      console.log('Submitting ticket with attachments:', attachments.length);
      console.log('Using auth token:', token ? 'Token exists' : 'No token');
      
      // Debug FormData contents
      for (let [key, value] of formDataToSend.entries()) {
        console.log(`FormData ${key}:`, value);
      }

      // Use axios directly with explicit headers
      const response = await axios.post(getApiUrl('/api/tickets'), formDataToSend, { headers });

      console.log('Ticket creation response:', response.data);
      toast.success('Ticket created successfully! It will be reviewed by administrators.');
      navigate('/tickets');
    } catch (error) {
      console.error('Error creating ticket:', error);
      // Show more detailed error information
      if (error.response) {
        console.error('Error response data:', error.response.data);
        console.error('Error response status:', error.response.status);

        // Extract validation error messages
        if (error.response.data.details && error.response.data.details.length > 0) {
          const errorMessages = error.response.data.details.map(detail => detail.msg).join(', ');
          toast.error(errorMessages);
        } else {
          toast.error(error.response.data.error || 'Failed to create ticket');
        }
      } else {
        toast.error('Failed to create ticket. Please check your connection.');
      }
    } finally {
      setLoading(false);
    }
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'LOW':
        return 'text-green-600 bg-green-100';
      case 'MEDIUM':
        return 'text-yellow-600 bg-yellow-100';
      case 'HIGH':
        return 'text-orange-600 bg-orange-100';
      case 'URGENT':
        return 'text-red-600 bg-red-100';
      default:
        return 'text-gray-600 bg-gray-100';
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex flex-col gap-3 p-4">
        <p className="text-[#141414] tracking-light text-[32px] font-bold leading-tight">Create New Ticket</p>
        <p className="text-neutral-500 text-sm font-normal leading-normal">
          Submit a new ticket for review and processing. All tickets require admin approval.
        </p>
      </div>

      {/* Form */}
      <div className="rounded-xl border border-[#dbdbdb] bg-neutral-50 overflow-hidden mx-4">
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Title */}
          <div>
            <label htmlFor="title" className="block text-sm font-medium text-[#141414] mb-2">
              Ticket Title <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              id="title"
              name="title"
              value={formData.title}
              onChange={handleInputChange}
              className="flex h-10 w-full rounded-xl border border-[#dbdbdb] bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-black"
              placeholder="Enter ticket title (min 5 characters)"
              required
              minLength={5}
            />
          </div>

          {/* Description */}
          <div>
            <label htmlFor="description" className="block text-sm font-medium text-[#141414] mb-2">
              Description <span className="text-red-500">*</span>
            </label>
            <textarea
              id="description"
              name="description"
              value={formData.description}
              onChange={handleInputChange}
              rows={4}
              className="flex w-full rounded-xl border border-[#dbdbdb] bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-black"
              placeholder="Describe the issue or request in detail (min 10 characters)"
              required
              minLength={10}
            />
          </div>

          {/* Type and Category */}
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
            <div>
              <label htmlFor="type" className="block text-sm font-medium text-[#141414] mb-2">
                Ticket Type <span className="text-red-500">*</span>
              </label>
              <select
                id="type"
                name="type"
                value={formData.type}
                onChange={handleInputChange}
                className="flex h-10 w-full rounded-xl border border-[#dbdbdb] bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-black"
                required
              >
                <option value="bug">Bug</option>
                <option value="feature">Feature Request</option>
                <option value="task">Task</option>
                <option value="improvement">Improvement</option>
                <option value="support">Support</option>
                <option value="requirement">Requirement</option>
              </select>
            </div>

            <div>
              <label htmlFor="category" className="block text-sm font-medium text-[#141414] mb-2">
                Category <span className="text-red-500">*</span>
              </label>
              <select
                id="category"
                name="category"
                value={formData.category}
                onChange={handleInputChange}
                className="flex h-10 w-full rounded-xl border border-[#dbdbdb] bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-black"
                required
              >
                <option value="Hardware">Hardware</option>
                <option value="Software">Software</option>
                <option value="Tools">Tools</option>
                <option value="Lab Support">Lab Support</option>
                <option value="Purchase">Purchase</option>
                <option value="ASPICE">ASPICE</option>
                <option value="Functional Safety">Functional Safety</option>
                <option value="Cyber sec">Cyber sec</option>
              </select>
            </div>
          </div>

          {/* Assigned Team and Due Date */}
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
            <div>
              <label htmlFor="assignedTeamId" className="block text-sm font-medium text-[#141414] mb-2">
                Assign to Team <span className="text-red-500">*</span>
              </label>
              <select
                id="assignedTeamId"
                name="assignedTeamId"
                value={formData.assignedTeamId}
                onChange={handleInputChange}
                className="flex h-10 w-full rounded-xl border border-[#dbdbdb] bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-black"
                required
              >
                <option value="">Select a team to assign the task</option>
                {teams.map((team) => (
                    <option key={team.id} value={team.id}>
                      {team.teamName}
                    </option>
                  ))}
              </select>
              {user?.role === 'team' && (
                <p className="mt-1 text-xs text-neutral-500">
                  You can assign tickets to your own team or other teams
                </p>
              )}
            </div>

            <div>
              <label htmlFor="dueDate" className="block text-sm font-medium text-[#141414] mb-2">
                Due Date <span className="text-red-500">*</span>
              </label>
              <input
                type="datetime-local"
                id="dueDate"
                name="dueDate"
                value={formData.dueDate}
                onChange={handleInputChange}
                className="flex h-10 w-full rounded-xl border border-[#dbdbdb] bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-black"
                required
                min={new Date().toISOString().slice(0, 16)}
              />
            </div>
          </div>

          {/* Creator Team and Project */}
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
            <div>
              <label htmlFor="teamId" className="block text-sm font-medium text-[#141414] mb-2">
                {user?.role === 'team' ? 'Your Team (Creator)' : 'Your Team'} <span className="text-red-500">*</span>
              </label>
              <select
                id="teamId"
                name="teamId"
                value={formData.teamId}
                onChange={handleInputChange}
                className="flex h-10 w-full rounded-xl border border-[#dbdbdb] bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-black"
                required
                disabled={user?.role === 'user' || user?.role === 'team'} // Members and team managers are auto-assigned
              >
                <option value="">Select your team</option>
                {teams.map((team) => (
                  <option key={team.id} value={team.id}>
                    {team.teamName}
                  </option>
                ))}
              </select>
              {user?.role === 'user' && (
                <p className="mt-1 text-xs text-neutral-500">
                  You are automatically assigned to your team
                </p>
              )}
              {user?.role === 'team' && (
                <p className="mt-1 text-xs text-neutral-500">
                  You are creating this ticket on behalf of your team
                </p>
              )}
            </div>

            <div>
              <label htmlFor="projectId" className="block text-sm font-medium text-[#141414] mb-2">
                Project (Optional)
              </label>
              <select
                id="projectId"
                name="projectId"
                value={formData.projectId}
                onChange={handleInputChange}
                className="flex h-10 w-full rounded-xl border border-[#dbdbdb] bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-black"
              >
                <option value="">No Project</option>
                {projects.map((project) => (
                  <option key={project.id} value={project.id}>
                    {project.name} {project.team ? `(${project.team.teamName})` : ''}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Priority */}
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
            <div>
              <label htmlFor="priority" className="block text-sm font-medium text-[#141414] mb-2">
                Priority
              </label>
              <select
                id="priority"
                name="priority"
                value={formData.priority}
                onChange={handleInputChange}
                className="flex h-10 w-full rounded-xl border border-[#dbdbdb] bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-black"
              >
                <option value="LOW">Low</option>
                <option value="MEDIUM">Medium</option>
                <option value="HIGH">High</option>
                <option value="URGENT">Urgent</option>
              </select>
            </div>
            
            <div>
              <label htmlFor="estimatedHours" className="block text-sm font-medium text-[#141414] mb-2">
                Estimated Hours (Optional)
              </label>
              <input
                type="number"
                id="estimatedHours"
                name="estimatedHours"
                value={formData.estimatedHours}
                onChange={handleInputChange}
                className="flex h-10 w-full rounded-xl border border-[#dbdbdb] bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-black"
                placeholder="Enter estimated hours"
                min="0"
                step="0.5"
              />
            </div>
          </div>

          {/* Placeholder for spacing */}
          <div className="hidden">
          </div>

          {/* Expected Closure Date */}
          <div>
            <label htmlFor="expectedClosure" className="block text-sm font-medium text-[#141414] mb-2">
              Expected Closure Date (Optional)
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Calendar className="h-5 w-5 text-neutral-500" />
              </div>
              <input
                type="datetime-local"
                id="expectedClosure"
                name="expectedClosure"
                value={formData.expectedClosure}
                onChange={handleInputChange}
                className="flex h-10 w-full rounded-xl border border-[#dbdbdb] bg-white px-3 py-2 pl-10 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-black"
              />
            </div>
          </div>

          {/* File Attachments */}
          <div>
            <label className="block text-sm font-medium text-[#141414] mb-2">
              Attachments (Optional)
            </label>
            <div>
              <div className="flex items-center justify-center w-full">
                <label className="flex flex-col w-full h-32 border-2 border-dashed border-[#dbdbdb] hover:bg-[#f9f9f9] hover:border-[#c0c0c0] group cursor-pointer rounded-xl">
                  <div className="flex flex-col items-center justify-center pt-7">
                    <Upload className="w-10 h-10 text-neutral-400 group-hover:text-[#141414]" />
                    <p className="pt-1 text-sm tracking-wider text-neutral-400 group-hover:text-[#141414]">
                      Select files
                    </p>
                  </div>
                  <input
                    type="file"
                    multiple
                    onChange={handleFileChange}
                    className="opacity-0"
                  />
                </label>
              </div>
            </div>

            {/* Display selected files */}
            {attachments.length > 0 && (
              <div className="mt-4 space-y-2">
                <h4 className="text-sm font-medium text-[#141414]">Selected Files:</h4>
                {attachments.map((file, index) => (
                  <div key={index} className="flex items-center justify-between p-2 bg-[#ededed] rounded-xl">
                    <div className="flex items-center">
                      <FileText className="h-4 w-4 text-[#141414] mr-2" />
                      <span className="text-sm text-[#141414]">{file.name}</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => removeAttachment(index)}
                      className="text-[#141414] hover:text-red-600 p-1"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Information Box */}
          <div className="bg-[#f5f8ff] border border-[#dbdbdb] rounded-xl p-4">
            <div className="flex">
              <div className="flex-shrink-0">
                <AlertCircle className="h-5 w-5 text-[#141414]" />
              </div>
              <div className="ml-3">
                <h3 className="text-sm font-medium text-[#141414]">
                  Ticket Approval Process
                </h3>
                <div className="mt-2 text-sm text-neutral-500">
                  <p>• Your ticket will be submitted for admin review</p>
                  <p>• Admins will assign priority and expected closure date</p>
                  <p>• You will be notified when the ticket is approved or rejected</p>
                  <p>• Resource allocation will be handled by administrators</p>
                </div>
              </div>
            </div>
          </div>

          {/* Submit Button */}
          <div className="flex justify-end space-x-3">
            <button
              type="button"
              onClick={() => navigate('/tickets')}
              className="flex items-center justify-center rounded-xl h-10 px-4 border border-[#dbdbdb] bg-white text-[#141414] text-sm font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="flex items-center justify-center rounded-xl h-10 px-4 bg-black text-neutral-50 text-sm font-medium"
            >
              {loading ? (
                <div className="flex items-center">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Creating...
                </div>
              ) : (
                'Create Ticket'
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CreateTicket;
