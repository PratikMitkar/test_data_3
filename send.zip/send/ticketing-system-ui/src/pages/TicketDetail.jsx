import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import axios from 'axios';
import toast from 'react-hot-toast';
import { getApiUrl } from '../config/api';
import {
  FileText,
  CheckCircle,
  XCircle,
  User,
  Edit,
  Calendar,
  Clock,
  AlertTriangle,
  Play,
  Eye,
  CheckSquare,
  MessageSquare,
  Plus,
  Paperclip
} from 'lucide-react';

const TicketDetail = () => {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [ticket, setTicket] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [newComment, setNewComment] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [showApprovalModal, setShowApprovalModal] = useState(false);
  const [activeTab, setActiveTab] = useState('details'); // 'details', 'comments' or 'activity'
  const [approvalData, setApprovalData] = useState({
    action: '',
    priority: 'MEDIUM',
    expectedClosure: '',
    rejectionReason: ''
  });

  // Check if user is admin or super_admin or assigned to this ticket
  const isAdminOrSuperAdmin = ['admin', 'super_admin'].includes(user?.role);
  const isAssignedUser = ticket?.assignedTo === user?.id;
  const isCreator = ticket?.createdBy === user?.id;
  const hasAdminPrivileges = isAdminOrSuperAdmin || isAssignedUser;

  useEffect(() => {
    fetchTicket();
  }, [id]);

  const fetchTicket = async () => {
    try {
      setLoading(true);
      const response = await axios.get(getApiUrl(`/api/tickets/${id}`));
      setTicket(response.data.ticket);

      // Debug: Log ticket data to see attachments
      console.log('Fetched ticket data:', response.data.ticket);
      console.log('Attachments:', response.data.ticket.attachments);

      // Initialize approval data with ticket values
      if (response.data.ticket) {
        setApprovalData({
          ...approvalData,
          priority: response.data.ticket.priority || 'MEDIUM',
          expectedClosure: response.data.ticket.expectedClosure || ''
        });
      }
    } catch (error) {
      console.error('Error fetching ticket:', error);
      toast.error('Failed to fetch ticket details');
      navigate('/tickets');
    } finally {
      setLoading(false);
    }
  };

  const handleStatusUpdate = async (newStatus) => {
    try {
      setSubmitting(true);
      await axios.patch(getApiUrl(`/api/tickets/${id}/status`), {
        status: newStatus
      });
      toast.success('Ticket status updated successfully');
      fetchTicket();
    } catch (error) {
      console.error('Error updating status:', error);
      toast.error('Failed to update ticket status');
    } finally {
      setSubmitting(false);
    }
  };

  const handleAddComment = async () => {
    if (!newComment.trim()) {
      toast.error('Please enter a comment');
      return;
    }

    try {
      setSubmitting(true);
      await axios.post(getApiUrl(`/api/tickets/${id}/comments`), {
        content: newComment,
        isInternal: false
      });
      toast.success('Comment added successfully');
      setNewComment('');
      fetchTicket();
    } catch (error) {
      console.error('Error adding comment:', error);
      toast.error('Failed to add comment');
    } finally {
      setSubmitting(false);
    }
  };

  const handleApproval = async () => {
    try {
      setSubmitting(true);

      const updateData = {
        status: approvalData.action === 'approve' ? 'APPROVED' : 'REJECTED'
      };

      if (approvalData.action === 'approve') {
        updateData.priority = approvalData.priority;
        if (approvalData.expectedClosure) {
          updateData.expectedClosure = approvalData.expectedClosure;
        }
      } else {
        updateData.rejectionReason = approvalData.rejectionReason;
      }

      await axios.put(getApiUrl(`/api/tickets/${id}`), updateData);

      toast.success(`Ticket ${approvalData.action === 'approve' ? 'approved' : 'rejected'} successfully!`);
      setShowApprovalModal(false);
      fetchTicket();
    } catch (error) {
      console.error('Failed to update ticket:', error);
      toast.error('Failed to update ticket');
    } finally {
      setSubmitting(false);
    }
  };

  const openApprovalModal = (action) => {
    setApprovalData({
      ...approvalData,
      action,
      rejectionReason: ''
    });
    setShowApprovalModal(true);
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'Unknown';

    const date = new Date(dateString);
    const now = new Date();

    // Reset time to start of day for accurate day comparison
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const commentDate = new Date(date.getFullYear(), date.getMonth(), date.getDate());

    const diffTime = today.getTime() - commentDate.getTime();
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays === 0) {
      // Same day - show time
      return date.toLocaleTimeString('en-US', {
        hour: 'numeric',
        minute: '2-digit',
        hour12: true
      });
    } else if (diffDays === 1) {
      return 'Yesterday';
    } else if (diffDays < 7) {
      return `${diffDays} days ago`;
    } else if (diffDays < 30) {
      const weeks = Math.floor(diffDays / 7);
      return weeks === 1 ? '1 week ago' : `${weeks} weeks ago`;
    } else {
      return date.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: date.getFullYear() !== now.getFullYear() ? 'numeric' : undefined
      });
    }
  };

  const formatTime = (dateString) => {
    if (!dateString) return '';

    const date = new Date(dateString);
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    });
  };

  const formatFullDate = (dateString) => {
    if (!dateString) return 'Not set';
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'PENDING_APPROVAL':
        return <Clock className="h-6 w-6 text-gray-600" />;
      case 'APPROVED':
        return <CheckCircle className="h-6 w-6 text-gray-700" />;
      case 'IN_PROGRESS':
        return <Play className="h-6 w-6 text-gray-700" />;
      case 'IN_REVIEW':
        return <Eye className="h-6 w-6 text-gray-600" />;
      case 'COMPLETED':
        return <CheckSquare className="h-6 w-6 text-gray-800" />;
      case 'REJECTED':
        return <XCircle className="h-6 w-6 text-gray-600" />;
      default:
        return <FileText className="h-6 w-6 text-gray-500" />;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'PENDING_APPROVAL':
        return 'text-yellow-600 bg-yellow-100';
      case 'APPROVED':
        return 'text-green-600 bg-green-100';
      case 'IN_PROGRESS':
        return 'text-blue-600 bg-blue-100';
      case 'IN_REVIEW':
        return 'text-purple-600 bg-purple-100';
      case 'COMPLETED':
        return 'text-green-700 bg-green-100';
      case 'REJECTED':
        return 'text-red-600 bg-red-100';
      default:
        return 'text-gray-600 bg-gray-100';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div>
      </div>
    );
  }

  if (!ticket) {
    return (
      <div className="text-center py-12">
        <FileText className="mx-auto h-12 w-12 text-neutral-400" />
        <h3 className="mt-2 text-sm font-medium text-[#141414]">Ticket not found</h3>
        <p className="mt-1 text-sm text-neutral-500">The ticket you're looking for doesn't exist.</p>
      </div>
    );
  }

  const projectName = ticket.projectRef?.name || 'Project Alpha';

  return (
    <>
      {/* Main container with theme background */}
      <div className="relative flex size-full min-h-screen flex-col bg-slate-50 overflow-x-hidden" style={{ fontFamily: 'Inter, "Noto Sans", sans-serif' }}>
        <div className="gap-1 px-6 flex flex-1 justify-center py-5">
          {/* Main Content - Left Side */}
          <div className="layout-content-container flex flex-col max-w-[920px] flex-1">
            {/* Breadcrumb */}
            <div className="flex flex-wrap gap-2 p-4">
              <Link to="/projects" className="text-neutral-500 text-base font-medium leading-normal">Projects</Link>
              <span className="text-neutral-500 text-base font-medium leading-normal">/</span>
              <Link to={`/projects/${ticket.projectRef?.id || ''}`} className="text-neutral-500 text-base font-medium leading-normal">
                {projectName}
              </Link>
              <span className="text-neutral-500 text-base font-medium leading-normal">/</span>
              <span className="text-[#141414] text-base font-medium leading-normal">Ticket #{ticket.id}</span>
            </div>

            {/* Ticket Header */}
            <div className="px-4 py-6">
              {/* Title */}
              <h1 className="text-[#141414] text-[28px] font-bold leading-tight mb-4">
                Ticket #{ticket.id}: {ticket.title}
              </h1>

              {/* Ticket Meta Information */}
              <div className="text-neutral-500 text-sm space-y-2 mb-8">
                <div className="flex flex-wrap gap-6">
                  <span>
                    <strong>Assigned to:</strong> {ticket.assignedUser?.name || 'Unassigned'}
                  </span>
                  <span>
                    <strong>Priority:</strong> {ticket.priority ? ticket.priority.charAt(0) + ticket.priority.slice(1).toLowerCase() : 'Medium'}
                  </span>
                  <span>
                    <strong>Status:</strong> {ticket.status === 'PENDING_APPROVAL' ? 'Pending Approval' :
                      ticket.status === 'APPROVED' ? 'Approved' :
                        ticket.status === 'IN_PROGRESS' ? 'In Progress' :
                          ticket.status === 'IN_REVIEW' ? 'In Review' :
                            ticket.status === 'COMPLETED' ? 'Completed' :
                              ticket.status === 'REJECTED' ? 'Rejected' : 'Unknown'}
                  </span>
                </div>

                {/* Additional row for more fields */}

                {/* Time tracking information */}
                {ticket.actualHours && (
                  <div className="flex flex-wrap gap-6">
                    {ticket.actualHours && (
                      <span>
                        <strong>Actual Hours:</strong> {ticket.actualHours}h
                      </span>
                    )}
                  </div>
                )}
              </div>

              {/* Description Section */}
              <div className="mb-8">
                <h3 className="text-neutral-500 text-sm font-normal leading-normal mb-3">Description</h3>
                <div
                  className="border border-[#dbdbdb] rounded-xl p-4 mb-4 bg-neutral-50"
                  style={{
                    height: '240px',
                    overflowY: 'auto',
                    overflowX: 'hidden',
                    fontFamily: 'Inter, "Noto Sans", sans-serif'
                  }}
                >
                  <p
                    className="text-[#141414] text-sm font-normal leading-normal whitespace-pre-wrap m-0"
                    style={{
                      textAlign: 'justify',
                      textJustify: 'inter-word',
                      hyphens: 'none',
                      wordBreak: 'normal',
                      overflowWrap: 'break-word'
                    }}
                  >
                    {ticket.description}
                  </p>
                </div>
              </div>


              {/* Attachments Section */}
              {ticket.attachments && ticket.attachments.length > 0 && (
                <div className="mb-8">
                  <h4 className="text-neutral-500 text-sm font-normal leading-normal mb-3">Attachments ({ticket.attachments.length})</h4>
                  <div className="space-y-2">
                    {ticket.attachments.map((attachment, index) => (
                      <div key={`attachment-${attachment.id || attachment.filename || index}`} className="flex items-center gap-3 p-3 bg-neutral-50 rounded-xl border border-[#dbdbdb]">
                        <div className="text-neutral-500">
                          <Paperclip className="h-4 w-4" />
                        </div>
                        <span className="text-[#141414] text-sm flex-1">
                          {attachment.filename || attachment.name || `attachment_${index + 1}`}
                        </span>
                        <div className="flex gap-2">
                          <button
                            onClick={() => {
                              const fileUrl = attachment.url || (attachment.path ? `${getApiUrl('')}/${attachment.path}` : null);
                              if (fileUrl) {
                                window.open(fileUrl, '_blank');
                              } else {
                                toast.error('File not found');
                              }
                            }}
                            className="flex items-center gap-1 px-3 py-1 bg-[#141414] text-white text-xs rounded-lg hover:bg-gray-800 transition-colors"
                            title="View file"
                          >
                            <Eye className="h-3 w-3" />
                            View
                          </button>
                          <button
                            onClick={() => {
                              const fileUrl = attachment.url || (attachment.path ? `${getApiUrl('')}/${attachment.path}` : null);
                              if (fileUrl) {
                                const link = document.createElement('a');
                                link.href = fileUrl;
                                link.download = attachment.originalName || attachment.filename || attachment.name || 'download';
                                link.click();
                              } else {
                                toast.error('File not found');
                              }
                            }}
                            className="flex items-center gap-1 px-3 py-1 border border-[#dbdbdb] bg-white text-[#141414] text-xs rounded-lg hover:bg-neutral-50 transition-colors"
                            title="Download file"
                          >
                            <svg className="h-3 w-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                            </svg>
                            Download
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Show message if no attachments */}
              {(!ticket.attachments || ticket.attachments.length === 0) && (
                <div className="mb-8">
                  <h4 className="text-neutral-500 text-sm font-normal leading-normal mb-3">Attachments</h4>
                  <p className="text-neutral-500 text-sm italic">No attachments</p>
                </div>
              )}
            </div>


          </div>

          {/* Comments and Activity - Right Side */}
          <div className="layout-content-container flex flex-col w-[360px]">
            <div className="pb-3">
              <div className="flex border-b border-[#dbdbdb] px-4 gap-6">
                <button
                  onClick={() => setActiveTab('details')}
                  className={`flex flex-col items-center justify-center border-b-[3px] pb-[13px] pt-4 ${activeTab === 'details'
                    ? 'border-b-[#141414] text-[#141414]'
                    : 'border-b-transparent text-neutral-500'
                    }`}
                >
                  <p className="text-sm font-bold leading-normal tracking-[0.015em]">Details</p>
                </button>
                <button
                  onClick={() => setActiveTab('comments')}
                  className={`flex flex-col items-center justify-center border-b-[3px] pb-[13px] pt-4 ${activeTab === 'comments'
                    ? 'border-b-[#141414] text-[#141414]'
                    : 'border-b-transparent text-neutral-500'
                    }`}
                >
                  <p className="text-sm font-bold leading-normal tracking-[0.015em]">Comments</p>
                </button>
                <button
                  onClick={() => setActiveTab('activity')}
                  className={`flex flex-col items-center justify-center border-b-[3px] pb-[13px] pt-4 ${activeTab === 'activity'
                    ? 'border-b-[#141414] text-[#141414]'
                    : 'border-b-transparent text-neutral-500'
                    }`}
                >
                  <p className="text-sm font-bold leading-normal tracking-[0.015em]">Activity</p>
                </button>
              </div>
            </div>

            {/* Details Tab Content */}
            {activeTab === 'details' && (
              <div className="px-4 py-4">
                <div className="space-y-1">
                  {/* Due Date */}
                  <div className="group hover:bg-slate-50 rounded-lg transition-colors duration-150 relative border-b border-neutral-300">
                    <div className="flex items-center justify-between py-3 px-3">
                      <div className="flex items-center gap-3">
                        <div className="flex items-center justify-center w-8 h-8 rounded-full bg-gray-100 group-hover:bg-gray-200 transition-colors duration-150">
                          <Calendar className="h-4 w-4 text-gray-700" />
                        </div>
                        <span className="text-slate-600 text-sm font-medium">Due Date</span>
                      </div>
                      <div className="text-right">
                        <span className="text-[#141414] text-sm font-semibold block">
                          {ticket.dueDate ? new Date(ticket.dueDate).toLocaleDateString('en-US', {
                            month: 'short',
                            day: 'numeric',
                            year: 'numeric'
                          }) : 'Not set'}
                        </span>
                        {ticket.dueDate && (
                          <span className="text-slate-400 text-xs">
                            {new Date(ticket.dueDate).toLocaleDateString('en-US', { weekday: 'long' })}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Expected Closure */}
                  <div className="group hover:bg-slate-50 rounded-lg transition-colors duration-150 relative border-b border-neutral-300">
                    <div className="flex items-center justify-between py-3 px-3">
                      <div className="flex items-center gap-3">
                        <div className="flex items-center justify-center w-8 h-8 rounded-full bg-gray-100 group-hover:bg-gray-200 transition-colors duration-150">
                          <Clock className="h-4 w-4 text-gray-700" />
                        </div>
                        <span className="text-slate-600 text-sm font-medium">Expected Closure</span>
                      </div>
                      <div className="text-right">
                        <span className="text-[#141414] text-sm font-semibold block">
                          {ticket.expectedClosure ? new Date(ticket.expectedClosure).toLocaleDateString('en-US', {
                            month: 'short',
                            day: 'numeric',
                            year: 'numeric'
                          }) : 'Not set'}
                        </span>
                        {ticket.expectedClosure && (
                          <span className="text-slate-400 text-xs">
                            {new Date(ticket.expectedClosure).toLocaleDateString('en-US', { weekday: 'long' })}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Type */}
                  <div className="group hover:bg-slate-50 rounded-lg transition-colors duration-150 relative border-b border-neutral-300">
                    <div className="flex items-center justify-between py-3 px-3">
                      <div className="flex items-center gap-3">
                        <div className="flex items-center justify-center w-8 h-8 rounded-full bg-gray-100 group-hover:bg-gray-200 transition-colors duration-150">
                          <FileText className="h-4 w-4 text-gray-700" />
                        </div>
                        <span className="text-slate-600 text-sm font-medium">Type</span>
                      </div>
                      <span className="text-[#141414] text-sm font-semibold">
                        {ticket.type ? ticket.type.charAt(0).toUpperCase() + ticket.type.slice(1) : 'Task'}
                      </span>
                    </div>
                  </div>

                  {/* Created */}
                  <div className="group hover:bg-slate-50 rounded-lg transition-colors duration-150 relative border-b border-neutral-300">
                    <div className="flex items-center justify-between py-3 px-3">
                      <div className="flex items-center gap-3">
                        <div className="flex items-center justify-center w-8 h-8 rounded-full bg-gray-100 group-hover:bg-gray-200 transition-colors duration-150">
                          <Plus className="h-4 w-4 text-gray-700" />
                        </div>
                        <span className="text-slate-600 text-sm font-medium">Created</span>
                      </div>
                      <div className="text-right">
                        <span className="text-[#141414] text-sm font-semibold block">
                          {new Date(ticket.createdAt).toLocaleDateString('en-US', {
                            month: 'short',
                            day: 'numeric',
                            year: 'numeric'
                          })}
                        </span>
                        <span className="text-slate-400 text-xs">
                          {new Date(ticket.createdAt).toLocaleDateString('en-US', { weekday: 'long' })}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Creator Team */}
                  <div className="group hover:bg-slate-50 rounded-lg transition-colors duration-150 relative border-b border-neutral-300">
                    <div className="flex items-center justify-between py-3 px-3">
                      <div className="flex items-center gap-3">
                        <div className="flex items-center justify-center w-8 h-8 rounded-full bg-gray-100 group-hover:bg-gray-200 transition-colors duration-150">
                          <User className="h-4 w-4 text-gray-700" />
                        </div>
                        <span className="text-slate-600 text-sm font-medium">Creator Team</span>
                      </div>
                      <span className="text-[#141414] text-sm font-semibold">
                        {ticket.creatorTeam?.teamName || 'Not assigned'}
                      </span>
                    </div>
                  </div>

                  {/* Assigned Team */}
                  <div className="group hover:bg-slate-50 rounded-lg transition-colors duration-150 relative border-b border-neutral-300">
                    <div className="flex items-center justify-between py-3 px-3">
                      <div className="flex items-center gap-3">
                        <div className="flex items-center justify-center w-8 h-8 rounded-full bg-gray-100 group-hover:bg-gray-200 transition-colors duration-150">
                          <User className="h-4 w-4 text-gray-700" />
                        </div>
                        <span className="text-slate-600 text-sm font-medium">Assigned Team</span>
                      </div>
                      <span className="text-[#141414] text-sm font-semibold">
                        {ticket.assignedTeam?.teamName || 'Not assigned'}
                      </span>
                    </div>
                  </div>

                  {/* Estimated Hours */}
                  <div className="group hover:bg-slate-50 rounded-lg transition-colors duration-150 relative border-b border-neutral-300">
                    <div className="flex items-center justify-between py-3 px-3">
                      <div className="flex items-center gap-3">
                        <div className="flex items-center justify-center w-8 h-8 rounded-full bg-gray-100 group-hover:bg-gray-200 transition-colors duration-150">
                          <Clock className="h-4 w-4 text-gray-700" />
                        </div>
                        <span className="text-slate-600 text-sm font-medium">Estimated Hours</span>
                      </div>
                      <span className="text-[#141414] text-sm font-semibold">
                        {ticket.estimatedHours ? `${ticket.estimatedHours}h` : 'Not set'}
                      </span>
                    </div>
                  </div>

                  {/* Created By */}
                  <div className="group hover:bg-slate-50 rounded-lg transition-colors duration-150 relative">
                    <div className="flex items-center justify-between py-3 px-3">
                      <div className="flex items-center gap-3">
                        <div className="flex items-center justify-center w-8 h-8 rounded-full bg-gray-100 group-hover:bg-gray-200 transition-colors duration-150">
                          <User className="h-4 w-4 text-gray-700" />
                        </div>
                        <span className="text-slate-600 text-sm font-medium">Created By</span>
                      </div>
                      <span className="text-[#141414] text-sm font-semibold">
                        {ticket.creator?.name || 'Unknown'}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Comments Tab Content */}
            {activeTab === 'comments' && (
              <>
                {/* Add Comment Input */}
                <div className="flex items-center px-4 py-3 gap-3 @container">
                  <div
                    className="bg-center bg-no-repeat aspect-square bg-cover rounded-full size-10 shrink-0"
                    style={{ backgroundImage: `url("https://i.pravatar.cc/300?u=${user?.id || 'current'}")` }}
                  ></div>
                  <label className="flex flex-col min-w-40 h-12 flex-1">
                    <div className="flex w-full flex-1 items-stretch rounded-xl h-full">
                      <input
                        placeholder="Add a comment..."
                        className="form-input flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-xl text-[#141414] focus:outline-0 focus:ring-0 border-none bg-[#ededed] focus:border-none h-full placeholder:text-neutral-500 px-4 rounded-r-none border-r-0 pr-2 text-base font-normal leading-normal"
                        value={newComment}
                        onChange={(e) => setNewComment(e.target.value)}
                        onKeyPress={(e) => {
                          if (e.key === 'Enter' && newComment.trim()) {
                            handleAddComment();
                          }
                        }}
                      />
                      <div className="flex border-none bg-[#ededed] items-center justify-center pr-4 rounded-r-xl border-l-0 !pr-2">
                        <div className="flex items-center gap-4 justify-end">
                          <div className="flex items-center gap-1">
                            <button className="flex items-center justify-center p-1.5">
                              <div className="text-neutral-500" data-icon="Paperclip" data-size="20px" data-weight="regular">
                                <Paperclip className="h-5 w-5" />
                              </div>
                            </button>
                          </div>
                          <button
                            onClick={handleAddComment}
                            disabled={submitting || !newComment.trim()}
                            className="min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-full h-8 px-4 bg-[#141414] text-white text-sm font-medium hidden @[480px]:block disabled:opacity-50"
                          >
                            <span className="truncate">Send</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </label>
                </div>

                {/* Comments List */}
                {ticket.comments && ticket.comments.filter(c => c.type === 'comment').length > 0 ? (
                  ticket.comments
                    .filter(comment => comment.type === 'comment')
                    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)) // Sort by newest first
                    .map((comment, index) => (
                      <div key={`comment-${comment.id || comment.createdAt || index}`} className="flex w-full flex-row items-start justify-start gap-3 p-4">
                        <div
                          className="bg-center bg-no-repeat aspect-square bg-cover rounded-full w-10 shrink-0"
                          style={{ backgroundImage: `url("https://i.pravatar.cc/300?u=${comment.user?.id || comment.createdBy || index}")` }}
                        ></div>
                        <div className="flex h-full flex-1 flex-col items-start justify-start">
                          <div className="flex w-full flex-row items-start justify-start gap-x-3">
                            <p className="text-[#141414] text-sm font-bold leading-normal tracking-[0.015em]">
                              {comment.user?.name || `User ${comment.createdBy}`}
                            </p>
                            <p className="text-neutral-500 text-sm font-normal leading-normal">
                              {formatDate(comment.createdAt)}
                            </p>
                          </div>
                          <p className="text-[#141414] text-sm font-normal leading-normal">{comment.content}</p>
                        </div>
                      </div>
                    ))
                ) : (
                  <p className="text-neutral-500 text-sm italic px-4 py-2">No comments yet</p>
                )}
              </>
            )}

            {/* Activity Tab Content */}
            {activeTab === 'activity' && (
              <div className="grid grid-cols-[40px_1fr] gap-x-2 px-4">
                {/* Create a unified activity timeline */}
                {(() => {
                  const activities = [];

                  // Add ticket creation
                  activities.push({
                    type: 'created',
                    icon: <FileText className="h-6 w-6 text-[#141414]" />,
                    title: 'Ticket created',
                    description: `by ${ticket.creator?.name || 'Unknown'}`,
                    timestamp: ticket.createdAt
                  });

                  // Add status update if not pending
                  if (ticket.status !== 'PENDING_APPROVAL' && ticket.approvedAt) {
                    activities.push({
                      type: 'status',
                      icon: <CheckCircle className="h-6 w-6 text-[#141414]" />,
                      title: 'Status updated to Approved',
                      description: `by ${ticket.approver?.name || 'Admin'}`,
                      timestamp: ticket.approvedAt
                    });
                  }

                  // Add assignment if assigned
                  if (ticket.assignedUser && ticket.assignedTo) {
                    activities.push({
                      type: 'assigned',
                      icon: <User className="h-6 w-6 text-[#141414]" />,
                      title: `Assigned to ${ticket.assignedUser.name}`,
                      description: '',
                      timestamp: ticket.updatedAt
                    });
                  }

                  // Add status updates from comments (but not regular comments)
                  if (ticket.comments && ticket.comments.length > 0) {
                    const statusUpdates = ticket.comments.filter(comment => comment.type === 'status_update');

                    statusUpdates.forEach(update => {
                      activities.push({
                        type: 'status_update',
                        icon: <Clock className="h-6 w-6 text-[#141414]" />,
                        title: 'Status updated',
                        description: update.content,
                        timestamp: update.createdAt
                      });
                    });
                  }

                  // Sort activities by timestamp
                  activities.sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));

                  return activities.map((activity, index) => (
                    <React.Fragment key={`activity-${activity.timestamp}-${index}`}>
                      <div className="flex flex-col items-center gap-1 pt-3">
                        <div className="text-[#141414]">
                          {activity.icon}
                        </div>
                        {index < activities.length - 1 && (
                          <div className="w-[1.5px] bg-[#dbdbdb] h-full grow"></div>
                        )}
                      </div>
                      <div className="flex flex-1 flex-col py-3">
                        <p className="text-[#141414] text-base font-medium leading-normal">
                          {activity.title}
                        </p>
                        {activity.description && (
                          <p className="text-neutral-500 text-base font-normal leading-normal">
                            {activity.description}
                          </p>
                        )}
                        <p className="text-neutral-500 text-base font-normal leading-normal">
                          {new Date(activity.timestamp).toLocaleDateString('en-US', {
                            month: 'short',
                            day: 'numeric',
                            year: 'numeric'
                          })}
                        </p>
                      </div>
                    </React.Fragment>
                  ));
                })()}

                {/* Status Update Buttons - Only for assigned user */}
                {isAssignedUser && ticket.status === 'APPROVED' && (
                  <>
                    <div className="flex flex-col items-center gap-1 pb-3">
                      <div className="w-[1.5px] bg-[#dbdbdb] h-2"></div>
                      <div className="text-[#141414]">
                        <Play className="h-6 w-6 text-[#141414]" />
                      </div>
                    </div>
                    <div className="flex flex-1 flex-col py-3">
                      <button
                        onClick={() => handleStatusUpdate('IN_PROGRESS')}
                        disabled={submitting}
                        className="flex items-center justify-center rounded-xl h-10 px-4 bg-[#141414] text-white text-sm font-medium w-full hover:bg-gray-800 disabled:opacity-50"
                      >
                        <Play className="h-4 w-4 mr-2" />
                        Start Work
                      </button>
                    </div>
                  </>
                )}

                {isAssignedUser && ticket.status === 'IN_PROGRESS' && (
                  <>
                    <div className="flex flex-col items-center gap-1 pb-3">
                      <div className="w-[1.5px] bg-[#dbdbdb] h-2"></div>
                      <div className="text-[#141414]">
                        <Eye className="h-6 w-6 text-[#141414]" />
                      </div>
                    </div>
                    <div className="flex flex-1 flex-col py-3 space-y-2">
                      <button
                        onClick={() => handleStatusUpdate('IN_REVIEW')}
                        disabled={submitting}
                        className="flex items-center justify-center rounded-xl h-10 px-4 bg-[#141414] text-white text-sm font-medium w-full hover:bg-gray-800 disabled:opacity-50"
                      >
                        <Eye className="h-4 w-4 mr-2" />
                        Submit for Review
                      </button>
                      <button
                        onClick={() => handleStatusUpdate('COMPLETED')}
                        disabled={submitting}
                        className="flex items-center justify-center rounded-xl h-10 px-4 bg-[#0d181c] text-white text-sm font-medium w-full hover:bg-gray-800 disabled:opacity-50"
                      >
                        <CheckSquare className="h-4 w-4 mr-2" />
                        Mark Complete
                      </button>
                    </div>
                  </>
                )}

                {isAssignedUser && ticket.status === 'IN_REVIEW' && (
                  <>
                    <div className="flex flex-col items-center gap-1 pb-3">
                      <div className="w-[1.5px] bg-[#d0dbe7] h-2"></div>
                      <div className="text-[#0d181c]">
                        <CheckSquare className="h-6 w-6 text-[#0d181c]" />
                      </div>
                    </div>
                    <div className="flex flex-1 flex-col py-3 space-y-2">
                      <button
                        onClick={() => handleStatusUpdate('IN_PROGRESS')}
                        disabled={submitting}
                        className="flex items-center justify-center rounded-xl h-10 px-4 bg-[#0d181c] text-white text-sm font-medium w-full hover:bg-gray-800 disabled:opacity-50"
                      >
                        <Play className="h-4 w-4 mr-2" />
                        Back to Work
                      </button>
                      <button
                        onClick={() => handleStatusUpdate('COMPLETED')}
                        disabled={submitting}
                        className="flex items-center justify-center rounded-xl h-10 px-4 bg-[#0d181c] text-white text-sm font-medium w-full hover:bg-gray-800 disabled:opacity-50"
                      >
                        <CheckSquare className="h-4 w-4 mr-2" />
                        Mark Complete
                      </button>
                    </div>
                  </>
                )}

                {/* Actions - Moved below activity log */}
                <div className="col-span-2 border-t border-t-[#d0dbe7] mt-4 pt-4">
                  {/* Admin/Super Admin/Assigned User Actions for Pending Approval tickets */}
                  {hasAdminPrivileges && ticket.status === 'PENDING_APPROVAL' && (
                    <div className="flex gap-2">
                      <button
                        onClick={() => openApprovalModal('approve')}
                        disabled={submitting}
                        className="flex items-center justify-center rounded-xl h-10 px-4 bg-[#0d181c] text-white text-sm font-medium flex-1"
                      >
                        <CheckCircle className="h-4 w-4 mr-2" />
                        Accept
                      </button>
                      <button
                        onClick={() => openApprovalModal('reject')}
                        disabled={submitting}
                        className="flex items-center justify-center rounded-xl h-10 px-4 border border-[#d0dbe7] bg-white text-[#0d181c] text-sm font-medium flex-1"
                      >
                        <XCircle className="h-4 w-4 mr-2" />
                        Reject
                      </button>
                    </div>
                  )}

                  {/* Edit button for pending approval tickets - show for creator, admin, or assigned user */}
                  {(isCreator || hasAdminPrivileges) && ticket.status === 'PENDING_APPROVAL' && (
                    <button
                      onClick={() => navigate(`/tickets/${id}/edit`)}
                      className="flex items-center justify-center rounded-xl h-10 px-4 border border-[#d0dbe7] bg-white text-[#0d181c] text-sm font-medium w-full mt-2"
                    >
                      <Edit className="h-4 w-4 mr-2" />
                      Edit Ticket
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Approval Modal */}
      {showApprovalModal && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <div className="mt-3">
              <div className="flex items-center">
                {approvalData.action === 'approve' ? (
                  <CheckCircle className="h-6 w-6 text-green-600 mr-2" />
                ) : (
                  <XCircle className="h-6 w-6 text-red-600 mr-2" />
                )}
                <h3 className="text-lg font-medium text-gray-900">
                  {approvalData.action === 'approve' ? 'Accept Ticket' : 'Reject Ticket'}
                </h3>
              </div>

              <div className="mt-4">
                <h4 className="text-sm font-medium text-gray-700 mb-2">
                  {ticket.title}
                </h4>

                {approvalData.action === 'approve' ? (
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        Priority
                      </label>
                      <select
                        value={approvalData.priority}
                        onChange={(e) => setApprovalData({ ...approvalData, priority: e.target.value })}
                        className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                      >
                        <option value="LOW">Low</option>
                        <option value="MEDIUM">Medium</option>
                        <option value="HIGH">High</option>
                        <option value="URGENT">Urgent</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        Expected Closure Date (Optional)
                      </label>
                      <input
                        type="datetime-local"
                        value={approvalData.expectedClosure}
                        onChange={(e) => setApprovalData({ ...approvalData, expectedClosure: e.target.value })}
                        className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                        min={new Date().toISOString().slice(0, 16)}
                      />
                    </div>
                  </div>
                ) : (
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Rejection Reason <span className="text-red-500">*</span>
                    </label>
                    <textarea
                      value={approvalData.rejectionReason}
                      onChange={(e) => setApprovalData({ ...approvalData, rejectionReason: e.target.value })}
                      className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                      rows={3}
                      placeholder="Please provide a reason for rejection..."
                      required
                    />
                  </div>
                )}
              </div>

              <div className="flex justify-end space-x-3 mt-6">
                <button
                  onClick={() => setShowApprovalModal(false)}
                  className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300"
                >
                  Cancel
                </button>
                <button
                  onClick={handleApproval}
                  disabled={approvalData.action === 'reject' && !approvalData.rejectionReason}
                  className={`px-4 py-2 rounded-md ${approvalData.action === 'approve'
                    ? 'bg-black text-white hover:bg-gray-800'
                    : 'bg-red-600 hover:bg-red-700 text-white'
                    } ${(approvalData.action === 'reject' && !approvalData.rejectionReason) ? 'opacity-50 cursor-not-allowed' : ''}`}
                >
                  {approvalData.action === 'approve' ? 'Accept' : 'Reject'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default TicketDetail;