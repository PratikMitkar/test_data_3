import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { api } from '../contexts/AuthContext';
import { getApiUrl } from '../config/api';
import toast from 'react-hot-toast';
import {
  Ticket,
  Save,
  ArrowLeft,
  AlertCircle,
  Calendar,
  Upload,
  X,
  FileText,
  Eye,
  Paperclip
} from 'lucide-react';

const EditTicket = () => {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [ticket, setTicket] = useState(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    type: 'task',
    category: 'Software',
    dueDate: '',
    teamId: '',
    assignedTeamId: '',
    projectId: '',
    priority: 'MEDIUM',
    estimatedHours: '',
    expectedClosure: ''
  });
  const [teams, setTeams] = useState([]);
  const [projects, setProjects] = useState([]);
  const [existingAttachments, setExistingAttachments] = useState([]);
  const [newAttachments, setNewAttachments] = useState([]);
  const [attachmentsToRemove, setAttachmentsToRemove] = useState([]);

  useEffect(() => {
    fetchTicket();
    fetchFormData();
  }, [id]);

  const fetchTicket = async () => {
    try {
      setLoading(true);
      const response = await api.get(`/api/tickets/${id}`);
      const ticketData = response.data.ticket;
      setTicket(ticketData);

      // Format date for input field (YYYY-MM-DDThh:mm)
      const formatDate = (dateString) => {
        if (!dateString) return '';
        const date = new Date(dateString);
        return date.toISOString().slice(0, 16);
      };

      setFormData({
        title: ticketData.title || '',
        description: ticketData.description || '',
        type: ticketData.type || 'task',
        category: ticketData.category || 'Software',
        dueDate: formatDate(ticketData.dueDate),
        teamId: ticketData.teamId?.toString() || '',
        assignedTeamId: ticketData.assignedTeamId?.toString() || '',
        projectId: ticketData.projectId?.toString() || '',
        priority: ticketData.priority || 'MEDIUM',
        estimatedHours: ticketData.estimatedHours?.toString() || '',
        expectedClosure: formatDate(ticketData.expectedClosure)
      });

      // Load existing attachments
      setExistingAttachments(ticketData.attachments || []);
    } catch (error) {
      console.error('Error fetching ticket:', error);
      toast.error('Failed to fetch ticket details');
      navigate('/tickets');
    } finally {
      setLoading(false);
    }
  };

  const fetchFormData = async () => {
    try {
      // Fetch teams and projects for dropdowns using the correct endpoints
      const [teamsRes, projectsRes] = await Promise.all([
        api.get('/api/teams/dropdown'),
        api.get('/api/projects/dropdown')
      ]);

      setTeams(teamsRes.data.teams || []);
      setProjects(projectsRes.data.projects || []);
    } catch (error) {
      console.error('Error fetching form data:', error);
      toast.error('Failed to load form data');
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // Handle new file uploads
  const handleFileChange = (e) => {
    const files = Array.from(e.target.files);
    setNewAttachments(prev => [...prev, ...files]);
  };

  // Remove new attachment (not yet uploaded)
  const removeNewAttachment = (index) => {
    setNewAttachments(prev => prev.filter((_, i) => i !== index));
  };

  // Mark existing attachment for removal
  const removeExistingAttachment = (index) => {
    const attachmentToRemove = existingAttachments[index];
    setAttachmentsToRemove(prev => [...prev, attachmentToRemove]);
    setExistingAttachments(prev => prev.filter((_, i) => i !== index));
  };

  // View existing attachment
  const viewAttachment = (attachment) => {
    const fileUrl = attachment.url || (attachment.path ? `${getApiUrl('')}/${attachment.path}` : null);
    if (fileUrl) {
      window.open(fileUrl, '_blank');
    } else {
      toast.error('File not found');
    }
  };

  // Download existing attachment
  const downloadAttachment = (attachment) => {
    const fileUrl = attachment.url || (attachment.path ? `${getApiUrl('')}/${attachment.path}` : null);
    if (fileUrl) {
      const link = document.createElement('a');
      link.href = fileUrl;
      link.download = attachment.originalName || attachment.filename || attachment.name || 'download';
      link.click();
    } else {
      toast.error('File not found');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validate required fields
    if (!formData.title || formData.title.length < 5) {
      toast.error('Title must be at least 5 characters long');
      return;
    }

    if (!formData.description || formData.description.length < 10) {
      toast.error('Description must be at least 10 characters long');
      return;
    }

    if (!formData.dueDate) {
      toast.error('Due date is required');
      return;
    }

    if (!formData.assignedTeamId) {
      toast.error('Please select a team to assign the task to');
      return;
    }

    try {
      setSubmitting(true);

      // Step 1: Update basic ticket information
      const updateData = {
        title: formData.title,
        description: formData.description,
        type: formData.type,
        category: formData.category,
        priority: formData.priority,
        dueDate: formData.dueDate,
        teamId: parseInt(formData.teamId),
        assignedTeamId: parseInt(formData.assignedTeamId)
      };

      if (formData.projectId) {
        updateData.projectId = parseInt(formData.projectId);
      }

      if (formData.estimatedHours) {
        updateData.estimatedHours = parseFloat(formData.estimatedHours);
      }

      if (formData.expectedClosure) {
        updateData.expectedClosure = formData.expectedClosure;
      }

      console.log('Updating ticket with data:', updateData);

      // Update ticket basic information
      const response = await api.put(`/api/tickets/${id}`, updateData);

      // Step 2: Handle attachment removals
      if (attachmentsToRemove.length > 0) {
        console.log('Removing attachments:', attachmentsToRemove.length);

        // Find the original indices of attachments to remove
        const originalAttachments = ticket.attachments || [];
        for (const attachmentToRemove of attachmentsToRemove) {
          const originalIndex = originalAttachments.findIndex(att =>
            att.filename === attachmentToRemove.filename &&
            att.uploadedAt === attachmentToRemove.uploadedAt
          );

          if (originalIndex !== -1) {
            try {
              await api.delete(`/api/tickets/${id}/attachments/${originalIndex}`);
              console.log(`Removed attachment at index ${originalIndex}`);
            } catch (error) {
              console.error(`Failed to remove attachment at index ${originalIndex}:`, error);
              toast.error(`Failed to remove attachment: ${attachmentToRemove.originalName || attachmentToRemove.filename}`);
            }
          }
        }
      }

      // Step 3: Handle new attachment uploads
      if (newAttachments.length > 0) {
        console.log('Adding new attachments:', newAttachments.length);

        const formDataForAttachments = new FormData();
        newAttachments.forEach((file) => {
          formDataForAttachments.append('attachments', file);
        });

        try {
          await api.post(`/api/tickets/${id}/attachments`, formDataForAttachments, {
            headers: {
              'Content-Type': 'multipart/form-data',
            },
          });
          console.log('Successfully added new attachments');
        } catch (error) {
          console.error('Failed to add new attachments:', error);
          toast.error('Failed to add new attachments');
        }
      }

      console.log('Ticket update response:', response.data);
      toast.success('Ticket updated successfully!');
      navigate(`/tickets/${id}`);
    } catch (error) {
      console.error('Error updating ticket:', error);

      // Show more detailed error information
      if (error.response) {
        console.error('Error response data:', error.response.data);
        console.error('Error response status:', error.response.status);

        // Extract validation error messages
        if (error.response.data.details && error.response.data.details.length > 0) {
          const errorMessages = error.response.data.details.map(detail => detail.msg).join(', ');
          toast.error(errorMessages);
        } else {
          toast.error(error.response.data.error || 'Failed to update ticket');
        }
      } else {
        toast.error('Failed to update ticket. Please check your connection.');
      }
    } finally {
      setSubmitting(false);
    }
  };

  // Check if user can edit this ticket
  const canEdit = () => {
    if (!ticket || !user) return false;

    // If ticket is not in PENDING_APPROVAL status, it can't be edited
    if (ticket.status !== 'PENDING_APPROVAL') return false;

    // Admin and super admin can always edit
    if (user.role === 'admin' || user.role === 'super_admin') return true;

    // Team manager can edit tickets for their team
    if (user.role === 'team' && ticket.teamId === user.id) return true;

    // User can edit if they created the ticket
    if (user.role === 'user' && ticket.createdBy === user.id) return true;

    return false;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  if (!ticket) {
    return (
      <div className="text-center py-12">
        <Ticket className="mx-auto h-12 w-12 text-gray-400" />
        <h3 className="mt-2 text-sm font-medium text-gray-900">Ticket not found</h3>
        <p className="mt-1 text-sm text-gray-500">The ticket you're looking for doesn't exist.</p>
      </div>
    );
  }

  if (!canEdit()) {
    return (
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex flex-col gap-3 p-4">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate(`/tickets/${id}`)}
              className="text-[#141414] hover:text-neutral-600"
            >
              <ArrowLeft className="h-6 w-6" />
            </button>
            <p className="text-[#141414] tracking-light text-[32px] font-bold leading-tight">Edit Ticket</p>
          </div>
          <p className="text-neutral-500 text-sm font-normal leading-normal">
            This ticket cannot be edited at this time.
          </p>
        </div>

        {/* Cannot Edit Message */}
        <div className="rounded-xl border border-[#dbdbdb] bg-neutral-50 overflow-hidden mx-4">
          <div className="p-6">
            <div className="bg-[#fff8dc] border border-[#f0e68c] rounded-xl p-4">
              <div className="flex">
                <div className="flex-shrink-0">
                  <AlertCircle className="h-5 w-5 text-[#141414]" />
                </div>
                <div className="ml-3">
                  <h3 className="text-sm font-medium text-[#141414]">
                    Cannot Edit Ticket
                  </h3>
                  <div className="mt-2 text-sm text-neutral-600">
                    <p>This ticket cannot be edited because:</p>
                    <ul className="list-disc pl-5 mt-1">
                      {ticket.status !== 'PENDING_APPROVAL' && (
                        <li>The ticket has already been {ticket.status.toLowerCase().replace('_', ' ')}</li>
                      )}
                      {ticket.status === 'PENDING_APPROVAL' && (
                        <li>You don't have permission to edit this ticket</li>
                      )}
                    </ul>
                  </div>
                  <div className="mt-4">
                    <button
                      type="button"
                      onClick={() => navigate(`/tickets/${id}`)}
                      className="flex items-center justify-center rounded-xl h-10 px-4 border border-[#dbdbdb] bg-white text-[#141414] text-sm font-medium hover:bg-neutral-50"
                    >
                      Back to Ticket
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex flex-col gap-3 p-4">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate(`/tickets/${id}`)}
            className="text-[#141414] hover:text-neutral-600"
          >
            <ArrowLeft className="h-6 w-6" />
          </button>
          <p className="text-[#141414] tracking-light text-[32px] font-bold leading-tight">Edit Ticket</p>
        </div>
        <p className="text-neutral-500 text-sm font-normal leading-normal">
          Update ticket information. Changes will be saved and reflected immediately.
        </p>
      </div>

      {/* Form */}
      <div className="rounded-xl border border-[#dbdbdb] bg-neutral-50 overflow-hidden mx-4">
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Title */}
          <div>
            <label htmlFor="title" className="block text-sm font-medium text-[#141414] mb-2">
              Ticket Title <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              id="title"
              name="title"
              value={formData.title}
              onChange={handleInputChange}
              className="flex h-10 w-full rounded-xl border border-[#dbdbdb] bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-black"
              placeholder="Enter ticket title (min 5 characters)"
              required
              minLength={5}
            />
          </div>

          {/* Description */}
          <div>
            <label htmlFor="description" className="block text-sm font-medium text-[#141414] mb-2">
              Description <span className="text-red-500">*</span>
            </label>
            <textarea
              id="description"
              name="description"
              value={formData.description}
              onChange={handleInputChange}
              rows={4}
              className="flex w-full rounded-xl border border-[#dbdbdb] bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-black"
              placeholder="Describe the issue or request in detail (min 10 characters)"
              required
              minLength={10}
            />
          </div>

          {/* Type and Category */}
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
            <div>
              <label htmlFor="type" className="block text-sm font-medium text-[#141414] mb-2">
                Ticket Type <span className="text-red-500">*</span>
              </label>
              <select
                id="type"
                name="type"
                value={formData.type}
                onChange={handleInputChange}
                className="flex h-10 w-full rounded-xl border border-[#dbdbdb] bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-black"
                required
              >
                <option value="bug">Bug</option>
                <option value="feature">Feature Request</option>
                <option value="task">Task</option>
                <option value="improvement">Improvement</option>
                <option value="support">Support</option>
                <option value="requirement">Requirement</option>
              </select>
            </div>

            <div>
              <label htmlFor="category" className="block text-sm font-medium text-[#141414] mb-2">
                Category <span className="text-red-500">*</span>
              </label>
              <select
                id="category"
                name="category"
                value={formData.category}
                onChange={handleInputChange}
                className="flex h-10 w-full rounded-xl border border-[#dbdbdb] bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-black"
                required
              >
                <option value="Hardware">Hardware</option>
                <option value="Software">Software</option>
                <option value="Tools">Tools</option>
                <option value="Lab Support">Lab Support</option>
                <option value="Purchase">Purchase</option>
                <option value="ASPICE">ASPICE</option>
                <option value="Functional Safety">Functional Safety</option>
                <option value="Cyber sec">Cyber sec</option>
              </select>
            </div>
          </div>

          {/* Assigned Team and Due Date */}
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
            <div>
              <label htmlFor="assignedTeamId" className="block text-sm font-medium text-[#141414] mb-2">
                Assign to Team <span className="text-red-500">*</span>
              </label>
              <select
                id="assignedTeamId"
                name="assignedTeamId"
                value={formData.assignedTeamId}
                onChange={handleInputChange}
                className="flex h-10 w-full rounded-xl border border-[#dbdbdb] bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-black"
                required
              >
                <option value="">Select a team to assign the task</option>
                {teams.map((team) => (
                  <option key={team.id} value={team.id}>
                    {team.teamName}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="dueDate" className="block text-sm font-medium text-[#141414] mb-2">
                Due Date <span className="text-red-500">*</span>
              </label>
              <input
                type="datetime-local"
                id="dueDate"
                name="dueDate"
                value={formData.dueDate}
                onChange={handleInputChange}
                className="flex h-10 w-full rounded-xl border border-[#dbdbdb] bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-black"
                required
                min={new Date().toISOString().slice(0, 16)}
              />
            </div>
          </div>

          {/* Creator Team and Project */}
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
            <div>
              <label htmlFor="teamId" className="block text-sm font-medium text-[#141414] mb-2">
                Creator Team <span className="text-red-500">*</span>
              </label>
              <select
                id="teamId"
                name="teamId"
                value={formData.teamId}
                onChange={handleInputChange}
                className="flex h-10 w-full rounded-xl border border-[#dbdbdb] bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-black"
                required
                disabled={user?.role === 'user' || user?.role === 'team'} // Members and team managers are auto-assigned
              >
                <option value="">Select creator team</option>
                {teams.map((team) => (
                  <option key={team.id} value={team.id}>
                    {team.teamName}
                  </option>
                ))}
              </select>
              {user?.role === 'user' && (
                <p className="mt-1 text-xs text-neutral-500">
                  You are automatically assigned to your team
                </p>
              )}
              {user?.role === 'team' && (
                <p className="mt-1 text-xs text-neutral-500">
                  This ticket was created on behalf of your team
                </p>
              )}
            </div>

            <div>
              <label htmlFor="projectId" className="block text-sm font-medium text-[#141414] mb-2">
                Project (Optional)
              </label>
              <select
                id="projectId"
                name="projectId"
                value={formData.projectId}
                onChange={handleInputChange}
                className="flex h-10 w-full rounded-xl border border-[#dbdbdb] bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-black"
              >
                <option value="">No Project</option>
                {projects.map((project) => (
                  <option key={project.id} value={project.id}>
                    {project.name} {project.team ? `(${project.team.teamName})` : ''}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Priority and Estimated Hours */}
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
            <div>
              <label htmlFor="priority" className="block text-sm font-medium text-[#141414] mb-2">
                Priority
              </label>
              <select
                id="priority"
                name="priority"
                value={formData.priority}
                onChange={handleInputChange}
                className="flex h-10 w-full rounded-xl border border-[#dbdbdb] bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-black"
              >
                <option value="LOW">Low</option>
                <option value="MEDIUM">Medium</option>
                <option value="HIGH">High</option>
                <option value="URGENT">Urgent</option>
              </select>
            </div>

            <div>
              <label htmlFor="estimatedHours" className="block text-sm font-medium text-[#141414] mb-2">
                Estimated Hours (Optional)
              </label>
              <input
                type="number"
                id="estimatedHours"
                name="estimatedHours"
                value={formData.estimatedHours}
                onChange={handleInputChange}
                className="flex h-10 w-full rounded-xl border border-[#dbdbdb] bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-black"
                placeholder="Enter estimated hours"
                min="0"
                step="0.5"
              />
            </div>
          </div>

          {/* Expected Closure Date */}
          <div>
            <label htmlFor="expectedClosure" className="block text-sm font-medium text-[#141414] mb-2">
              Expected Closure Date (Optional)
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Calendar className="h-5 w-5 text-neutral-500" />
              </div>
              <input
                type="datetime-local"
                id="expectedClosure"
                name="expectedClosure"
                value={formData.expectedClosure}
                onChange={handleInputChange}
                className="flex h-10 w-full rounded-xl border border-[#dbdbdb] bg-white px-3 py-2 pl-10 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-black"
              />
            </div>
          </div>

          {/* Attachments Management */}
          <div>
            <label className="block text-sm font-medium text-[#141414] mb-2">
              Attachments
            </label>

            {/* Existing Attachments */}
            {existingAttachments.length > 0 && (
              <div className="mb-4">
                <h4 className="text-sm font-medium text-[#141414] mb-2">Current Attachments:</h4>
                <div className="space-y-2">
                  {existingAttachments.map((attachment, index) => (
                    <div key={`existing-${attachment.filename}-${index}`} className="flex items-center gap-3 p-3 bg-white rounded-xl border border-[#dbdbdb]">
                      <div className="text-neutral-500">
                        <Paperclip className="h-4 w-4" />
                      </div>
                      <span className="text-[#141414] text-sm flex-1">
                        {attachment.originalName || attachment.filename || `attachment_${index + 1}`}
                      </span>
                      <div className="flex gap-2">
                        <button
                          type="button"
                          onClick={() => viewAttachment(attachment)}
                          className="flex items-center gap-1 px-3 py-1 bg-[#141414] text-white text-xs rounded-lg hover:bg-gray-800 transition-colors"
                          title="View file"
                        >
                          <Eye className="h-3 w-3" />
                          View
                        </button>
                        <button
                          type="button"
                          onClick={() => downloadAttachment(attachment)}
                          className="flex items-center gap-1 px-3 py-1 border border-[#dbdbdb] bg-white text-[#141414] text-xs rounded-lg hover:bg-neutral-50 transition-colors"
                          title="Download file"
                        >
                          <svg className="h-3 w-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                          </svg>
                          Download
                        </button>
                        <button
                          type="button"
                          onClick={() => removeExistingAttachment(index)}
                          className="flex items-center gap-1 px-3 py-1 bg-red-500 text-white text-xs rounded-lg hover:bg-red-600 transition-colors"
                          title="Remove file"
                        >
                          <X className="h-3 w-3" />
                          Remove
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Add New Attachments */}
            <div>
              <div className="flex items-center justify-center w-full">
                <label className="flex flex-col w-full h-32 border-2 border-dashed border-[#dbdbdb] hover:bg-[#f9f9f9] hover:border-[#c0c0c0] group cursor-pointer rounded-xl">
                  <div className="flex flex-col items-center justify-center pt-7">
                    <Upload className="w-10 h-10 text-neutral-400 group-hover:text-[#141414]" />
                    <p className="pt-1 text-sm tracking-wider text-neutral-400 group-hover:text-[#141414]">
                      Add new files
                    </p>
                  </div>
                  <input
                    type="file"
                    multiple
                    onChange={handleFileChange}
                    className="opacity-0"
                    accept=".jpeg,.jpg,.png,.gif,.pdf,.doc,.docx,.xls,.xlsx,.txt,.zip,.rar"
                  />
                </label>
              </div>
            </div>

            {/* Display new files to be uploaded */}
            {newAttachments.length > 0 && (
              <div className="mt-4 space-y-2">
                <h4 className="text-sm font-medium text-[#141414]">New Files to Upload:</h4>
                {newAttachments.map((file, index) => (
                  <div key={`new-${file.name}-${index}`} className="flex items-center justify-between p-2 bg-[#ededed] rounded-xl">
                    <div className="flex items-center">
                      <FileText className="h-4 w-4 text-[#141414] mr-2" />
                      <span className="text-sm text-[#141414]">{file.name}</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => removeNewAttachment(index)}
                      className="text-[#141414] hover:text-red-600 p-1"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Information Box */}
          <div className="bg-[#f5f8ff] border border-[#dbdbdb] rounded-xl p-4">
            <div className="flex">
              <div className="flex-shrink-0">
                <AlertCircle className="h-5 w-5 text-[#141414]" />
              </div>
              <div className="ml-3">
                <h3 className="text-sm font-medium text-[#141414]">
                  Ticket Update Information
                </h3>
                <div className="mt-2 text-sm text-neutral-500">
                  <p>• Changes will be saved immediately upon submission</p>
                  <p>• Only tickets in "Pending Approval" status can be edited</p>
                  <p>• Team assignments and priority may affect workflow</p>
                  <p>• You can add new attachments and remove existing ones</p>
                  <p>• All changes are logged for audit purposes</p>
                </div>
              </div>
            </div>
          </div>

          {/* Submit Button */}
          <div className="flex justify-end space-x-3">
            <button
              type="button"
              onClick={() => navigate(`/tickets/${id}`)}
              className="flex items-center justify-center rounded-xl h-10 px-4 border border-[#dbdbdb] bg-white text-[#141414] text-sm font-medium hover:bg-neutral-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="flex items-center justify-center rounded-xl h-10 px-4 bg-black text-neutral-50 text-sm font-medium hover:bg-gray-800 disabled:opacity-50"
            >
              {submitting ? (
                <div className="flex items-center">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Updating...
                </div>
              ) : (
                <>
                  <Save className="h-4 w-4 mr-2" />
                  Update Ticket
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditTicket;