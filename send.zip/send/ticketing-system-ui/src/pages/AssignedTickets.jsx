import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import axios from 'axios';
import { getApiUrl } from '../config/api';
import toast from 'react-hot-toast';
import {
  Search,
  Eye,
  Calendar,
  User,
  List,
  LayoutGrid,
  Users,
  Plus
} from 'lucide-react';

const AssignedTickets = () => {
  const { user } = useAuth();
  const [tickets, setTickets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    status: '',
    priority: '',
    search: '',
    page: 1,
    limit: 10
  });
  const [pagination, setPagination] = useState({
    page: 1,
    limit: 10,
    total: 0,
    pages: 0
  });

  useEffect(() => {
    fetchAssignedTickets();
  }, [filters]);

  const fetchAssignedTickets = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();

      Object.entries(filters).forEach(([key, value]) => {
        if (value) params.append(key, value);
      });

      const response = await axios.get(getApiUrl(`/api/tickets/assigned?${params}`));
      setTickets(response.data.tickets);
      setPagination(response.data.pagination);
    } catch (error) {
      console.error('Error fetching assigned tickets:', error);
      toast.error('Failed to fetch assigned tickets');
    } finally {
      setLoading(false);
    }
  };

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({
      ...prev,
      [key]: value,
      page: 1 // Reset to first page when filter changes
    }));
  };

  const handlePageChange = (page) => {
    setFilters(prev => ({ ...prev, page }));
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'Not set';
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div>
      {/* Header with Project Title - Exact Match to My Tickets */}
      <div className="flex flex-wrap justify-between gap-3 p-4">
        <div className="flex min-w-72 flex-col gap-3">
          <p className="text-[#141414] tracking-light text-[32px] font-bold leading-tight">Tickets Assigned to Me</p>
          <p className="text-neutral-500 text-sm font-normal leading-normal">Tickets assigned to you by other teams and users</p>
        </div>
      </div>

      {/* View Controls - Exact Match to My Tickets */}
      <div className="flex justify-between gap-2 px-4 py-3">
        <div className="flex gap-2">
          <button className="p-2 text-[#141414]">
            <List className="h-6 w-6" />
          </button>
          <button className="p-2 text-[#141414]">
            <LayoutGrid className="h-6 w-6" />
          </button>
        </div>
      </div>

      {/* Tickets Table - Exact Match to My Tickets */}
      <div className="px-4 py-3 @container">
        <div className="flex overflow-hidden rounded-xl border border-[#dbdbdb] bg-neutral-50">
          {loading ? (
            <div className="flex items-center justify-center h-64 w-full">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div>
            </div>
          ) : tickets.length === 0 ? (
            <div className="text-center py-12 w-full">
              <h3 className="mt-2 text-sm font-medium text-[#141414]">No assigned tickets</h3>
              <p className="mt-1 text-sm text-neutral-500">
                You don't have any tickets assigned to you by other teams or users.
              </p>
            </div>
          ) : (
            <table className="flex-1 w-full">
              <thead>
                <tr className="bg-neutral-50">
                  <th className="table-column-120 px-6 py-4 text-left text-[#141414] w-[35%] text-sm font-medium leading-normal">Title</th>
                  <th className="table-column-240 px-6 py-4 text-center text-[#141414] w-[20%] text-sm font-medium leading-normal">Priority</th>
                  <th className="table-column-360 px-6 py-4 text-center text-[#141414] w-[20%] text-sm font-medium leading-normal">Status</th>
                  <th className="table-column-480 px-6 py-4 text-left text-[#141414] w-[20%] text-sm font-medium leading-normal">From Team</th>
                  <th className="table-column-600 px-6 py-4 text-center text-[#141414] w-[5%] text-sm font-medium leading-normal">Actions</th>
                </tr>
              </thead>
              <tbody>
                {tickets.map((ticket, index) => (
                  <tr key={ticket.id} className="border-t border-t-[#dbdbdb]">
                    <td className="table-column-120 h-[72px] px-6 py-4 w-[35%] text-[#141414] text-sm font-normal leading-normal">
                      <Link to={`/tickets/${ticket.id}`} className="hover:underline">
                        {ticket.title}
                      </Link>
                    </td>
                    <td className="table-column-240 h-[72px] px-6 py-4 w-[20%] text-sm font-normal leading-normal text-center">
                      <div className="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-xl h-8 px-4 bg-[#ededed] text-[#141414] text-sm font-medium leading-normal w-full">
                        <span className="truncate">{ticket.priority ? ticket.priority.charAt(0) + ticket.priority.slice(1).toLowerCase() : 'Medium'}</span>
                      </div>
                    </td>
                    <td className="table-column-360 h-[72px] px-6 py-4 w-[20%] text-sm font-normal leading-normal text-center">
                      <div className="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-xl h-8 px-4 bg-[#ededed] text-[#141414] text-sm font-medium leading-normal w-full">
                        <span className="truncate">
                          {ticket.status === 'PENDING_APPROVAL' ? 'To Do' :
                            ticket.status === 'APPROVED' ? 'Approved' :
                              ticket.status === 'IN_PROGRESS' ? 'In Progress' :
                                ticket.status === 'COMPLETED' ? 'Completed' :
                                  ticket.status === 'REJECTED' ? 'Rejected' : 'To Do'}
                        </span>
                      </div>
                    </td>
                    <td className="table-column-480 h-[72px] px-6 py-4 w-[20%] text-neutral-500 text-sm font-normal leading-normal">
                      {ticket.creatorTeam?.teamName || 'Unknown Team'}
                      {ticket.creator && (
                        <div className="text-xs text-neutral-400">
                          by {ticket.creator?.name || 'Unknown User'}
                        </div>
                      )}
                    </td>
                    <td className="table-column-600 h-[72px] px-6 py-4 w-[5%] text-sm font-medium text-center">
                      <div className="flex items-center justify-center">
                        <Link
                          to={`/tickets/${ticket.id}`}
                          className="p-2 text-[#141414] hover:bg-[#ededed] rounded-full transition-colors"
                          title="View Details"
                        >
                          <Eye className="h-5 w-5" />
                        </Link>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
        <style>
          {`
          @container(max-width:120px){.table-column-120{display: none;}}
          @container(max-width:240px){.table-column-240{display: none;}}
          @container(max-width:360px){.table-column-360{display: none;}}
          @container(max-width:480px){.table-column-480{display: none;}}
          @container(max-width:600px){.table-column-600{display: none;}}
          `}
        </style>
      </div>

      {/* Pagination - Exact Match to My Tickets */}
      {pagination.pages > 1 && (
        <div className="flex items-center justify-between px-4 py-3">
          <div className="text-sm text-neutral-500">
            Showing {((pagination.page - 1) * pagination.limit) + 1} to{' '}
            {Math.min(pagination.page * pagination.limit, pagination.total)} of{' '}
            {pagination.total} results
          </div>
          <div className="flex space-x-2">
            <button
              onClick={() => handlePageChange(pagination.page - 1)}
              disabled={pagination.page === 1}
              className="flex items-center justify-center rounded-xl h-8 px-3 border border-[#dbdbdb] bg-neutral-50 text-[#141414] text-sm font-medium disabled:opacity-50"
            >
              Previous
            </button>
            <button
              onClick={() => handlePageChange(pagination.page + 1)}
              disabled={pagination.page === pagination.pages}
              className="flex items-center justify-center rounded-xl h-8 px-3 border border-[#dbdbdb] bg-neutral-50 text-[#141414] text-sm font-medium disabled:opacity-50"
            >
              Next
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default AssignedTickets;