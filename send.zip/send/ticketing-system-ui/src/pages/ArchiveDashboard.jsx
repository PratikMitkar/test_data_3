import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useArchive } from '../contexts/ArchiveContext';
import {
  Archive,
  Users,
  Building,
  Shield,
  Crown,
  Ticket,
  FolderOpen,
  Search,
  Filter,
  Eye,
  RotateCcw,
  AlertTriangle
} from 'lucide-react';
import toast from 'react-hot-toast';

const ArchiveDashboard = () => {
  const { user, isSuperAdmin, isAdmin } = useAuth();
  const {
    systemStatus,
    archivedContent,
    loading,
    fetchSystemStatus,
    fetchArchivedContent,
    canViewSystemStatus,
    canViewArchived
  } = useArchive();

  const [activeTab, setActiveTab] = useState('overview');
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');

  useEffect(() => {
    if (canViewSystemStatus()) {
      fetchSystemStatus();
    }
    if (canViewArchived()) {
      fetchArchivedContent();
    }
  }, []);

  if (!isAdmin()) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <AlertTriangle className="mx-auto h-12 w-12 text-red-500" />
          <h3 className="mt-2 text-sm font-medium text-[#141414]">Access Denied</h3>
          <p className="mt-1 text-sm text-neutral-500">
            You don't have permission to view the archive dashboard.
          </p>
        </div>
      </div>
    );
  }

  const StatCard = ({ title, value, total, icon: Icon, color = 'blue' }) => {
    const percentage = total > 0 ? ((value / total) * 100).toFixed(1) : 0;
    
    return (
      <div className="rounded-xl border border-[#dbdbdb] bg-neutral-50 p-6">
        <div className="flex items-center">
          <div className={`rounded-full p-2 bg-${color}-100`}>
            <Icon className={`h-6 w-6 text-${color}-600`} />
          </div>
          <div className="ml-4">
            <p className="text-sm font-medium text-neutral-500">{title}</p>
            <div className="flex items-baseline">
              <p className="text-2xl font-semibold text-[#141414]">{value}</p>
              <p className="ml-2 text-sm text-neutral-500">/ {total}</p>
            </div>
            <p className="text-xs text-neutral-400">{percentage}% archived</p>
          </div>
        </div>
      </div>
    );
  };

  const filteredTickets = archivedContent.tickets?.tickets?.filter(ticket => {
    const matchesSearch = ticket.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         ticket.description?.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesSearch;
  }) || [];

  const filteredProjects = archivedContent.projects?.projects?.filter(project => {
    const matchesSearch = project.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         project.code?.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesSearch;
  }) || [];

  return (
    <div>
      {/* Header */}
      <div className="flex flex-wrap justify-between gap-3 p-4">
        <div className="flex min-w-72 flex-col gap-3">
          <p className="text-[#141414] tracking-light text-[32px] font-bold leading-tight">Archive Dashboard</p>
          <p className="text-neutral-500 text-sm font-normal leading-normal">
            Monitor system status and manage archived content
          </p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => {
              if (canViewSystemStatus()) fetchSystemStatus();
              if (canViewArchived()) fetchArchivedContent();
            }}
            className="flex items-center justify-center rounded-xl h-10 px-4 border border-[#dbdbdb] bg-white text-[#141414] text-sm font-medium"
          >
            <RotateCcw className="h-4 w-4 mr-2" />
            Refresh
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="px-4">
        <div className="border-b border-[#dbdbdb]">
          <nav className="-mb-px flex space-x-8">
            <button
              onClick={() => setActiveTab('overview')}
              className={`py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'overview'
                  ? 'border-black text-[#141414]'
                  : 'border-transparent text-neutral-500 hover:text-[#141414] hover:border-neutral-300'
              }`}
            >
              Overview
            </button>
            {canViewArchived() && (
              <>
                <button
                  onClick={() => setActiveTab('tickets')}
                  className={`py-2 px-1 border-b-2 font-medium text-sm ${
                    activeTab === 'tickets'
                      ? 'border-black text-[#141414]'
                      : 'border-transparent text-neutral-500 hover:text-[#141414] hover:border-neutral-300'
                  }`}
                >
                  Archived Tickets
                </button>
                <button
                  onClick={() => setActiveTab('projects')}
                  className={`py-2 px-1 border-b-2 font-medium text-sm ${
                    activeTab === 'projects'
                      ? 'border-black text-[#141414]'
                      : 'border-transparent text-neutral-500 hover:text-[#141414] hover:border-neutral-300'
                  }`}
                >
                  Archived Projects
                </button>
              </>
            )}
          </nav>
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        {activeTab === 'overview' && (
          <div className="space-y-6">
            {/* System Status Cards */}
            {canViewSystemStatus() && systemStatus && (
              <div>
                <h3 className="text-lg font-medium text-[#141414] mb-4">System Status</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <StatCard
                    title="Super Admins"
                    value={systemStatus.superAdmins?.archived || 0}
                    total={systemStatus.superAdmins?.total || 0}
                    icon={Crown}
                    color="yellow"
                  />
                  <StatCard
                    title="Admins"
                    value={systemStatus.admins?.archived || 0}
                    total={systemStatus.admins?.total || 0}
                    icon={Shield}
                    color="blue"
                  />
                  <StatCard
                    title="Teams"
                    value={systemStatus.teams?.archived || 0}
                    total={systemStatus.teams?.total || 0}
                    icon={Building}
                    color="green"
                  />
                  <StatCard
                    title="Users"
                    value={systemStatus.users?.archived || 0}
                    total={systemStatus.users?.total || 0}
                    icon={Users}
                    color="purple"
                  />
                </div>
              </div>
            )}

            {/* Content Status Cards */}
            {canViewSystemStatus() && systemStatus && (
              <div>
                <h3 className="text-lg font-medium text-[#141414] mb-4">Content Status</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <StatCard
                    title="Tickets"
                    value={systemStatus.tickets?.archived || 0}
                    total={systemStatus.tickets?.total || 0}
                    icon={Ticket}
                    color="red"
                  />
                  <StatCard
                    title="Projects"
                    value={systemStatus.projects?.archived || 0}
                    total={systemStatus.projects?.total || 0}
                    icon={FolderOpen}
                    color="indigo"
                  />
                </div>
              </div>
            )}

            {/* Quick Actions */}
            <div>
              <h3 className="text-lg font-medium text-[#141414] mb-4">Quick Actions</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <button
                  onClick={() => setActiveTab('tickets')}
                  className="flex items-center justify-center rounded-xl h-12 border border-[#dbdbdb] bg-white text-[#141414] text-sm font-medium hover:bg-neutral-50"
                >
                  <Archive className="h-5 w-5 mr-2" />
                  View Archived Tickets
                </button>
                <button
                  onClick={() => setActiveTab('projects')}
                  className="flex items-center justify-center rounded-xl h-12 border border-[#dbdbdb] bg-white text-[#141414] text-sm font-medium hover:bg-neutral-50"
                >
                  <Archive className="h-5 w-5 mr-2" />
                  View Archived Projects
                </button>
                <button
                  onClick={() => window.location.href = '/users'}
                  className="flex items-center justify-center rounded-xl h-12 border border-[#dbdbdb] bg-white text-[#141414] text-sm font-medium hover:bg-neutral-50"
                >
                  <Users className="h-5 w-5 mr-2" />
                  Manage Users
                </button>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'tickets' && (
          <div className="space-y-4">
            {/* Search */}
            <div className="flex gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-neutral-500" />
                  <input
                    type="text"
                    placeholder="Search archived tickets..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="flex h-10 w-full rounded-xl border border-[#dbdbdb] bg-white px-3 py-2 pl-10 text-sm placeholder:text-neutral-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-black"
                  />
                </div>
              </div>
            </div>

            {/* Archived Tickets List */}
            <div className="rounded-xl border border-[#dbdbdb] bg-neutral-50">
              {loading ? (
                <div className="flex items-center justify-center h-64">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div>
                </div>
              ) : filteredTickets.length === 0 ? (
                <div className="text-center py-12">
                  <Archive className="mx-auto h-12 w-12 text-neutral-400" />
                  <h3 className="mt-2 text-sm font-medium text-[#141414]">No archived tickets</h3>
                  <p className="mt-1 text-sm text-neutral-500">
                    {searchTerm ? 'No tickets match your search.' : 'All tickets are currently active.'}
                  </p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="bg-neutral-50 border-b border-[#dbdbdb]">
                        <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                          Title
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                          Creator
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                          Team
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                          Status
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                          Actions
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-[#dbdbdb]">
                      {filteredTickets.map((ticket) => (
                        <tr key={ticket.id}>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm font-medium text-[#141414]">{ticket.title}</div>
                            <div className="text-sm text-neutral-500 truncate max-w-xs">
                              {ticket.description}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-[#141414]">
                              {ticket.creator?.name || 'Unknown'}
                            </div>
                            <div className="text-sm text-neutral-500">
                              {ticket.creator?.isActive ? 'Active' : 'Inactive'}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-[#141414]">
                              {ticket.creatorTeam?.teamName || 'Unknown'}
                            </div>
                            <div className="text-sm text-neutral-500">
                              {ticket.creatorTeam?.isActive ? 'Active' : 'Inactive'}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-red-100 text-red-800">
                              Archived
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            <button
                              onClick={() => window.location.href = `/tickets/${ticket.id}`}
                              className="text-[#141414] hover:text-black"
                            >
                              <Eye className="h-4 w-4" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === 'projects' && (
          <div className="space-y-4">
            {/* Search */}
            <div className="flex gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-neutral-500" />
                  <input
                    type="text"
                    placeholder="Search archived projects..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="flex h-10 w-full rounded-xl border border-[#dbdbdb] bg-white px-3 py-2 pl-10 text-sm placeholder:text-neutral-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-black"
                  />
                </div>
              </div>
            </div>

            {/* Archived Projects List */}
            <div className="rounded-xl border border-[#dbdbdb] bg-neutral-50">
              {loading ? (
                <div className="flex items-center justify-center h-64">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div>
                </div>
              ) : filteredProjects.length === 0 ? (
                <div className="text-center py-12">
                  <Archive className="mx-auto h-12 w-12 text-neutral-400" />
                  <h3 className="mt-2 text-sm font-medium text-[#141414]">No archived projects</h3>
                  <p className="mt-1 text-sm text-neutral-500">
                    {searchTerm ? 'No projects match your search.' : 'All projects are currently active.'}
                  </p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="bg-neutral-50 border-b border-[#dbdbdb]">
                        <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                          Project
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                          Manager
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                          Team
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                          Status
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                          Actions
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-[#dbdbdb]">
                      {filteredProjects.map((project) => (
                        <tr key={project.id}>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm font-medium text-[#141414]">{project.name}</div>
                            <div className="text-sm text-neutral-500">{project.code}</div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-[#141414]">
                              {project.manager?.name || 'Unknown'}
                            </div>
                            <div className="text-sm text-neutral-500">
                              {project.manager?.isActive ? 'Active' : 'Inactive'}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-[#141414]">
                              {project.team?.teamName || 'Unknown'}
                            </div>
                            <div className="text-sm text-neutral-500">
                              {project.team?.isActive ? 'Active' : 'Inactive'}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-red-100 text-red-800">
                              Archived
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            <button
                              onClick={() => window.location.href = `/projects/${project.id}`}
                              className="text-[#141414] hover:text-black"
                            >
                              <Eye className="h-4 w-4" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ArchiveDashboard;