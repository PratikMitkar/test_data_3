import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import {
    Users,
    Mail,
    User,
    Calendar,
    ArrowLeft,
    Activity,
    CheckCircle,
    Clock,
    AlertCircle,
    UserCheck,
    UserX,
    Shield
} from 'lucide-react';
import axios from 'axios';
import toast from 'react-hot-toast';
import { getApiUrl } from '../config/api';

const TeamDetail = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const { user } = useAuth();
    const [team, setTeam] = useState(null);
    const [stats, setStats] = useState(null);
    const [loading, setLoading] = useState(true);
    const [statsLoading, setStatsLoading] = useState(true);



    useEffect(() => {
        fetchTeamDetails();
        fetchTeamStats();
    }, [id]);

    const fetchTeamDetails = async () => {
        try {
            const response = await axios.get(getApiUrl(`/api/teams/${id}`));
            const teamData = response.data.team;
            
            // Check if team is deactivated and user doesn't have admin privileges
            if (!teamData.isActive && user?.role !== 'super_admin' && user?.role !== 'admin') {
                toast.error('This team has been deactivated and is no longer accessible');
                navigate('/teams');
                return;
            }
            
            setTeam(teamData);
        } catch (error) {
            console.error('Failed to fetch team details:', error);
            toast.error('Failed to load team details');
            if (error.response?.status === 404) {
                navigate('/teams');
            }
        } finally {
            setLoading(false);
        }
    };

    const fetchTeamStats = async () => {
        try {
            const response = await axios.get(getApiUrl(`/api/teams/${id}/stats`));
            setStats(response.data.stats);
        } catch (error) {
            console.error('Failed to fetch team stats:', error);
            // Don't show error toast for stats as it's not critical
        } finally {
            setStatsLoading(false);
        }
    };

    const toggleTeamStatus = async () => {
        try {
            await axios.put(getApiUrl(`/api/teams/${id}/status`), {
                isActive: !team.isActive
            });

            setTeam(prev => ({ ...prev, isActive: !prev.isActive }));
            toast.success(`Team ${!team.isActive ? 'activated' : 'deactivated'} successfully`);
        } catch (error) {
            toast.error('Failed to update team status');
        }
    };



    if (loading) {
        return (
            <div className="flex items-center justify-center h-64">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div>
            </div>
        );
    }

    if (!team) {
        return (
            <div className="text-center py-12 px-4">
                <Users className="mx-auto h-12 w-12 text-neutral-400" />
                <h3 className="mt-2 text-sm font-medium text-[#141414]">Team not found</h3>
                <p className="mt-1 text-sm text-neutral-500">
                    The team you're looking for doesn't exist or you don't have permission to view it.
                </p>
                <div className="mt-6">
                    <Link
                        to="/teams"
                        className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-black hover:bg-gray-800"
                    >
                        <ArrowLeft className="h-4 w-4 mr-2" />
                        Back to Teams
                    </Link>
                </div>
            </div>
        );
    }

    return (
        <div>
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b border-[#dbdbdb]">
                <div className="flex items-center">
                    <Link
                        to="/teams"
                        className="mr-4 p-2 hover:bg-gray-100 rounded-lg transition-colors"
                    >
                        <ArrowLeft className="h-5 w-5 text-neutral-600" />
                    </Link>
                    <div>
                        <h1 className="text-2xl font-bold text-[#141414]">{team.teamName}</h1>
                        <p className="text-sm text-neutral-500">Team Details & Members</p>
                    </div>
                </div>

                <div className="flex items-center gap-3">
                    <span className={`inline-flex px-3 py-1 text-sm font-semibold rounded-full ${team.isActive
                        ? 'bg-green-100 text-green-800'
                        : 'bg-red-100 text-red-800'
                        }`}>
                        {team.isActive ? 'Active' : 'Inactive'}
                    </span>

                    {(user?.role === 'super_admin' || user?.role === 'admin') && (
                        <button
                            onClick={toggleTeamStatus}
                            className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${team.isActive
                                ? 'bg-red-100 text-red-700 hover:bg-red-200'
                                : 'bg-green-100 text-green-700 hover:bg-green-200'
                                }`}
                        >
                            {team.isActive ? 'Deactivate' : 'Activate'}
                        </button>
                    )}
                </div>
            </div>

            {/* Deactivated Team Warning Banner */}
            {!team.isActive && (
                <div className="mx-6 mt-6 rounded-xl border border-red-200 bg-red-50 p-4">
                    <div className="flex items-center">
                        <Shield className="h-5 w-5 text-red-600 mr-3" />
                        <div>
                            <h3 className="text-sm font-medium text-red-800">Team Deactivated</h3>
                            <p className="text-sm text-red-700 mt-1">
                                This team has been deactivated. All team members have been deactivated and content may be hidden from normal users.
                            </p>
                        </div>
                    </div>
                </div>
            )}

            <div className="p-6">
                {/* Team Information Card */}
                <div className="bg-white rounded-xl border border-[#dbdbdb] p-6 mb-6">
                    <h2 className="text-lg font-semibold text-[#141414] mb-4">Team Information</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-4">
                            <div className="flex items-center">
                                <User className="h-5 w-5 text-neutral-500 mr-3" />
                                <div>
                                    <p className="text-sm text-neutral-500">Manager</p>
                                    <p className="font-medium text-[#141414]">{team.managerName}</p>
                                </div>
                            </div>

                            <div className="flex items-center">
                                <Mail className="h-5 w-5 text-neutral-500 mr-3" />
                                <div>
                                    <p className="text-sm text-neutral-500">Email</p>
                                    <p className="font-medium text-[#141414]">{team.email}</p>
                                </div>
                            </div>
                        </div>

                        <div className="space-y-4">
                            <div className="flex items-center">
                                <Calendar className="h-5 w-5 text-neutral-500 mr-3" />
                                <div>
                                    <p className="text-sm text-neutral-500">Created</p>
                                    <p className="font-medium text-[#141414]">
                                        {new Date(team.createdAt).toLocaleDateString('en-US', {
                                            year: 'numeric',
                                            month: 'long',
                                            day: 'numeric'
                                        })}
                                    </p>
                                </div>
                            </div>

                            <div className="flex items-center">
                                <Activity className="h-5 w-5 text-neutral-500 mr-3" />
                                <div>
                                    <p className="text-sm text-neutral-500">Status</p>
                                    <p className={`font-medium ${team.isActive ? 'text-green-600' : 'text-red-600'}`}>
                                        {team.isActive ? 'Active' : 'Inactive'}
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Team Statistics */}
                {!statsLoading && stats && (
                    <div className="bg-white rounded-xl border border-[#dbdbdb] p-6 mb-6">
                        <h2 className="text-lg font-semibold text-[#141414] mb-4">Team Statistics</h2>
                        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                            <div className="text-center p-4 bg-blue-50 rounded-lg">
                                <Users className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                                <p className="text-2xl font-bold text-blue-600">{stats.totalMembers}</p>
                                <p className="text-sm text-neutral-600">Total Members</p>
                            </div>

                            <div className="text-center p-4 bg-green-50 rounded-lg">
                                <UserCheck className="h-8 w-8 text-green-600 mx-auto mb-2" />
                                <p className="text-2xl font-bold text-green-600">{stats.activeMembers}</p>
                                <p className="text-sm text-neutral-600">Active Members</p>
                            </div>

                            <div className="text-center p-4 bg-purple-50 rounded-lg">
                                <Activity className="h-8 w-8 text-purple-600 mx-auto mb-2" />
                                <p className="text-2xl font-bold text-purple-600">{stats.totalTickets}</p>
                                <p className="text-sm text-neutral-600">Total Tickets</p>
                            </div>

                            <div className="text-center p-4 bg-yellow-50 rounded-lg">
                                <Clock className="h-8 w-8 text-yellow-600 mx-auto mb-2" />
                                <p className="text-2xl font-bold text-yellow-600">{stats.pendingTickets}</p>
                                <p className="text-sm text-neutral-600">Pending</p>
                            </div>

                            <div className="text-center p-4 bg-green-50 rounded-lg">
                                <CheckCircle className="h-8 w-8 text-green-600 mx-auto mb-2" />
                                <p className="text-2xl font-bold text-green-600">{stats.completedTickets}</p>
                                <p className="text-sm text-neutral-600">Completed</p>
                            </div>

                            <div className="text-center p-4 bg-indigo-50 rounded-lg">
                                <AlertCircle className="h-8 w-8 text-indigo-600 mx-auto mb-2" />
                                <p className="text-2xl font-bold text-indigo-600">{stats.completionRate}%</p>
                                <p className="text-sm text-neutral-600">Completion Rate</p>
                            </div>
                        </div>
                    </div>
                )}

                {/* Team Members */}
                <div className="bg-white rounded-xl border border-[#dbdbdb] p-6">
                    <div className="flex items-center justify-between mb-4">
                        <h2 className="text-lg font-semibold text-[#141414]">Team Members</h2>
                        <div className="flex items-center gap-4">
                            <span className="text-sm text-neutral-500">
                                {team.users?.length || 0} member{(team.users?.length || 0) !== 1 ? 's' : ''}
                            </span>
                            {(user?.role === 'super_admin' || user?.role === 'admin') && (
                                <Link
                                    to="/users/create-member"
                                    className="text-sm font-medium text-blue-600 hover:text-blue-700"
                                >
                                    Add Member
                                </Link>
                            )}
                        </div>
                    </div>

                    {team.users && team.users.length > 0 ? (
                        <div className="space-y-3">
                            {team.users.map((member) => (
                                <div key={member.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                                    <div className="flex items-center">
                                        <div className="bg-white rounded-full p-2 mr-3 shadow-sm">
                                            <User className="h-5 w-5 text-neutral-600" />
                                        </div>
                                        <div>
                                            <h3 className="font-medium text-[#141414]">{member.name}</h3>
                                            <p className="text-sm text-neutral-500">{member.email}</p>
                                            {member.username && (
                                                <p className="text-xs text-neutral-400">@{member.username}</p>
                                            )}
                                        </div>
                                    </div>

                                    <div className="flex items-center gap-3">
                                        <div className="text-right">
                                            <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${member.isActive
                                                ? 'bg-green-100 text-green-800'
                                                : 'bg-red-100 text-red-800'
                                                }`}>
                                                {member.isActive ? 'Active' : 'Inactive'}
                                            </span>
                                            <p className="text-xs text-neutral-500 mt-1">
                                                Joined {new Date(member.createdAt).toLocaleDateString()}
                                            </p>
                                        </div>


                                    </div>
                                </div>
                            ))}
                        </div>
                    ) : (
                        <div className="text-center py-8">
                            <UserX className="mx-auto h-12 w-12 text-neutral-400" />
                            <h3 className="mt-2 text-sm font-medium text-[#141414]">No team members</h3>
                            <p className="mt-1 text-sm text-neutral-500">
                                This team doesn't have any members assigned yet.
                            </p>
                        </div>
                    )}
                </div>
            </div>


        </div>
    );
};

export default TeamDetail;