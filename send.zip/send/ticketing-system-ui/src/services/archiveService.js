import axios from 'axios';
import { getApiUrl } from '../config/api';

class ArchiveService {
  /**
   * Get archived tickets and projects
   * @param {Object} options - Query options
   * @returns {Promise<Object>} - Archived content
   */
  static async getArchivedContent(options = {}) {
    try {
      const params = new URLSearchParams();
      
      Object.entries(options).forEach(([key, value]) => {
        if (value) params.append(key, value);
      });

      const response = await axios.get(getApiUrl(`/api/admin/archived?${params}`));
      return response.data;
    } catch (error) {
      console.error('Error fetching archived content:', error);
      throw error;
    }
  }

  /**
   * Get system status with archive statistics
   * @returns {Promise<Object>} - System status
   */
  static async getSystemStatus() {
    try {
      const response = await axios.get(getApiUrl('/api/admin/system-status'));
      return response.data;
    } catch (error) {
      console.error('Error fetching system status:', error);
      throw error;
    }
  }

  /**
   * Activate/Deactivate a user
   * @param {number} userId - User ID
   * @param {boolean} isActive - Active status
   * @returns {Promise<Object>} - Response data
   */
  static async updateUserStatus(userId, isActive) {
    try {
      const response = await axios.put(getApiUrl(`/api/admin/user/${userId}/status`), {
        isActive
      });
      return response.data;
    } catch (error) {
      console.error('Error updating user status:', error);
      throw error;
    }
  }

  /**
   * Activate/Deactivate a team
   * @param {number} teamId - Team ID
   * @param {boolean} isActive - Active status
   * @returns {Promise<Object>} - Response data
   */
  static async updateTeamStatus(teamId, isActive) {
    try {
      const response = await axios.put(getApiUrl(`/api/admin/team/${teamId}/status`), {
        isActive
      });
      return response.data;
    } catch (error) {
      console.error('Error updating team status:', error);
      throw error;
    }
  }

  /**
   * Activate/Deactivate an admin
   * @param {number} adminId - Admin ID
   * @param {boolean} isActive - Active status
   * @returns {Promise<Object>} - Response data
   */
  static async updateAdminStatus(adminId, isActive) {
    try {
      const response = await axios.put(getApiUrl(`/api/admin/admin/${adminId}/status`), {
        isActive
      });
      return response.data;
    } catch (error) {
      console.error('Error updating admin status:', error);
      throw error;
    }
  }

  /**
   * Activate/Deactivate a super admin
   * @param {number} superAdminId - Super Admin ID
   * @param {boolean} isActive - Active status
   * @returns {Promise<Object>} - Response data
   */
  static async updateSuperAdminStatus(superAdminId, isActive) {
    try {
      const response = await axios.put(getApiUrl(`/api/admin/super-admin/${superAdminId}/status`), {
        isActive
      });
      return response.data;
    } catch (error) {
      console.error('Error updating super admin status:', error);
      throw error;
    }
  }

  /**
   * Get tickets with archive filtering
   * @param {Object} options - Query options
   * @param {boolean} includeArchived - Whether to include archived tickets
   * @returns {Promise<Object>} - Tickets data
   */
  static async getTickets(options = {}, includeArchived = false) {
    try {
      const params = new URLSearchParams();
      
      Object.entries(options).forEach(([key, value]) => {
        if (value) params.append(key, value);
      });

      params.append('includeArchived', includeArchived.toString());

      const response = await axios.get(getApiUrl(`/api/tickets?${params}`));
      return response.data;
    } catch (error) {
      console.error('Error fetching tickets:', error);
      throw error;
    }
  }

  /**
   * Get projects with archive filtering
   * @param {Object} options - Query options
   * @param {boolean} includeArchived - Whether to include archived projects
   * @returns {Promise<Object>} - Projects data
   */
  static async getProjects(options = {}, includeArchived = false) {
    try {
      const params = new URLSearchParams();
      
      Object.entries(options).forEach(([key, value]) => {
        if (value) params.append(key, value);
      });

      params.append('includeArchived', includeArchived.toString());

      const response = await axios.get(getApiUrl(`/api/projects?${params}`));
      return response.data;
    } catch (error) {
      console.error('Error fetching projects:', error);
      throw error;
    }
  }

  /**
   * Check if current user's team is active
   * @param {Object} user - Current user object
   * @returns {Promise<boolean>} - Whether team is active
   */
  static async isUserTeamActive(user) {
    try {
      if (!user || !user.teamId) return true;
      
      const response = await axios.get(getApiUrl(`/api/teams/${user.teamId}`));
      return response.data.team?.isActive || false;
    } catch (error) {
      console.error('Error checking team status:', error);
      return false;
    }
  }
}

export default ArchiveService;