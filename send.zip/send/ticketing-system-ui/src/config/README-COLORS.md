# 🎨 Master Color Configuration Guide

## 📍 Single Source of Truth for All Colors

This guide explains how to change colors across the **ENTIRE** web application from a single location.

## 🎯 Quick Start - How to Change Colors

### To Change ALL Colors in the App:
1. Open `Client/ticketing-system-ui/src/config/colors.js`
2. Modify the colors in the `masterColors` object
3. Save the file
4. **ALL pages will automatically update!**

## 🎨 Color Categories

### 1. Brand Colors
```javascript
brand: {
  primary: '#141414',        // Main brand color (buttons, headers)
  primaryHover: '#262626',   // Hover state
  secondary: '#737373',      // Secondary elements
  accent: '#0ea5e9',         // Links and highlights
}
```

### 2. Status Colors (Ticket Status Badges)
```javascript
status: {
  pending: { bg: '#fef3c7', text: '#92400e' },     // Yellow
  approved: { bg: '#dbeafe', text: '#1e40af' },    // Blue
  inProgress: { bg: '#e0e7ff', text: '#4338ca' },  // Indigo
  completed: { bg: '#dcfce7', text: '#166534' },   // Green
  rejected: { bg: '#fee2e2', text: '#991b1b' },    // Red
}
```

### 3. Priority Colors (Priority Badges)
```javascript
priority: {
  low: { bg: '#dcfce7', text: '#166534' },      // Green
  medium: { bg: '#fef3c7', text: '#92400e' },   // Yellow
  high: { bg: '#fed7aa', text: '#c2410c' },     // Orange
  urgent: { bg: '#fee2e2', text: '#991b1b' },   // Red
  critical: { bg: '#f3e8ff', text: '#7c3aed' }, // Purple
}
```

## 🔄 How It Works

### Files That Control Colors:
1. **`/src/config/colors.js`** - Master color definitions
2. **`/src/index.css`** - CSS variables (auto-generated)
3. **`/src/components/ui/Badge.jsx`** - Status/Priority badges
4. **`/src/components/ui/Button.jsx`** - Button colors
5. **`/src/theme/index.js`** - Theme system integration

### Pages Using the System:
- ✅ Dashboard
- ✅ My Tickets (Tickets.jsx)
- ✅ Tickets Assigned to Me (AssignedTickets.jsx)
- ✅ Ticket Approval (TicketApproval.jsx)
- ✅ Ticket Detail (TicketDetail.jsx)
- ✅ Edit Ticket (EditTicket.jsx)

## 🎨 Example: Changing Theme Colors

### To Make Everything Blue Theme:
```javascript
// In /src/config/colors.js
brand: {
  primary: '#1e40af',        // Blue primary
  primaryHover: '#1d4ed8',   // Darker blue hover
  secondary: '#64748b',      // Blue-gray secondary
  accent: '#3b82f6',         // Bright blue accent
}
```

### To Make Everything Green Theme:
```javascript
// In /src/config/colors.js
brand: {
  primary: '#166534',        // Green primary
  primaryHover: '#15803d',   // Darker green hover
  secondary: '#64748b',      // Gray secondary
  accent: '#22c55e',         // Bright green accent
}
```

## 🚀 Advanced Customization

### Custom Status Colors:
```javascript
status: {
  pending: { bg: '#your-color', text: '#your-text-color' },
  // ... other statuses
}
```

### Custom Priority Colors:
```javascript
priority: {
  low: { bg: '#your-color', text: '#your-text-color' },
  // ... other priorities
}
```

## 📱 Responsive Design

All colors automatically work across:
- Desktop
- Tablet  
- Mobile
- Dark/Light themes (when implemented)

## 🔧 Technical Details

### CSS Variables Generated:
- `--color-brand-primary`
- `--color-status-pending-bg`
- `--color-priority-low-text`
- And many more...

### Component Integration:
- `<StatusBadge status="PENDING_APPROVAL" />` - Auto-styled
- `<PriorityBadge priority="HIGH" />` - Auto-styled
- `<Button variant="primary" />` - Auto-styled

## 🎯 Consistency Guarantee

✅ **Dashboard** - Uses master colors
✅ **My Tickets** - Uses master colors  
✅ **Tickets Assigned to Me** - Uses master colors
✅ **Ticket Approval** - Uses master colors
✅ **All Modals** - Uses master colors
✅ **All Forms** - Uses master colors

## 🚨 Important Notes

1. **Never hardcode colors** in components
2. **Always use** the master color system
3. **Test changes** across all pages
4. **Colors are cached** - refresh browser after changes

## 🎉 Result

**One file change = Entire app theme change!**

Change colors in `/src/config/colors.js` and watch your entire application transform instantly! 🚀