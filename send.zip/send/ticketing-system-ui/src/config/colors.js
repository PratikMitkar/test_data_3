// 🎨 MASTER COLOR CONFIGURATION
// ================================
// Change colors here and they will update across the ENTIRE application
// This is the SINGLE SOURCE OF TRUTH for all colors in the webapp

export const masterColors = {
  // 🎯 PRIMARY BRAND COLORS
  // These are the main colors that define your brand identity
  brand: {
    primary: '#141414',        // Main brand color (black) - used for primary buttons, headers
    primaryHover: '#262626',   // Hover state for primary elements
    secondary: '#737373',      // Secondary brand color (neutral gray)
    accent: '#0ea5e9',         // Accent color for highlights and links
  },

  // 🎨 BACKGROUND COLORS
  // These define the overall look and feel of your application
  background: {
    primary: '#ffffff',        // Main background (white)
    secondary: '#fafafa',      // Secondary background (neutral-50)
    tertiary: '#f5f5f5',      // Card backgrounds (neutral-100)
    hover: '#f9f9f9',          // Hover states
    border: '#dbdbdb',         // Border color
  },

  // 📝 TEXT COLORS
  // All text colors used throughout the application
  text: {
    primary: '#141414',        // Main text color (black)
    secondary: '#737373',      // Secondary text (neutral-500)
    muted: '#a3a3a3',          // Muted text (neutral-400)
    inverse: '#ffffff',        // White text for dark backgrounds
  },

  // 🚦 STATUS COLORS
  // Colors for different ticket statuses - CHANGE THESE TO UPDATE ALL STATUS BADGES
  status: {
    pending: {
      bg: '#fef3c7',           // Yellow background for pending
      text: '#92400e',         // Yellow text for pending
      border: '#f59e0b',       // Yellow border
    },
    approved: {
      bg: '#dbeafe',           // Blue background for approved
      text: '#1e40af',         // Blue text for approved
      border: '#3b82f6',       // Blue border
    },
    inProgress: {
      bg: '#e0e7ff',           // Indigo background for in progress
      text: '#4338ca',         // Indigo text for in progress
      border: '#6366f1',       // Indigo border
    },
    completed: {
      bg: '#dcfce7',           // Green background for completed
      text: '#166534',         // Green text for completed
      border: '#22c55e',       // Green border
    },
    rejected: {
      bg: '#fee2e2',           // Red background for rejected
      text: '#991b1b',         // Red text for rejected
      border: '#ef4444',       // Red border
    },
    onHold: {
      bg: '#f3f4f6',           // Gray background for on hold
      text: '#4b5563',         // Gray text for on hold
      border: '#6b7280',       // Gray border
    }
  },

  // 🎯 PRIORITY COLORS
  // Colors for different priority levels - CHANGE THESE TO UPDATE ALL PRIORITY BADGES
  priority: {
    low: {
      bg: '#dcfce7',           // Green background for low priority
      text: '#166534',         // Green text for low priority
      border: '#22c55e',       // Green border
    },
    medium: {
      bg: '#fef3c7',           // Yellow background for medium priority
      text: '#92400e',         // Yellow text for medium priority
      border: '#f59e0b',       // Yellow border
    },
    high: {
      bg: '#fed7aa',           // Orange background for high priority
      text: '#c2410c',         // Orange text for high priority
      border: '#f97316',       // Orange border
    },
    urgent: {
      bg: '#fee2e2',           // Red background for urgent priority
      text: '#991b1b',         // Red text for urgent priority
      border: '#ef4444',       // Red border
    },
    critical: {
      bg: '#f3e8ff',           // Purple background for critical priority
      text: '#7c3aed',         // Purple text for critical priority
      border: '#8b5cf6',       // Purple border
    }
  },

  // 🔘 BUTTON COLORS
  // All button variants used throughout the application
  buttons: {
    primary: {
      bg: '#141414',           // Primary button background
      text: '#ffffff',         // Primary button text
      hover: '#262626',        // Primary button hover
      border: '#141414',       // Primary button border
    },
    secondary: {
      bg: '#ffffff',           // Secondary button background
      text: '#141414',         // Secondary button text
      hover: '#f5f5f5',        // Secondary button hover
      border: '#dbdbdb',       // Secondary button border
    },
    success: {
      bg: '#22c55e',           // Success button background
      text: '#ffffff',         // Success button text
      hover: '#16a34a',        // Success button hover
      border: '#22c55e',       // Success button border
    },
    warning: {
      bg: '#f59e0b',           // Warning button background
      text: '#ffffff',         // Warning button text
      hover: '#d97706',        // Warning button hover
      border: '#f59e0b',       // Warning button border
    },
    error: {
      bg: '#ef4444',           // Error button background
      text: '#ffffff',         // Error button text
      hover: '#dc2626',        // Error button hover
      border: '#ef4444',       // Error button border
    },
    info: {
      bg: '#3b82f6',           // Info button background
      text: '#ffffff',         // Info button text
      hover: '#2563eb',        // Info button hover
      border: '#3b82f6',       // Info button border
    }
  },

  // 📊 CHART & GRAPH COLORS
  // Colors for data visualization
  charts: {
    primary: '#0ea5e9',
    secondary: '#8b5cf6',
    tertiary: '#f59e0b',
    quaternary: '#ef4444',
    success: '#22c55e',
    warning: '#f59e0b',
    error: '#ef4444',
  },

  // 🎨 SEMANTIC COLORS
  // Colors with specific meanings
  semantic: {
    success: '#22c55e',
    warning: '#f59e0b',
    error: '#ef4444',
    info: '#3b82f6',
    neutral: '#6b7280',
  }
};

// 🎨 COMPUTED COLOR UTILITIES
// These functions generate CSS classes based on the master colors above
export const getStatusColors = (status) => {
  const statusMap = {
    'PENDING_APPROVAL': masterColors.status.pending,
    'APPROVED': masterColors.status.approved,
    'IN_PROGRESS': masterColors.status.inProgress,
    'IN_REVIEW': masterColors.status.inProgress, // Same as in progress
    'COMPLETED': masterColors.status.completed,
    'REJECTED': masterColors.status.rejected,
    'ON_HOLD': masterColors.status.onHold,
  };
  
  const colors = statusMap[status] || masterColors.status.pending;
  return {
    backgroundColor: colors.bg,
    color: colors.text,
    borderColor: colors.border,
    className: `inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium`,
    style: {
      backgroundColor: colors.bg,
      color: colors.text,
      border: `1px solid ${colors.border}`
    }
  };
};

export const getPriorityColors = (priority) => {
  const priorityMap = {
    'LOW': masterColors.priority.low,
    'MEDIUM': masterColors.priority.medium,
    'HIGH': masterColors.priority.high,
    'URGENT': masterColors.priority.urgent,
    'CRITICAL': masterColors.priority.critical,
  };
  
  const colors = priorityMap[priority] || masterColors.priority.medium;
  return {
    backgroundColor: colors.bg,
    color: colors.text,
    borderColor: colors.border,
    className: `inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium`,
    style: {
      backgroundColor: colors.bg,
      color: colors.text,
      border: `1px solid ${colors.border}`
    }
  };
};

export const getButtonColors = (variant) => {
  const button = masterColors.buttons[variant] || masterColors.buttons.primary;
  return {
    backgroundColor: button.bg,
    color: button.text,
    borderColor: button.border,
    hoverBackgroundColor: button.hover,
    className: `inline-flex items-center justify-center rounded-xl font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-black disabled:opacity-50`,
    style: {
      backgroundColor: button.bg,
      color: button.text,
      border: `1px solid ${button.border}`
    },
    hoverStyle: {
      backgroundColor: button.hover
    }
  };
};

// 🎨 CSS CUSTOM PROPERTIES GENERATOR
// This generates CSS custom properties that can be used in CSS files
export const generateCSSVariables = () => {
  return `
    :root {
      /* Brand Colors */
      --color-brand-primary: ${masterColors.brand.primary};
      --color-brand-primary-hover: ${masterColors.brand.primaryHover};
      --color-brand-secondary: ${masterColors.brand.secondary};
      --color-brand-accent: ${masterColors.brand.accent};
      
      /* Background Colors */
      --color-bg-primary: ${masterColors.background.primary};
      --color-bg-secondary: ${masterColors.background.secondary};
      --color-bg-tertiary: ${masterColors.background.tertiary};
      --color-bg-hover: ${masterColors.background.hover};
      --color-border: ${masterColors.background.border};
      
      /* Text Colors */
      --color-text-primary: ${masterColors.text.primary};
      --color-text-secondary: ${masterColors.text.secondary};
      --color-text-muted: ${masterColors.text.muted};
      --color-text-inverse: ${masterColors.text.inverse};
      
      /* Status Colors */
      --color-status-pending-bg: ${masterColors.status.pending.bg};
      --color-status-pending-text: ${masterColors.status.pending.text};
      --color-status-approved-bg: ${masterColors.status.approved.bg};
      --color-status-approved-text: ${masterColors.status.approved.text};
      --color-status-progress-bg: ${masterColors.status.inProgress.bg};
      --color-status-progress-text: ${masterColors.status.inProgress.text};
      --color-status-completed-bg: ${masterColors.status.completed.bg};
      --color-status-completed-text: ${masterColors.status.completed.text};
      --color-status-rejected-bg: ${masterColors.status.rejected.bg};
      --color-status-rejected-text: ${masterColors.status.rejected.text};
      
      /* Priority Colors */
      --color-priority-low-bg: ${masterColors.priority.low.bg};
      --color-priority-low-text: ${masterColors.priority.low.text};
      --color-priority-medium-bg: ${masterColors.priority.medium.bg};
      --color-priority-medium-text: ${masterColors.priority.medium.text};
      --color-priority-high-bg: ${masterColors.priority.high.bg};
      --color-priority-high-text: ${masterColors.priority.high.text};
      --color-priority-urgent-bg: ${masterColors.priority.urgent.bg};
      --color-priority-urgent-text: ${masterColors.priority.urgent.text};
      
      /* Button Colors */
      --color-btn-primary-bg: ${masterColors.buttons.primary.bg};
      --color-btn-primary-text: ${masterColors.buttons.primary.text};
      --color-btn-primary-hover: ${masterColors.buttons.primary.hover};
      --color-btn-secondary-bg: ${masterColors.buttons.secondary.bg};
      --color-btn-secondary-text: ${masterColors.buttons.secondary.text};
      --color-btn-secondary-hover: ${masterColors.buttons.secondary.hover};
    }
  `;
};

export default masterColors;