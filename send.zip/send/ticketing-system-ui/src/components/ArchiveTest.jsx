import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useArchive } from '../contexts/ArchiveContext';
import { 
  CheckCircle, 
  XCircle, 
  AlertTriangle, 
  Users, 
  Building, 
  Ticket, 
  FolderOpen,
  RefreshCw
} from 'lucide-react';

const ArchiveTest = () => {
  const { user, isAdmin, isSuperAdmin } = useAuth();
  const {
    showArchived,
    setShowArchived,
    systemStatus,
    fetchSystemStatus,
    shouldShowArchiveWarning,
    canManageUsers,
    canViewArchived,
    canViewSystemStatus
  } = useArchive();

  const [testResults, setTestResults] = useState({});
  const [loading, setLoading] = useState(false);

  const runTests = async () => {
    setLoading(true);
    const results = {};

    try {
      // Test 1: Archive Context Availability
      results.contextAvailable = !!useArchive;

      // Test 2: User Authentication
      results.userAuthenticated = !!user;

      // Test 3: Role-based Access
      results.adminAccess = isAdmin();
      results.superAdminAccess = isSuperAdmin();

      // Test 4: Archive State Management
      results.archiveStateToggle = typeof setShowArchived === 'function';

      // Test 5: System Status (for admins)
      if (canViewSystemStatus()) {
        await fetchSystemStatus();
        results.systemStatusAvailable = !!systemStatus;
      }

      // Test 6: Permission Checks
      results.canManageUsersCheck = canManageUsers();
      results.canViewArchivedCheck = canViewArchived();
      results.canViewSystemStatusCheck = canViewSystemStatus();

      // Test 7: Archive Warning
      results.archiveWarningLogic = typeof shouldShowArchiveWarning === 'function';

      setTestResults(results);
    } catch (error) {
      console.error('Test error:', error);
      results.error = error.message;
      setTestResults(results);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    runTests();
  }, [user]);

  const TestResult = ({ label, result, description }) => {
    const isSuccess = result === true;
    const isError = result === false;
    const isInfo = typeof result === 'string' || typeof result === 'number';

    return (
      <div className="flex items-center justify-between p-3 rounded-lg border border-[#dbdbdb] bg-white">
        <div className="flex items-center space-x-3">
          {isSuccess && <CheckCircle className="h-5 w-5 text-green-600" />}
          {isError && <XCircle className="h-5 w-5 text-red-600" />}
          {isInfo && <AlertTriangle className="h-5 w-5 text-blue-600" />}
          <div>
            <p className="text-sm font-medium text-[#141414]">{label}</p>
            {description && (
              <p className="text-xs text-neutral-500">{description}</p>
            )}
          </div>
        </div>
        <div className="text-sm">
          {isSuccess && <span className="text-green-600 font-medium">✓ Pass</span>}
          {isError && <span className="text-red-600 font-medium">✗ Fail</span>}
          {isInfo && <span className="text-blue-600 font-medium">{String(result)}</span>}
        </div>
      </div>
    );
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="mb-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-[#141414]">Archive System Test</h1>
            <p className="text-neutral-500 mt-1">
              Testing frontend archive functionality and integration
            </p>
          </div>
          <button
            onClick={runTests}
            disabled={loading}
            className="flex items-center space-x-2 px-4 py-2 bg-black text-white rounded-lg hover:bg-gray-800 disabled:opacity-50"
          >
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
            <span>Run Tests</span>
          </button>
        </div>
      </div>

      {/* User Info */}
      <div className="mb-6 p-4 rounded-xl border border-[#dbdbdb] bg-neutral-50">
        <h2 className="text-lg font-semibold text-[#141414] mb-3">Current User Info</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <p className="text-sm text-neutral-500">Name</p>
            <p className="text-[#141414] font-medium">{user?.name || 'N/A'}</p>
          </div>
          <div>
            <p className="text-sm text-neutral-500">Role</p>
            <p className="text-[#141414] font-medium">{user?.role || 'N/A'}</p>
          </div>
          <div>
            <p className="text-sm text-neutral-500">Email</p>
            <p className="text-[#141414] font-medium">{user?.email || 'N/A'}</p>
          </div>
          <div>
            <p className="text-sm text-neutral-500">Active Status</p>
            <p className="text-[#141414] font-medium">
              {user?.isActive !== undefined ? (user.isActive ? 'Active' : 'Inactive') : 'N/A'}
            </p>
          </div>
        </div>
      </div>

      {/* Archive State */}
      <div className="mb-6 p-4 rounded-xl border border-[#dbdbdb] bg-neutral-50">
        <h2 className="text-lg font-semibold text-[#141414] mb-3">Archive State</h2>
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <span className="text-sm text-neutral-500">Show Archived:</span>
            <span className="text-[#141414] font-medium">
              {showArchived ? 'Yes' : 'No'}
            </span>
          </div>
          <button
            onClick={() => setShowArchived(!showArchived)}
            className={`px-3 py-1 text-sm rounded-lg ${
              showArchived 
                ? 'bg-red-100 text-red-800' 
                : 'bg-green-100 text-green-800'
            }`}
          >
            {showArchived ? 'Hide Archived' : 'Show Archived'}
          </button>
        </div>
      </div>

      {/* System Status */}
      {systemStatus && (
        <div className="mb-6 p-4 rounded-xl border border-[#dbdbdb] bg-neutral-50">
          <h2 className="text-lg font-semibold text-[#141414] mb-3">System Status</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center">
              <Users className="h-8 w-8 mx-auto text-blue-600 mb-2" />
              <p className="text-sm text-neutral-500">Users</p>
              <p className="text-lg font-bold text-[#141414]">
                {systemStatus.users?.active || 0}/{systemStatus.users?.total || 0}
              </p>
            </div>
            <div className="text-center">
              <Building className="h-8 w-8 mx-auto text-green-600 mb-2" />
              <p className="text-sm text-neutral-500">Teams</p>
              <p className="text-lg font-bold text-[#141414]">
                {systemStatus.teams?.active || 0}/{systemStatus.teams?.total || 0}
              </p>
            </div>
            <div className="text-center">
              <Ticket className="h-8 w-8 mx-auto text-red-600 mb-2" />
              <p className="text-sm text-neutral-500">Tickets</p>
              <p className="text-lg font-bold text-[#141414]">
                {systemStatus.tickets?.active || 0}/{systemStatus.tickets?.total || 0}
              </p>
            </div>
            <div className="text-center">
              <FolderOpen className="h-8 w-8 mx-auto text-purple-600 mb-2" />
              <p className="text-sm text-neutral-500">Projects</p>
              <p className="text-lg font-bold text-[#141414]">
                {systemStatus.projects?.active || 0}/{systemStatus.projects?.total || 0}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Test Results */}
      <div className="space-y-4">
        <h2 className="text-lg font-semibold text-[#141414]">Test Results</h2>
        
        <TestResult
          label="Archive Context Available"
          result={testResults.contextAvailable}
          description="Archive context is properly initialized"
        />
        
        <TestResult
          label="User Authentication"
          result={testResults.userAuthenticated}
          description="User is properly authenticated"
        />
        
        <TestResult
          label="Admin Access"
          result={testResults.adminAccess}
          description="User has admin privileges"
        />
        
        <TestResult
          label="Super Admin Access"
          result={testResults.superAdminAccess}
          description="User has super admin privileges"
        />
        
        <TestResult
          label="Archive State Toggle"
          result={testResults.archiveStateToggle}
          description="Archive visibility can be toggled"
        />
        
        {testResults.systemStatusAvailable !== undefined && (
          <TestResult
            label="System Status Available"
            result={testResults.systemStatusAvailable}
            description="System status data is accessible"
          />
        )}
        
        <TestResult
          label="Can Manage Users"
          result={testResults.canManageUsersCheck}
          description="User can manage other users"
        />
        
        <TestResult
          label="Can View Archived"
          result={testResults.canViewArchivedCheck}
          description="User can view archived content"
        />
        
        <TestResult
          label="Can View System Status"
          result={testResults.canViewSystemStatusCheck}
          description="User can view system status"
        />
        
        <TestResult
          label="Archive Warning Logic"
          result={testResults.archiveWarningLogic}
          description="Archive warning system is functional"
        />

        {testResults.error && (
          <TestResult
            label="Error Occurred"
            result={testResults.error}
            description="An error occurred during testing"
          />
        )}
      </div>

      {/* Archive Warning Demo */}
      {shouldShowArchiveWarning() && (
        <div className="mt-6 p-4 rounded-xl border border-orange-200 bg-orange-50">
          <div className="flex items-center">
            <AlertTriangle className="h-5 w-5 text-orange-600 mr-3" />
            <div>
              <h3 className="text-sm font-medium text-orange-800">Archive Warning Active</h3>
              <p className="text-sm text-orange-700 mt-1">
                This warning would be shown to users with deactivated accounts or teams.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ArchiveTest;