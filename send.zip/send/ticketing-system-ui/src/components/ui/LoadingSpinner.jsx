import { getLoadingSpinner, componentStyles } from '../../theme';

export const LoadingSpinner = ({ size = 'md', className = '' }) => {
  const spinnerClasses = getLoadingSpinner(size);
  
  return (
    <div className={`${componentStyles.loading.container} ${className}`}>
      <div className={spinnerClasses}></div>
    </div>
  );
};