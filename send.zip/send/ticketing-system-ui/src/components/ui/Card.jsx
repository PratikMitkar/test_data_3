import { componentStyles } from '../../theme';

export const Card = ({ children, className = '' }) => {
  return (
    <div className={`${componentStyles.card.base} ${className}`}>
      {children}
    </div>
  );
};

export const CardHeader = ({ children, className = '' }) => {
  return (
    <div className={`${componentStyles.card.header} ${className}`}>
      {children}
    </div>
  );
};

export const CardContent = ({ children, className = '' }) => {
  return (
    <div className={`${componentStyles.card.content} ${className}`}>
      {children}
    </div>
  );
};

export const CardFooter = ({ children, className = '' }) => {
  return (
    <div className={`${componentStyles.card.footer} ${className}`}>
      {children}
    </div>
  );
};