import { componentStyles } from '../../theme';

export const PageContainer = ({ children, className = '' }) => {
  return (
    <div className={`${componentStyles.page.container} ${className}`}>
      {children}
    </div>
  );
};

export const PageHeader = ({ title, subtitle, children, className = '' }) => {
  return (
    <div className={`${componentStyles.page.header} ${className}`}>
      <div className="flex items-center justify-between">
        <div>
          <h1 className={componentStyles.page.title}>{title}</h1>
          {subtitle && (
            <p className={componentStyles.page.subtitle}>{subtitle}</p>
          )}
        </div>
        {children && (
          <div className="flex items-center space-x-3">
            {children}
          </div>
        )}
      </div>
    </div>
  );
};

export const PageContent = ({ children, className = '' }) => {
  return (
    <div className={`${componentStyles.page.content} ${className}`}>
      {children}
    </div>
  );
};