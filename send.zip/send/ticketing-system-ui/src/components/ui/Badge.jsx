import { getStatusColors, getPriorityColors } from '../../config/colors';

export const StatusBadge = ({ status }) => {
  const colors = getStatusColors(status);
  const statusText = {
    'PENDING_APPROVAL': 'Pending Approval',
    'APPROVED': 'Approved', 
    'IN_PROGRESS': 'In Progress',
    'IN_REVIEW': 'In Review',
    'COMPLETED': 'Completed',
    'REJECTED': 'Rejected',
    'ON_HOLD': 'On Hold'
  };
  
  return (
    <span 
      className={colors.className}
      style={colors.style}
    >
      {statusText[status] || status}
    </span>
  );
};

export const PriorityBadge = ({ priority }) => {
  const colors = getPriorityColors(priority);
  const priorityText = {
    'LOW': 'Low',
    'MEDIUM': 'Medium', 
    'HIGH': 'High',
    'URGENT': 'Urgent',
    'CRITICAL': 'Critical'
  };
  
  return (
    <span 
      className={colors.className}
      style={colors.style}
    >
      {priorityText[priority] || priority}
    </span>
  );
};

export const Badge = ({ variant = 'primary', children, className = '' }) => {
  const baseClass = 'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium';
  const variants = {
    success: 'bg-green-100 text-green-800',
    warning: 'bg-yellow-100 text-yellow-800',
    error: 'bg-red-100 text-red-800',
    info: 'bg-blue-100 text-blue-800',
    primary: 'bg-gray-100 text-gray-800',
    neutral: 'bg-neutral-100 text-neutral-800'
  };
  
  return (
    <span className={`${baseClass} ${variants[variant]} ${className}`}>
      {children}
    </span>
  );
};