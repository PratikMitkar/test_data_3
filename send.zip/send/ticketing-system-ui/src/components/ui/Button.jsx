import { getButtonColors } from '../../config/colors';

export const Button = ({ 
  variant = 'primary', 
  size = 'md', 
  children, 
  className = '', 
  disabled = false,
  onClick,
  type = 'button',
  asChild = false,
  ...props 
}) => {
  const colors = getButtonColors(variant);
  const sizeClasses = {
    sm: 'h-8 px-3 text-xs',
    md: 'h-10 px-4 text-sm', 
    lg: 'h-12 px-6 text-base'
  };
  
  if (asChild) {
    // Return children with button classes applied
    return children;
  }
  
  return (
    <button
      type={type}
      className={`${colors.className} ${sizeClasses[size]} ${className}`}
      style={colors.style}
      disabled={disabled}
      onClick={onClick}
      onMouseEnter={(e) => {
        if (!disabled) {
          e.target.style.backgroundColor = colors.hoverStyle.backgroundColor;
        }
      }}
      onMouseLeave={(e) => {
        if (!disabled) {
          e.target.style.backgroundColor = colors.style.backgroundColor;
        }
      }}
      {...props}
    >
      {children}
    </button>
  );
};