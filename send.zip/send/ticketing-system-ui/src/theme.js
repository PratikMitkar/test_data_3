// Consistent theme configuration that works with existing color system
import { masterColors, getStatusColors, getPriorityColors, getButtonColors } from './config/colors';

// Component style helpers that use the existing color system
export const componentStyles = {
  form: {
    input: 'flex h-10 w-full rounded-xl border border-[#dbdbdb] bg-white px-3 py-2 text-sm placeholder:text-[#737373] focus:outline-none focus:ring-2 focus:ring-[#141414] focus:border-transparent disabled:opacity-50',
    select: 'flex h-10 w-full rounded-xl border border-[#dbdbdb] bg-white px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#141414] focus:border-transparent disabled:opacity-50',
    textarea: 'flex w-full rounded-xl border border-[#dbdbdb] bg-white px-3 py-2 text-sm placeholder:text-[#737373] focus:outline-none focus:ring-2 focus:ring-[#141414] focus:border-transparent disabled:opacity-50',
  },
  card: {
    base: 'rounded-xl border border-[#dbdbdb] bg-white shadow-sm',
    header: 'p-6 pb-0',
    content: 'p-6',
    footer: 'p-6 pt-0',
  },
  modal: {
    overlay: 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50',
    content: 'relative bg-white rounded-xl shadow-lg border border-[#dbdbdb] w-full max-w-md mx-4 p-6',
    header: 'flex items-center justify-between mb-4',
    title: 'text-lg font-semibold text-[#141414]',
    body: 'space-y-4',
    footer: 'flex items-center justify-end space-x-3 pt-4',
  }
};

// Icon color mappings using dark/black tone colors
export const iconColors = {
  roles: {
    'super_admin': 'text-[#404040]', // Dark gray for super admin
    'admin': 'text-[#262626]',       // Darker gray for admin
    'team': 'text-[#171717]',        // Very dark gray for team
    'user': 'text-[#525252]',        // Medium dark gray for user
  },
  status: {
    active: 'text-[#171717]',        // Very dark for active
    inactive: 'text-[#737373]',      // Medium gray for inactive
  },
  actions: {
    edit: 'text-[#404040] hover:text-[#171717]',           // Dark gray to black
    delete: 'text-[#525252] hover:text-[#262626]',         // Medium to dark gray
    activate: 'text-[#404040] hover:text-[#171717]',       // Dark gray to black
    deactivate: 'text-[#525252] hover:text-[#262626]',     // Medium to dark gray
  }
};

// Loading spinner helper using existing colors
export const getLoadingSpinner = (size = 'md') => {
  const sizes = {
    sm: 'h-4 w-4',
    md: 'h-8 w-8',
    lg: 'h-12 w-12',
    xl: 'h-16 w-16',
  };
  
  return `animate-spin rounded-full ${sizes[size]} border-2 border-[#e5e5e5] border-t-[#141414]`;
};

// Export existing color functions for consistency
export { getStatusColors, getPriorityColors, getButtonColors, masterColors };